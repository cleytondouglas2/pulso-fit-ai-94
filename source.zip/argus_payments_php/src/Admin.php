<?php
declare(strict_types=1);
namespace ArgusPayments;

use PDOException;
use ArgusPayments\Integrations\MisticPayPayout;

/** Owner-only operational console. Financial states are never edited manually. */
final class Admin
{
    private const ROLES = ['superadmin','admin','analyst'];
    private static function fail(string $msg,int $status=400):never { throw new ApiError($msg,$status); }
    private static function reply(mixed $data,int $status=200):never {
        header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');http_response_code($status);
        echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);exit;
    }
    private static function input():array {
        $raw=file_get_contents('php://input');if(!is_string($raw)||strlen($raw)>16384)self::fail('Solicitação muito grande',413);
        try{$data=json_decode($raw,true,24,JSON_THROW_ON_ERROR);}catch(\JsonException){self::fail('JSON inválido');}
        if(!is_array($data)||array_is_list($data))self::fail('Objeto JSON obrigatório');return $data;
    }
    private static function str(array $data,string $key,int $min=1,int $max=190):string {
        $value=$data[$key]??null;if(!is_string($value))self::fail('Campo obrigatório: '.$key);
        $value=trim($value);$len=function_exists('mb_strlen')?mb_strlen($value,'UTF-8'):strlen($value);
        if($len<$min||$len>$max)self::fail('Valor inválido: '.$key);return $value;
    }
    private static function now():string {return Database::stamp();}
    private static function bearerCookie():string { $v=$_COOKIE['arg_admin_session']??'';return is_string($v)&&preg_match('/\A[a-f0-9]{64}\z/D',$v)?$v:''; }
    private static function cookie(string $token,int $expires):void {
        $secure=filter_var(getenv('ARGUS_COOKIE_SECURE')?:'true',FILTER_VALIDATE_BOOLEAN);
        setcookie('arg_admin_session',$token,['expires'=>$expires,'path'=>'/','secure'=>$secure,'httponly'=>true,'samesite'=>'Strict']);
    }
    private static function csrfCookie(string $token,int $expires):void {
        $secure=filter_var(getenv('ARGUS_COOKIE_SECURE')?:'true',FILTER_VALIDATE_BOOLEAN);
        setcookie('arg_admin_csrf',$token,['expires'=>$expires,'path'=>'/','secure'=>$secure,'httponly'=>false,'samesite'=>'Strict']);
    }
    public static function install(Database $db):void {
        $isSql=$db->driver()!=='sqlite';$id=$isSql?'VARCHAR(120)':'TEXT';$email=$isSql?'VARCHAR(190)':'TEXT';$n=$isSql?'BIGINT':'INTEGER';$short=$isSql?'VARCHAR(80)':'TEXT';
        foreach([
          "CREATE TABLE IF NOT EXISTS admin_users (id $id PRIMARY KEY, email $email NOT NULL UNIQUE, display_name VARCHAR(180) NOT NULL, password_hash VARCHAR(255) NOT NULL, role VARCHAR(16) NOT NULL, status VARCHAR(16) NOT NULL DEFAULT 'active', must_change_password INTEGER NOT NULL DEFAULT 1, failed_logins INTEGER NOT NULL DEFAULT 0, locked_until $n NOT NULL DEFAULT 0, created_at VARCHAR(32) NOT NULL, last_login_at VARCHAR(32))",
          "CREATE TABLE IF NOT EXISTS admin_sessions (token_hash VARCHAR(64) PRIMARY KEY, user_id $id NOT NULL, csrf_hash VARCHAR(64) NOT NULL, expires_at $n NOT NULL, created_at VARCHAR(32) NOT NULL)",
          "CREATE TABLE IF NOT EXISTS admin_audit (id $id PRIMARY KEY, actor_id $id NOT NULL, action $short NOT NULL, entity_type VARCHAR(40) NOT NULL, entity_id VARCHAR(120) NOT NULL, detail TEXT NOT NULL, created_at VARCHAR(32) NOT NULL)",
          "CREATE TABLE IF NOT EXISTS admin_payer_blocks (id $id PRIMARY KEY, merchant_id $id NOT NULL, document_hash VARCHAR(64) NOT NULL, document_last4 VARCHAR(4) NOT NULL, reason VARCHAR(300) NOT NULL, created_at VARCHAR(32) NOT NULL, released_at VARCHAR(32))",
          "CREATE TABLE IF NOT EXISTS admin_payouts (id $id PRIMARY KEY, actor_id $id NOT NULL, idempotency_hash VARCHAR(64) NOT NULL UNIQUE, body_hash VARCHAR(64) NOT NULL, amount_cents $n NOT NULL, pix_key_type VARCHAR(24) NOT NULL, pix_key_masked VARCHAR(120) NOT NULL, pix_key_digest VARCHAR(64) NOT NULL, provider_tx_id VARCHAR(120), provider_job_id VARCHAR(120), status VARCHAR(24) NOT NULL, created_at VARCHAR(32) NOT NULL, checked_at VARCHAR(32))",
        ] as $sql)$db->pdo()->exec($sql);
        // Online schema migration, no login bypass for pre-existing accounts or sessions.
        foreach(['admin_users'=>['mfa_secret_cipher'=>'TEXT','mfa_pending_cipher'=>'TEXT','mfa_last_step'=>"$n NOT NULL DEFAULT -1",'mfa_failed_count'=>'INTEGER NOT NULL DEFAULT 0','mfa_locked_until'=>"$n NOT NULL DEFAULT 0"],
                 'admin_sessions'=>['mfa_verified_at'=>"$n NOT NULL DEFAULT 0"]] as $table=>$columns) {
            if($db->driver()==='pgsql') {
                $existing=$db->all('SELECT column_name FROM information_schema.columns WHERE table_schema=current_schema() AND table_name=?',[$table]);
                $found=array_fill_keys(array_column($existing,'column_name'),true);
                foreach($columns as $column=>$type)if(!isset($found[$column]))$db->pdo()->exec("ALTER TABLE $table ADD COLUMN IF NOT EXISTS $column $type");
            } else {
                $found=[];foreach($db->driver()==='sqlite'?$db->all("PRAGMA table_info($table)"):$db->all("SHOW COLUMNS FROM $table") as $r)$found[$r['name']??$r['Field']]=true;
                foreach($columns as $column=>$type)if(!isset($found[$column]))$db->pdo()->exec("ALTER TABLE $table ADD COLUMN $column $type");
            }
        }
        $emailRaw=trim((string)getenv('ARGUS_SUPERADMIN_BOOTSTRAP_EMAIL'));
        $email=strtolower($emailRaw);$hash=(string)getenv('ARGUS_SUPERADMIN_BOOTSTRAP_HASH');
        // Credentials come from Render secrets; code never creates a default password.
        if(filter_var($email,FILTER_VALIDATE_EMAIL)&&strlen($hash)>50&&password_get_info($hash)['algo']!==null){
            $user=$db->one('SELECT id FROM admin_users WHERE email=?',[$email]);
            $count=$db->one("SELECT COUNT(*) AS total FROM admin_users WHERE role='superadmin'");
            if(!$user&&(int)($count['total']??0)===0){
                try{$db->run('INSERT INTO admin_users(id,email,display_name,password_hash,role,status,must_change_password,failed_logins,locked_until,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
                    [Database::uid('adm'),$email,'Proprietário ARGUS',$hash,'superadmin','active',1,0,0,self::now()]);}
                catch(PDOException $e){if(!$db->one('SELECT id FROM admin_users WHERE email=?',[$email]))throw $e;}
            }
        }
    }
    private static function actor(Database $db,bool $allowPasswordChange=false):array {
        $token=self::bearerCookie();if($token==='')self::fail('Autenticação necessária',401);
        $row=$db->one('SELECT u.*,s.csrf_hash,s.mfa_verified_at FROM admin_sessions s JOIN admin_users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?',[hash('sha256',$token),time()]);
        if(!$row||$row['status']!=='active')self::fail('Sessão inválida ou expirada',401);
        if((int)$row['must_change_password']===1&&!$allowPasswordChange)self::fail('Altere a senha temporária antes de continuar',403);
        if(!$allowPasswordChange&&(!$row['mfa_secret_cipher']||(int)$row['mfa_verified_at']<=0))self::fail('Verifique o autenticador 2FA antes de continuar',403);
        return $row;
    }
    private static function csrf(array $actor):void {
        $given=$_SERVER['HTTP_X_CSRF_TOKEN']??'';
        if(!is_string($given)||strlen($given)<32||!hash_equals($actor['csrf_hash'],hash('sha256',$given)))self::fail('Token CSRF inválido; recarregue o painel',403);
    }
    private static function writeAllowed(array $actor,bool $super=false):void {
        if($super ? $actor['role']!=='superadmin' : !in_array($actor['role'],['superadmin','admin'],true))self::fail('Você não tem permissão para esta alteração',403);
    }
    private static function audit(Database $db,array $actor,string $action,string $entityType,string $entityId,string $detail=''):void {
        $db->run('INSERT INTO admin_audit(id,actor_id,action,entity_type,entity_id,detail,created_at) VALUES (?,?,?,?,?,?,?)',
            [Database::uid('audit'),$actor['id'],$action,$entityType,$entityId,substr($detail,0,700),self::now()]);
    }
    private static function safeUser(array $row):array {
        return ['id'=>$row['id'],'email'=>$row['email'],'display_name'=>$row['display_name'],'role'=>$row['role'],
          'status'=>$row['status'],'must_change_password'=>(bool)$row['must_change_password'],
          'mfa_enabled'=>!empty($row['mfa_secret_cipher']),
          'mfa_verified'=>((int)($row['mfa_verified_at']??0)>0),
          'created_at'=>$row['created_at'],'last_login_at'=>$row['last_login_at']??null];
    }
    private static function validCnpj(string $cnpj):bool {
        if(strlen($cnpj)!==14||preg_match('/^(\d)\1{13}$/',$cnpj))return false;
        $digits=array_map('intval',str_split($cnpj));foreach([12,13] as $pos){$w=$pos===12?[5,4,3,2,9,8,7,6,5,4,3,2]:[6,5,4,3,2,9,8,7,6,5,4,3,2];$sum=0;foreach($w as $i=>$num)$sum+=$num*$digits[$i];$rem=$sum%11;$check=$rem<2?0:11-$rem;if($check!==$digits[$pos])return false;}return true;
    }
    private static function email(string $value):string {
        $val=strtolower(trim($value));if(strlen($val)>190||!filter_var($val,FILTER_VALIDATE_EMAIL))self::fail('E-mail inválido');return $val;
    }
    private static function freshPassword(array $data,string $field='password'):string {
        $pwd=self::str($data,$field,16,256);if(!preg_match('/[A-Z]/',$pwd)||!preg_match('/[a-z]/',$pwd)||!preg_match('/[0-9]/',$pwd))self::fail('Senha precisa de 16 caracteres, letras maiúsculas, minúsculas e números',422);return $pwd;
    }
    private static function merchant(Database $db,string $id):array {
        $m=$db->one('SELECT * FROM b2b_merchants WHERE id=?',[$id]);if(!$m)self::fail('Empresa não encontrada',404);return $m;
    }
    private static function mfaFail(Database $db,array $actor):void {
        $fails=(int)$actor['mfa_failed_count']+1;
        $db->run('UPDATE admin_users SET mfa_failed_count=?,mfa_locked_until=? WHERE id=?',[$fails,$fails>=5?time()+900:0,$actor['id']]);
    }
    private static function verifyMfaCode(Database $db,array $actor,string $code):void {
        $current=$db->one('SELECT mfa_secret_cipher,mfa_last_step,mfa_failed_count,mfa_locked_until FROM admin_users WHERE id=?',[$actor['id']]);
        if(!$current||!$current['mfa_secret_cipher'])self::fail('Autenticador não cadastrado',403);
        if(time()<(int)$current['mfa_locked_until'])self::fail('Autenticador temporariamente bloqueado',429);
        $secret=Security2FA::unseal($current['mfa_secret_cipher']);
        $step=Security2FA::matchingStep($secret,$code,(int)$current['mfa_last_step']);
        if($step===null){self::mfaFail($db,array_merge($actor,$current));self::fail('Código expirado ou inválido. Aguarde o próximo código.',403);}
        $updated=$db->run('UPDATE admin_users SET mfa_last_step=?,mfa_failed_count=0,mfa_locked_until=0 WHERE id=? AND mfa_last_step<?',[$step,$actor['id'],$step]);
        if($updated->rowCount()!==1)self::fail('Código já utilizado',403);
    }
    private static function payoutAvailable(Database $db):void {
        if(getenv('ARGUS_PAYOUTS_ENABLED')!=='yes')self::fail('Transferências Pix estão aguardando ativação das credenciais de saque e controles operacionais',503);
        if(!LivePix::readiness($db)['ready'])self::fail('Piloto Pix expirou ou não está disponível',503);
        if(!Security2FA::key())self::fail('Chave de autenticação 2FA indisponível',503);
    }
    private static function payoutClient():MisticPayPayout {
        try{return new MisticPayPayout((string)getenv('ARGUS_MISTICPAY_PAYOUT_PK'),(string)getenv('ARGUS_MISTICPAY_PAYOUT_SK'));}
        catch(\InvalidArgumentException){self::fail('Crie uma chave MisticPay separada com permissões BALANCE_READ e WITHDRAW_CREATE',503);}
    }
    private static function liveReport(Database $db,string $from,string $to):array {
        $rows=$db->all('SELECT substr(created_at,1,10) AS day, COUNT(*) AS quantity, COALESCE(SUM(amount_cents),0) AS gross_cents, COALESCE(SUM(CASE WHEN status=\'paid\' THEN amount_cents ELSE 0 END),0) AS paid_cents, COALESCE(SUM(CASE WHEN status=\'paid\' THEN commission_cents ELSE 0 END),0) AS commission_estimate_cents FROM b2b_live_pix WHERE substr(created_at,1,10)>=? AND substr(created_at,1,10)<=? GROUP BY substr(created_at,1,10) ORDER BY day DESC',[$from,$to]);return $rows;
    }
    public static function handle(Database $db,string $method,string $path):never {
        self::install($db);
        if($method==='POST'&&$path==='/api/admin/login'){
            $data=self::input();$email=self::email(self::str($data,'email',4,190));$password=self::str($data,'password',1,256);
            $row=$db->one('SELECT * FROM admin_users WHERE email=?',[$email]);
            $valid=$row&&$row['status']==='active'&&time()>=(int)$row['locked_until']&&password_verify($password,$row['password_hash']);
            if(!$valid){if($row&&$row['status']==='active'&&time()>=(int)$row['locked_until']){
                $fails=(int)$row['failed_logins']+1;
                $db->run('UPDATE admin_users SET failed_logins=?,locked_until=? WHERE id=?',[$fails,$fails>=5?time()+900:0,$row['id']]);}
                self::fail('Credenciais inválidas ou acesso temporariamente bloqueado',401);
            }
            $token=bin2hex(random_bytes(32));$csrf=bin2hex(random_bytes(32));$expiry=time()+28800;
            $db->transaction(function(Database $db)use($row,$token,$csrf,$expiry){
                $db->run('DELETE FROM admin_sessions WHERE user_id=? OR expires_at<?',[$row['id'],time()]);
                $db->run('INSERT INTO admin_sessions(token_hash,user_id,csrf_hash,expires_at,created_at,mfa_verified_at) VALUES (?,?,?,?,?,0)',[hash('sha256',$token),$row['id'],hash('sha256',$csrf),$expiry,self::now()]);
                $db->run('UPDATE admin_users SET failed_logins=0,locked_until=0,last_login_at=? WHERE id=?',[self::now(),$row['id']]);
                self::audit($db,$row,'auth.login','admin_user',$row['id']);
            });
            self::cookie($token,$expiry);self::csrfCookie($csrf,$expiry);self::reply(['user'=>self::safeUser($row),'csrf_token'=>$csrf]);
        }
        if($method==='GET'&&$path==='/api/admin/session'){
            $who=self::actor($db,true);self::reply(['user'=>self::safeUser($who)]);
        }
        $actor=self::actor($db,true);
        if(in_array($method,['POST','PATCH','PUT','DELETE'],true))self::csrf($actor);
        if($method==='POST'&&$path==='/api/admin/change-password'){
            $data=self::input();if(!password_verify(self::str($data,'current_password',1,256),$actor['password_hash']))self::fail('Senha atual inválida',403);
            $pwd=self::freshPassword($data,'new_password');
            if(password_verify($pwd,$actor['password_hash']))self::fail('Escolha uma senha diferente',422);
            $db->transaction(function(Database $db)use($actor,$pwd){
                $db->run('UPDATE admin_users SET password_hash=?,must_change_password=0 WHERE id=?',[password_hash($pwd,PASSWORD_DEFAULT),$actor['id']]);
                $db->run('DELETE FROM admin_sessions WHERE user_id=?',[$actor['id']]);
                self::audit($db,$actor,'auth.password_changed','admin_user',$actor['id']);
            });
            self::cookie('',time()-3600);self::csrfCookie('',time()-3600);self::reply(['ok'=>true,'message'=>'Senha alterada; entre novamente']);
        }
        if($method==='POST'&&$path==='/api/admin/logout'){
            $token=self::bearerCookie();$db->run('DELETE FROM admin_sessions WHERE token_hash=?',[hash('sha256',$token)]);self::cookie('',time()-3600);self::csrfCookie('',time()-3600);self::reply(['ok'=>true]);
        }
        if((int)$actor['must_change_password']===1)self::fail('Altere a senha temporária antes de continuar',403);
        if((int)$actor['must_change_password']===1)self::fail('Altere a senha temporária antes de continuar',403);
        // Every interactive admin account, including newly created accounts, MUST enroll
        // and prove 2FA after the password stage. API keys are machine credentials, not logins.
        if($method==='GET'&&$path==='/api/admin/mfa/setup') {
            if($actor['mfa_secret_cipher'])self::fail('2FA já vinculado; solicite recuperação supervisionada',409);
            $pending=$db->one('SELECT mfa_pending_cipher FROM admin_users WHERE id=?',[$actor['id']]);
            if(!empty($pending['mfa_pending_cipher']))$secret=Security2FA::unseal($pending['mfa_pending_cipher']);
            else {$secret=Security2FA::newSecret();$db->run('UPDATE admin_users SET mfa_pending_cipher=? WHERE id=?',[Security2FA::seal($secret),$actor['id']]);}
            self::reply(['secret'=>$secret,'otpauth_uri'=>Security2FA::uri($actor['email'],$secret),'issuer'=>'ARGUS Payments']);
        }
        if($method==='POST'&&$path==='/api/admin/mfa/activate') {
            if($actor['mfa_secret_cipher'])self::fail('2FA já habilitado',409);
            $input=self::input();$code=self::str($input,'code',6,6);
            $pending=$db->one('SELECT mfa_pending_cipher,mfa_failed_count,mfa_locked_until FROM admin_users WHERE id=?',[$actor['id']]);
            if(!$pending['mfa_pending_cipher'])self::fail('Inicie o cadastro do autenticador',409);
            if(time()<(int)$pending['mfa_locked_until'])self::fail('Autenticador temporariamente bloqueado',429);
            $secret=Security2FA::unseal($pending['mfa_pending_cipher']);
            $step=Security2FA::matchingStep($secret,$code);
            if($step===null){self::mfaFail($db,$actor);self::fail('Código 2FA inválido',403);}
            $db->transaction(function(Database $db)use($actor,$secret,$step){
                $db->run('UPDATE admin_users SET mfa_secret_cipher=?,mfa_pending_cipher=NULL,mfa_last_step=?,mfa_failed_count=0,mfa_locked_until=0 WHERE id=?',[Security2FA::seal($secret),$step,$actor['id']]);
                $db->run('UPDATE admin_sessions SET mfa_verified_at=? WHERE token_hash=?',[time(),hash('sha256',self::bearerCookie())]);
                self::audit($db,$actor,'auth.mfa_enrolled','admin_user',$actor['id']);
            });self::reply(['ok'=>true]);
        }
        if($method==='POST'&&$path==='/api/admin/mfa/verify') {
            if(!$actor['mfa_secret_cipher'])self::fail('Cadastre primeiro o autenticador',409);
            $input=self::input();self::verifyMfaCode($db,$actor,self::str($input,'code',6,6));
            $db->run('UPDATE admin_sessions SET mfa_verified_at=? WHERE token_hash=?',[time(),hash('sha256',self::bearerCookie())]);
            self::audit($db,$actor,'auth.mfa_verified','admin_user',$actor['id']);self::reply(['ok'=>true]);
        }
        if(!$actor['mfa_secret_cipher']||(int)$actor['mfa_verified_at']<=0)self::fail('Verifique o autenticador 2FA antes de continuar',403);
        if($method==='GET'&&$path==='/api/admin/wallet/balance') {
            self::writeAllowed($actor,true);self::payoutAvailable($db);
            $client=self::payoutClient();self::reply(['available_cents'=>$client->balance(),'source'=>'MisticPay — conta da ARGUS, não saldos das empresas']);
        }
        if($method==='GET'&&$path==='/api/admin/payouts') {
            self::writeAllowed($actor,true);
            self::reply($db->all('SELECT id,amount_cents,pix_key_type,pix_key_masked,provider_tx_id,provider_job_id,status,created_at,checked_at FROM admin_payouts ORDER BY created_at DESC LIMIT 150'));
        }
        if($method==='POST'&&$path==='/api/admin/payouts') {
            self::writeAllowed($actor,true);self::payoutAvailable($db);$data=self::input();
            if(($data['confirm']??null)!==true)self::fail('Confirmação de saque obrigatória',422);
            $amount=$data['amount_cents']??null;
            if(!is_int($amount)||$amount<100||$amount>10000)self::fail('Limite temporário: R$ 1 a R$ 100 por Pix',422);
            $type=self::str($data,'pix_key_type',3,24);$key=MisticPayPayout::validatePixKey($type,self::str($data,'pix_key',5,190));
            $description=self::str($data,'description',3,120);$idem=self::str($data,'idempotency_key',16,120);
            $requestHash=hash('sha256',json_encode([$amount,$type,$key,$description],JSON_THROW_ON_ERROR));
            $digest=hash_hmac('sha256',$key,Security2FA::key());$idemHash=hash('sha256',$idem);
            $existing=$db->one('SELECT id,body_hash,status,provider_tx_id FROM admin_payouts WHERE idempotency_hash=?',[$idemHash]);
            if($existing){if(!hash_equals($requestHash,$existing['body_hash']))self::fail('Chave de idempotência usada com outros dados',409);self::reply(['id'=>$existing['id'],'status'=>$existing['status'],'provider_tx_id'=>$existing['provider_tx_id'],'already_submitted'=>true]);}
            // A new TOTP must be entered for EVERY transfer; codes cannot be replayed.
            self::verifyMfaCode($db,$actor,self::str($data,'otp',6,6));
            $day=$db->one('SELECT COALESCE(SUM(amount_cents),0) AS total FROM admin_payouts WHERE substr(created_at,1,10)=?',[gmdate('Y-m-d')]);
            if((int)$day['total']+$amount>50000)self::fail('Limite de piloto: R$ 500 por dia',429);
            $id=Database::uid('payout');$masked=substr($key,0,3).'••••'.substr($key,-4);
            $db->run('INSERT INTO admin_payouts(id,actor_id,idempotency_hash,body_hash,amount_cents,pix_key_type,pix_key_masked,pix_key_digest,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',[$id,$actor['id'],$idemHash,$requestHash,$amount,$type,$masked,$digest,'creating',self::now()]);
            self::audit($db,$actor,'payout.submitted','payout',$id,'Saque Pix R$ '.number_format($amount/100,2,',','.').' para chave mascarada '.$masked);
            try {
                $result=self::payoutClient()->withdraw($amount,$type,$key,$description,$idem);
                $db->run('UPDATE admin_payouts SET provider_tx_id=?,provider_job_id=?,status=? WHERE id=?',[$result['transaction_id'],$result['job_id'],'queued',$id]);
                self::reply(['id'=>$id,'status'=>'queued','provider_tx_id'=>$result['transaction_id']],202);
            } catch(\Throwable $e){
                // Unknown provider state: do not retry automatically. Idempotency is retained.
                $db->run("UPDATE admin_payouts SET status='unknown' WHERE id=?",[$id]);
                error_log('ARGUS Pix cashout submission uncertain: '.get_class($e));
                self::fail('Saque enviado com estado incerto. Verifique na MisticPay antes de qualquer nova tentativa. Protocolo '.$id,503);
            }
        }
        if($method==='POST'&&preg_match('~^/api/admin/payouts/([a-zA-Z0-9_-]+)/reconcile$~D',$path,$m)) {
            self::writeAllowed($actor,true);self::payoutAvailable($db);$row=$db->one('SELECT * FROM admin_payouts WHERE id=?',[$m[1]]);
            if(!$row||!$row['provider_tx_id'])self::fail('Saque sem transação consultável',404);
            $check=self::payoutClient()->status($row['provider_tx_id']);$status=['PENDENTE'=>'pending','COMPLETO'=>'paid','FALHA'=>'failed','CANCELADO'=>'cancelled','DEVOLVIDO'=>'refunded','DEVOLVIDO_PARCIAL'=>'partially_refunded'][$check['state']];
            $db->run('UPDATE admin_payouts SET status=?,checked_at=? WHERE id=?',[$status,self::now(),$row['id']]);
            self::audit($db,$actor,'payout.reconciled','payout',$row['id'],'Estado retornado pela MisticPay: '.$status);self::reply(['id'=>$row['id'],'status'=>$status]);
        }

        if($method==='POST'&&$path==='/api/admin/charges') {
            self::writeAllowed($actor);
            $data=self::input();
            $merchant=self::merchant($db,self::str($data,'merchant_id',4,120));
            if($merchant['status']!=='approved_live')self::fail('Empresa ainda não aprovada para emitir Pix real',403);
            $idem=self::str($data,'idempotency_key',12,128);
            self::audit($db,$actor,'charge.issue_requested','merchant',$merchant['id'],'Solicitação de Pix com idempotência '.substr(hash('sha256',$idem),0,16));
            LivePix::issueCharge($db,$merchant,$data,$idem);
        }
        if($method==='GET'&&preg_match('~^/api/admin/charges/([a-zA-Z0-9_-]+)$~D',$path,$idMatch)) {
            $charge=$db->one('SELECT id,merchant_id,amount_cents,commission_cents,payer_name,status,qr_copy,created_at,paid_at FROM b2b_live_pix WHERE id=?',[$idMatch[1]]);
            if(!$charge)self::fail('Cobrança não encontrada',404);
            self::reply(['id'=>$charge['id'],'merchant_id'=>$charge['merchant_id'],'amount_cents'=>(int)$charge['amount_cents'],'commission_estimate_cents'=>(int)$charge['commission_cents'],'payer_name'=>$charge['payer_name'],'status'=>$charge['status'],'pix_copy_paste'=>$charge['qr_copy'],'created_at'=>$charge['created_at'],'paid_at'=>$charge['paid_at']]);
        }
        if($method==='GET'&&$path==='/api/admin/overview'){
            $m=$db->one("SELECT COUNT(*) AS total,COALESCE(SUM(CASE WHEN status='approved_live' THEN 1 ELSE 0 END),0) AS active,COALESCE(SUM(CASE WHEN status='pending_review' THEN 1 ELSE 0 END),0) AS pending,COALESCE(SUM(CASE WHEN status='suspended' THEN 1 ELSE 0 END),0) AS suspended FROM b2b_merchants WHERE status!='approved_demo'");
            $p=$db->one("SELECT COUNT(*) AS total,COALESCE(SUM(CASE WHEN status='paid' THEN amount_cents ELSE 0 END),0) AS paid_cents,COALESCE(SUM(CASE WHEN status='paid' THEN commission_cents ELSE 0 END),0) AS commission_estimate_cents,COALESCE(SUM(CASE WHEN status='pending' OR status='unknown' THEN 1 ELSE 0 END),0) AS awaiting FROM b2b_live_pix");
            self::reply(['merchants'=>$m,'pix'=>$p,'integration'=>LivePix::readiness($db),'role'=>$actor['role'],'production_data_only'=>true]);
        }
        if($path==='/api/admin/merchants'){
            if($method==='GET'){
                self::reply($db->all('SELECT m.*, (SELECT COUNT(*) FROM b2b_live_pix p WHERE p.merchant_id=m.id) AS charges,(SELECT COUNT(*) FROM b2b_live_keys k WHERE k.merchant_id=m.id AND k.revoked_at IS NULL) AS active_keys FROM b2b_merchants m WHERE m.status!=\'approved_demo\' ORDER BY created_at DESC LIMIT 500'));
            }
            if($method==='POST'){
                self::writeAllowed($actor);$data=self::input();$legal=self::str($data,'legal_name',3,180);$cnpj=preg_replace('/\D/','',self::str($data,'cnpj',14,20));
                if(!self::validCnpj($cnpj))self::fail('CNPJ inválido',422);
                $email=self::email(self::str($data,'email',4,190));$recipient=self::email(self::str($data,'misticpay_email',4,190));
                $bps=$data['commission_bps']??150;if(!is_int($bps)||$bps<0||$bps>1000)self::fail('Comissão deve ser 0 a 10%',422);
                $id=Database::uid('mer');
                try{$db->transaction(function(Database $db)use($actor,$id,$legal,$cnpj,$email,$recipient,$bps){
                    $db->run('INSERT INTO b2b_merchants(id,legal_name,cnpj,email,misticpay_email,commission_bps,status,created_at) VALUES (?,?,?,?,?,?,?,?)',[$id,$legal,$cnpj,$email,$recipient,$bps,'pending_review',self::now()]);
                    self::audit($db,$actor,'merchant.created','merchant',$id,$legal);
                });}catch(PDOException $e){if($db->one('SELECT id FROM b2b_merchants WHERE cnpj=?',[$cnpj]))self::fail('CNPJ já cadastrado',409);throw $e;}
                self::reply(['id'=>$id,'status'=>'pending_review'],201);
            }
        }
        if($method==='POST'&&preg_match('~^/api/admin/merchants/([a-zA-Z0-9_-]+)/(approve|suspend|reject|reopen|update)$~D',$path,$match)){
            self::writeAllowed($actor);$id=$match[1];$action=$match[2];$body=self::input();$m=self::merchant($db,$id);
            if($action==='approve'){
                foreach(['kyb_verified','provider_approved','contract_signed','split_direction_confirmed'] as $flag)if(($body[$flag]??null)!==true)self::fail('É necessário confirmar: '.$flag,422);
                if(!filter_var($m['misticpay_email'],FILTER_VALIDATE_EMAIL))self::fail('Conta MisticPay do recebedor não definida',422);
                $db->transaction(function(Database $db)use($actor,$m,$id){
                    $db->run("UPDATE b2b_merchants SET status='approved_live',reviewed_at=? WHERE id=?",[self::now(),$id]);
                    self::audit($db,$actor,'merchant.approved','merchant',$id,'Responsável confirmou KYB, contrato, PSP e split; evidências devem ser arquivadas fora do banco');
                });self::reply(['ok'=>true,'status'=>'approved_live']);
            }
            if($action==='suspend'||$action==='reject'||$action==='reopen'){
                $target=['suspend'=>'suspended','reject'=>'rejected','reopen'=>'pending_review'][$action];
                if($action==='reopen'&&$m['status']!=='suspended'&&$m['status']!=='rejected')self::fail('Empresa não está suspensa/rejeitada',409);
                $reason=self::str($body,'reason',5,300);
                $db->transaction(function(Database $db)use($actor,$id,$target,$reason,$action){
                    $db->run('UPDATE b2b_merchants SET status=?,reviewed_at=? WHERE id=?',[$target,self::now(),$id]);
                    $db->run('UPDATE b2b_live_keys SET revoked_at=? WHERE merchant_id=? AND revoked_at IS NULL',[self::now(),$id]);
                    self::audit($db,$actor,'merchant.'.$action,'merchant',$id,$reason);
                });self::reply(['ok'=>true,'status'=>$target,'keys_revoked'=>true]);
            }
            if($action==='update'){
                $legal=self::str($body,'legal_name',3,180);$email=self::email(self::str($body,'email',4,190));$recipient=self::email(self::str($body,'misticpay_email',4,190));
                $bps=$body['commission_bps']??null;if(!is_int($bps)||$bps<0||$bps>1000)self::fail('Comissão fora de 0-10%',422);
                $changed=$recipient!==$m['misticpay_email'];
                $db->transaction(function(Database $db)use($actor,$id,$legal,$email,$recipient,$bps,$changed,$m){
                    $db->run('UPDATE b2b_merchants SET legal_name=?,email=?,misticpay_email=?,commission_bps=?,status=? WHERE id=?',
                        [$legal,$email,$recipient,$bps,$changed&&$m['status']==='approved_live'?'pending_review':$m['status'],$id]);
                    if($changed)$db->run('UPDATE b2b_live_keys SET revoked_at=? WHERE merchant_id=? AND revoked_at IS NULL',[self::now(),$id]);
                    self::audit($db,$actor,'merchant.updated','merchant',$id,'Dados bancários/contato e comissão alterados. Mudança de recebedor exige nova aprovação.');
                });self::reply(['ok'=>true,'reapproval_required'=>$changed]);
            }
        }
        if($method==='GET'&&$path==='/api/admin/keys'){
            self::reply($db->all('SELECT k.id,k.merchant_id,k.created_at,k.revoked_at,m.legal_name FROM b2b_live_keys k JOIN b2b_merchants m ON m.id=k.merchant_id ORDER BY k.created_at DESC LIMIT 300'));
        }
        if($method==='POST'&&preg_match('~^/api/admin/merchants/([a-zA-Z0-9_-]+)/keys$~D',$path,$m)){
            self::writeAllowed($actor);$merchant=self::merchant($db,$m[1]);if($merchant['status']!=='approved_live')self::fail('Empresa precisa estar aprovada',403);
            $key='arg_live_'.bin2hex(random_bytes(24));$id=Database::uid('lk');$db->transaction(function(Database $db)use($id,$key,$merchant,$actor){
                $db->run('INSERT INTO b2b_live_keys(id,merchant_id,key_hash,created_at,revoked_at) VALUES (?,?,?,?,?)',[$id,$merchant['id'],hash('sha256',$key),self::now(),null]);
                self::audit($db,$actor,'apikey.created','merchant',$merchant['id'],'Identificador da chave: '.$id);
            });self::reply(['id'=>$id,'api_key'=>$key,'message'=>'Copie e salve em local seguro: esta chave não poderá ser exibida novamente'],201);
        }
        if($method==='POST'&&preg_match('~^/api/admin/keys/([a-zA-Z0-9_-]+)/revoke$~D',$path,$m)){
            self::writeAllowed($actor);$db->transaction(function(Database $db)use($actor,$m){
                $key=$db->one('SELECT merchant_id FROM b2b_live_keys WHERE id=? AND revoked_at IS NULL',[$m[1]]);
                if(!$key)self::fail('Chave já revogada ou não encontrada',404);
                $db->run('UPDATE b2b_live_keys SET revoked_at=? WHERE id=?',[self::now(),$m[1]]);self::audit($db,$actor,'apikey.revoked','merchant',$key['merchant_id'],'Chave: '.$m[1]);
            });self::reply(['ok'=>true]);
        }
        if($method==='GET'&&$path==='/api/admin/charges'){
            $status=$_GET['status']??'all';if(!in_array($status,['all','creating','pending','paid','unknown','failed','expired'],true))self::fail('Filtro de status inválido');
            $merchant=$_GET['merchant']??'';if(!is_string($merchant)||strlen($merchant)>120)self::fail('Filtro de empresa inválido');
            $sql='SELECT p.id,p.merchant_id,p.amount_cents,p.commission_cents,p.description,p.payer_name,p.payer_document_last4,p.provider_tx_id,p.status,p.created_at,p.paid_at,p.checked_at,m.legal_name FROM b2b_live_pix p JOIN b2b_merchants m ON m.id=p.merchant_id WHERE 1=1';$params=[];
            if($status!=='all'){$sql.=' AND p.status=?';$params[]=$status;}
            if($merchant!==''){$sql.=' AND p.merchant_id=?';$params[]=$merchant;}
            self::reply($db->all($sql.' ORDER BY p.created_at DESC LIMIT 500',$params));
        }
        if($method==='POST'&&preg_match('~^/api/admin/charges/([a-zA-Z0-9_-]+)/reconcile$~D',$path,$m)){
            self::writeAllowed($actor);$payment=$db->one('SELECT * FROM b2b_live_pix WHERE id=?',[$m[1]]);if(!$payment)self::fail('Cobrança não encontrada',404);
            if(!$payment['provider_tx_id'])self::fail('Cobrança ainda não recebeu ID da MisticPay',409);
            LivePix::reconcile($db,$payment);self::audit($db,$actor,'pix.reconciled','charge',$payment['id'],'Consulta autenticada à MisticPay');self::reply(['ok'=>true,'charge'=>$db->one('SELECT id,status,paid_at,checked_at FROM b2b_live_pix WHERE id=?',[$m[1]])]);
        }
        if($method==='GET'&&$path==='/api/admin/blocks'){
            self::reply($db->all('SELECT b.id,b.merchant_id,b.document_last4,b.reason,b.created_at,b.released_at,m.legal_name FROM admin_payer_blocks b JOIN b2b_merchants m ON m.id=b.merchant_id ORDER BY b.created_at DESC LIMIT 400'));
        }
        if($method==='POST'&&$path==='/api/admin/blocks'){
            self::writeAllowed($actor);$body=self::input();$merchantId=self::str($body,'merchant_id',5,120);
            self::merchant($db,$merchantId);$doc=preg_replace('/\D/','',self::str($body,'payer_document',11,20));
            if(strlen($doc)!==11)self::fail('CPF do pagador inválido',422);
            $secret=(string)getenv('ARGUS_PAYER_HMAC_KEY');if(strlen($secret)<32)self::fail('Segredo de proteção de clientes não configurado',503);
            $hash=hash_hmac('sha256',$doc,$secret);$reason=self::str($body,'reason',5,300);
            $current=$db->one('SELECT id FROM admin_payer_blocks WHERE merchant_id=? AND document_hash=? AND released_at IS NULL',[$merchantId,$hash]);
            if($current)self::fail('Pagador já bloqueado',409);
            $id=Database::uid('block');$db->transaction(function(Database $db)use($actor,$id,$merchantId,$hash,$doc,$reason){
                $db->run('INSERT INTO admin_payer_blocks(id,merchant_id,document_hash,document_last4,reason,created_at,released_at) VALUES (?,?,?,?,?,?,?)',[$id,$merchantId,$hash,substr($doc,-4),$reason,self::now(),null]);
                self::audit($db,$actor,'payer.blocked','merchant',$merchantId,'CPF final '.substr($doc,-4).' · '.$reason);
            });self::reply(['id'=>$id,'ok'=>true],201);
        }
        if($method==='POST'&&preg_match('~^/api/admin/blocks/([a-zA-Z0-9_-]+)/release$~D',$path,$m)){
            self::writeAllowed($actor);$row=$db->one('SELECT * FROM admin_payer_blocks WHERE id=? AND released_at IS NULL',[$m[1]]);
            if(!$row)self::fail('Bloqueio inexistente ou já liberado',404);
            $db->transaction(function(Database $db)use($actor,$row){
                $db->run('UPDATE admin_payer_blocks SET released_at=? WHERE id=?',[self::now(),$row['id']]);
                self::audit($db,$actor,'payer.released','merchant',$row['merchant_id'],'CPF final '.$row['document_last4']);
            });self::reply(['ok'=>true]);
        }
        if($method==='GET'&&$path==='/api/admin/payers'){
            self::reply($db->all('SELECT p.merchant_id,m.legal_name,p.payer_name,p.payer_document_last4,COUNT(*) AS charge_count,COALESCE(SUM(CASE WHEN p.status=\'paid\' THEN p.amount_cents ELSE 0 END),0) AS paid_cents FROM b2b_live_pix p JOIN b2b_merchants m ON m.id=p.merchant_id GROUP BY p.merchant_id,m.legal_name,p.payer_name,p.payer_document_last4 ORDER BY paid_cents DESC LIMIT 250'));
        }
        if($method==='GET'&&$path==='/api/admin/reports'){
            $from=$_GET['from']??gmdate('Y-m-01');$to=$_GET['to']??gmdate('Y-m-d');
            foreach([$from,$to]as$date){if(!is_string($date)||!preg_match('/\A\d{4}-\d{2}-\d{2}\z/D',$date))self::fail('Período inválido');}
            if($from>$to)self::fail('Data inicial maior que final');
            self::reply(['from'=>$from,'to'=>$to,'daily'=>self::liveReport($db,$from,$to),'commission_type'=>'estimated_before_provider_fees']);
        }
        if($method==='GET'&&$path==='/api/admin/reports.csv'){
            $from=$_GET['from']??gmdate('Y-m-01');$to=$_GET['to']??gmdate('Y-m-d');
            foreach([$from,$to]as$date)if(!is_string($date)||!preg_match('/\A\d{4}-\d{2}-\d{2}\z/D',$date))self::fail('Período inválido');
            header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="argus-relatorio.csv"');header('Cache-Control: no-store');
            $f=fopen('php://output','w');fputcsv($f,['Data UTC','Transações','Volume emitido (centavos)','Volume pago (centavos)','Comissão estimada (centavos)'],';');
            foreach(self::liveReport($db,$from,$to)as$row)fputcsv($f,[$row['day'],$row['quantity'],$row['gross_cents'],$row['paid_cents'],$row['commission_estimate_cents']],';');fclose($f);exit;
        }
        if($method==='GET'&&$path==='/api/admin/audit'){
            self::reply($db->all('SELECT a.*,u.email AS actor_email FROM admin_audit a JOIN admin_users u ON u.id=a.actor_id ORDER BY a.created_at DESC LIMIT 300'));
        }
        if($method==='GET'&&$path==='/api/admin/users'){
            self::writeAllowed($actor,true);self::reply(array_map([self::class,'safeUser'],$db->all('SELECT * FROM admin_users ORDER BY created_at ASC')));
        }
        if($method==='POST'&&$path==='/api/admin/users'){
            self::writeAllowed($actor,true);$data=self::input();$email=self::email(self::str($data,'email',4,190));$name=self::str($data,'display_name',2,180);
            $role=self::str($data,'role',5,16);if(!in_array($role,['admin','analyst'],true))self::fail('Perfil inválido');
            $pwd=bin2hex(random_bytes(18));$id=Database::uid('adm');
            try{$db->transaction(function(Database $db)use($actor,$id,$email,$name,$role,$pwd){
                $db->run('INSERT INTO admin_users(id,email,display_name,password_hash,role,status,must_change_password,failed_logins,locked_until,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',[$id,$email,$name,password_hash($pwd,PASSWORD_DEFAULT),$role,'active',1,0,0,self::now()]);
                self::audit($db,$actor,'user.created','admin_user',$id,$email.' perfil '.$role);
            });}catch(PDOException $e){if($db->one('SELECT id FROM admin_users WHERE email=?',[$email]))self::fail('Usuário já cadastrado',409);throw $e;}
            self::reply(['id'=>$id,'temporary_password'=>$pwd,'message'=>'Entregue a senha ao usuário por canal seguro. Troca obrigatória ao entrar.'],201);
        }
        if($method==='POST'&&preg_match('~^/api/admin/users/([a-zA-Z0-9_-]+)/(suspend|activate|reset-password)$~D',$path,$m)){
            self::writeAllowed($actor,true);$id=$m[1];$action=$m[2];$target=$db->one('SELECT * FROM admin_users WHERE id=?',[$id]);if(!$target)self::fail('Usuário não encontrado',404);
            if($target['role']==='superadmin'||$target['id']===$actor['id'])self::fail('Conta do proprietário não pode ser modificada por esta ação',403);
            if($action==='reset-password'){$pwd=bin2hex(random_bytes(18));$db->transaction(function(Database $db)use($actor,$target,$pwd){$db->run('UPDATE admin_users SET password_hash=?,must_change_password=1,failed_logins=0,locked_until=0 WHERE id=?',[password_hash($pwd,PASSWORD_DEFAULT),$target['id']]);$db->run('DELETE FROM admin_sessions WHERE user_id=?',[$target['id']]);self::audit($db,$actor,'user.reset_password','admin_user',$target['id']);});self::reply(['temporary_password'=>$pwd,'message'=>'Exibida apenas uma vez']);}
            $status=$action==='activate'?'active':'suspended';$db->transaction(function(Database $db)use($actor,$target,$status,$action){$db->run('UPDATE admin_users SET status=? WHERE id=?',[$status,$target['id']]);$db->run('DELETE FROM admin_sessions WHERE user_id=?',[$target['id']]);self::audit($db,$actor,'user.'.$action,'admin_user',$target['id']);});self::reply(['ok'=>true,'status'=>$status]);
        }
        self::fail('Rota administrativa não encontrada',404);
    }
}
