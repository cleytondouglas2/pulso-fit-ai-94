<?php
declare(strict_types=1);
namespace ArgusPayments;

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/B2B.php';
require_once __DIR__ . '/Integrations/MisticPayHttpClient.php';
require_once __DIR__ . '/LivePix.php';
require_once __DIR__ . '/Admin.php';
require_once __DIR__ . '/Security2FA.php';
require_once __DIR__ . '/Integrations/MisticPayPayout.php';

use DateTimeImmutable;
use DateTimeZone;
use DomainException;
use PDOException;
use Throwable;

final class ApiError extends \RuntimeException
{
    public function __construct(string $message, public int $status = 400)
    { parent::__construct($message); }
}

final class Gateway
{
    private static Database $db;
    private static array $config;
    private const MERCHANT = 'merchant_demo';
    private const ALLOWED_METHODS = ['pix', 'card', 'boleto'];

    public static function dispatch(): void
    {
        self::$config = require dirname(__DIR__) . '/config.php';
        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        $path = rawurldecode((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH));
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('X-Frame-Options: SAMEORIGIN');
        try {
            // Real-operation console: legacy demo pages, test checkout and demo login are removed.
            if ($method === 'GET' && in_array($path, ['/', '/index.php', '/operacao', '/admin'], true)) {
                self::htmlFile('admin.html');
                return;
            }
            if ($method === 'GET' && $path === '/health') {
                try {
                    $probe = new Database(self::$config);
                    $probe->one('SELECT 1 AS result');
                    self::json(['ok'=>true,'mode'=>'operation','database'=>'connected']);
                } catch (Throwable $e) {
                    error_log('ARGUS health database unavailable: '.get_class($e));
                    self::json(['ok'=>false,'mode'=>'operation','database'=>'unavailable'],503);
                }
                return;
            }
            if (!str_starts_with($path, '/api/')) throw new ApiError('Rota não encontrada', 404);
            header('Cache-Control: no-store, private');
            if (in_array($method, ['POST','PUT','PATCH','DELETE'], true)) self::sameOrigin();
            // Only authenticated administrator API and provider-backed Pix API remain exposed.
            if (!str_starts_with($path, '/api/admin/') && !str_starts_with($path, '/api/live/')) {
                throw new ApiError('Endpoint de demonstração desativado',404);
            }
            self::$db = new Database(self::$config);
            self::$db->installAndSeed();
            if (str_starts_with($path, '/api/admin/')) {
                Admin::handle(self::$db,$method,$path);
            }
            LivePix::handle(self::$db,$method,$path);
        } catch (ApiError $e) {
            self::json(['detail' => $e->getMessage()], $e->status);
        } catch (\PDOException $e) {
            error_log('ARGUS Payments PHP erro de banco: ' . $e->getMessage());
            self::json(['detail'=>'Banco de dados indisponível. Ative pdo_sqlite ou pdo_mysql e confira a configuração.'], 503);
        } catch (Throwable $e) {
            error_log('ARGUS Payments PHP erro: ' . $e->getMessage());
            self::json(['detail'=>'Falha interna do servidor. Verifique os logs de PHP.'], 500);
        }
    }

    private static function json(mixed $payload, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    }

    private static function htmlFile(string $name): void
    {
        header('Content-Type: text/html; charset=utf-8');
        readfile(dirname(__DIR__) . '/public/static/' . $name);
    }

    private static function fail(string $msg, int $status = 400): never { throw new ApiError($msg, $status); }
    private static function matched(string $pattern, string $path): ?array
    {
        if (!preg_match($pattern, $path, $matches)) return null;
        return $matches;
    }

    private static function sameOrigin(): void
    {
        // As chaves bearer da API são server-to-server. Em cookies, o navegador é
        // protegido por SameSite=Strict, Origin/Referer e Fetch Metadata.
        if (str_starts_with($_SERVER['REQUEST_URI'] ?? '', '/api/v1/') || str_starts_with($_SERVER['REQUEST_URI'] ?? '', '/api/live/')) return;
        $site = strtolower($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '');
        if ($site !== '' && !in_array($site, ['same-origin','none'], true)) self::fail('Origem não autorizada', 403);
        $host = strtolower($_SERVER['HTTP_HOST'] ?? '');
        foreach (['HTTP_ORIGIN','HTTP_REFERER'] as $header) {
            if (empty($_SERVER[$header])) continue;
            $parts = parse_url($_SERVER[$header]);
            $originHost = strtolower(($parts['host'] ?? '') . (isset($parts['port']) ? ':' . $parts['port'] : ''));
            if (!$parts || !in_array($parts['scheme'] ?? '', ['http','https'], true) || !hash_equals($host,$originHost)) {
                self::fail('Origem não autorizada', 403);
            }
        }
    }

    private static function body(): array
    {
        $raw = file_get_contents('php://input');
        if ($raw === false || strlen($raw) > 32768) self::fail('Payload inválido ou excessivamente grande', 413);
        try { $data = json_decode($raw, true, 32, JSON_THROW_ON_ERROR); }
        catch (\JsonException $e) { self::fail('JSON inválido'); }
        if (!is_array($data) || array_is_list($data)) self::fail('Envie um objeto JSON');
        return $data;
    }

    private static function text(array $input, string $field, int $min, int $max): string
    {
        $val = $input[$field] ?? null;
        if (!is_string($val)) self::fail("Campo inválido: $field");
        $val = trim($val);
        $len = function_exists('mb_strlen') ? mb_strlen($val, 'UTF-8') : strlen($val);
        if ($len < $min || $len > $max) self::fail("O campo $field deve ter entre $min e $max caracteres");
        return $val;
    }

    private static function amount(array $input): int
    {
        $n = $input['amount_cents'] ?? null;
        if (!is_int($n) || $n < 100 || $n > 100_000_000) self::fail('O valor deve ser inteiro em centavos, de 100 até 100000000');
        return $n;
    }

    private static function email(array $input, string $field = 'email'): string
    {
        $email = strtolower(self::text($input, $field, 3, 190));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) self::fail('E-mail inválido');
        return $email;
    }

    private static function paymentPayload(array $input): array
    {
        $method = $input['method'] ?? null;
        if (!in_array($method, self::ALLOWED_METHODS, true)) self::fail('Método inválido');
        return [
            'amount_cents' => self::amount($input), 'method'=>$method,
            'customer_name'=>self::text($input,'customer_name',2,100),
            'customer_email'=>self::email($input,'customer_email'),
            'description'=>self::text($input,'description',2,140),
        ];
    }

    private static function merchant(): string
    {
        $token = $_COOKIE['arg_session'] ?? '';
        if (!is_string($token) || strlen($token) < 30) self::fail('Sessão não autenticada',401);
        $session = self::$db->one('SELECT merchant_id FROM sessions WHERE secret_hash=? AND expires_at>?',
            [hash('sha256',$token),time()]);
        if (!$session) self::fail('Sessão expirada. Acesse a demonstração novamente.',401);
        return $session['merchant_id'];
    }

    private static function apiMerchant(): string
    {
        $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
        if (!is_string($auth) || !preg_match('/^Bearer\s+(arg_test_[A-Za-z0-9_\-]+)$/', $auth, $match)) {
            self::fail('Envie Authorization: Bearer arg_test_...',401);
        }
        $record = self::$db->one('SELECT merchant_id FROM api_keys WHERE key_hash=? AND revoked_at IS NULL',
            [hash('sha256',$match[1])]);
        if (!$record) self::fail('Chave de API inválida ou revogada',401);
        return $record['merchant_id'];
    }

    private static function secureCookie(): bool
    {
        return (bool) self::$config['cookie_secure'] || (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    }

    private static function sessionCookie(string $token): void
    {
        setcookie('arg_session', $token, [
            'expires'=>time()+86400, 'path'=>'/', 'secure'=>self::secureCookie(),
            'httponly'=>true, 'samesite'=>'Strict',
        ]);
    }

    private static function createPayment(string $merchantId, array $data, ?string $slug = null, string $status = 'pending'): array
    {
        $id = Database::uid('pay');
        $stamp = Database::stamp();
        self::$db->run('INSERT INTO payments(id,merchant_id,amount_cents,method,customer_name,customer_email,description,status,provider,created_at,paid_at,link_slug,refunded_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
            [$id,$merchantId,$data['amount_cents'],$data['method'],$data['customer_name'],$data['customer_email'],$data['description'],$status,'sandbox',$stamp,$status==='paid' ? $stamp : null,$slug,null]);
        self::$db->ensureCustomer($merchantId,$data['customer_name'],$data['customer_email']);
        self::$db->audit($merchantId,'payment.created',"$id: {$data['method']}, {$data['amount_cents']} centavos — $status (SANDBOX)");
        return self::$db->one('SELECT * FROM payments WHERE id=? AND merchant_id=?',[$id,$merchantId]);
    }

    private static function api(string $method, string $path): void
    {
        if (str_starts_with($path, '/api/live/')) {
            LivePix::handle(self::$db, $method, $path);
            return;
        }
        if (str_starts_with($path, '/api/b2b/')) {
            self::merchant(); // Demo operator session; NOT individual merchant authentication.
            B2B::handle(self::$db, $method, $path);
            return;
        }

        // Autenticação de demonstração: nunca usar este endpoint como login comercial.
        if ($path === '/api/auth/demo' && $method === 'POST') {
            $token = Database::slug() . Database::slug() . Database::slug();
            self::$db->run('INSERT INTO sessions(secret_hash,merchant_id,expires_at) VALUES (?,?,?)',
                [hash('sha256',$token),self::MERCHANT,time()+86400]);
            self::sessionCookie($token);
            self::json(['ok'=>true,'merchant'=>'Loja Aurora','sandbox'=>true]);
            return;
        }
        if ($path === '/api/auth/logout' && $method === 'POST') {
            $token = $_COOKIE['arg_session'] ?? '';
            if (is_string($token) && $token !== '') self::$db->run('DELETE FROM sessions WHERE secret_hash=?',[hash('sha256',$token)]);
            setcookie('arg_session', '', ['expires'=>time()-3600,'path'=>'/','secure'=>self::secureCookie(),'httponly'=>true,'samesite'=>'Strict']);
            self::json(['ok'=>true]);
            return;
        }

        // API externa autenticada por token bearer. Somente cobranças sandbox.
        if ($method === 'POST' && $path === '/api/v1/charges') {
            self::apiChargeCreate(); return;
        }
        if ($method === 'GET' && ($m = self::matched('~^/api/v1/charges/([a-zA-Z0-9_-]+)$~',$path))) {
            $merchant = self::apiMerchant();
            $payment = self::$db->one('SELECT * FROM payments WHERE id=? AND merchant_id=?',[$m[1],$merchant]);
            if (!$payment) self::fail('Cobrança não encontrada',404);
            self::json($payment); return;
        }

        // Links públicos. Checkout pago é simulado: não existe PSP nem boleto real.
        if ($method === 'GET' && ($m = self::matched('~^/api/public/links/([a-zA-Z0-9_-]+)$~',$path))) {
            $link = self::$db->one('SELECT slug,title,amount_cents,active FROM links WHERE slug=?',[$m[1]]);
            if (!$link || !$link['active']) self::fail('Esta cobrança não está disponível',404);
            self::json($link + ['sandbox'=>true,'payment_methods'=>self::ALLOWED_METHODS]); return;
        }
        if ($method === 'POST' && ($m = self::matched('~^/api/public/links/([a-zA-Z0-9_-]+)/simulate$~',$path))) {
            $body = self::body();
            $data = [
                'customer_name'=>self::text($body,'customer_name',2,100),
                'customer_email'=>self::email($body,'customer_email'),
                'method'=>$body['method'] ?? null,
            ];
            if (!in_array($data['method'],self::ALLOWED_METHODS,true)) self::fail('Método inválido');
            $out = self::$db->transaction(function () use ($m,$data) {
                $link = self::$db->one('SELECT * FROM links WHERE slug=? AND active=1',[$m[1]]);
                if (!$link) self::fail('Link indisponível',404);
                $payment = self::createPayment($link['merchant_id'],$data + ['amount_cents'=>(int)$link['amount_cents'],'description'=>$link['title']],$m[1],'paid');
                self::$db->audit($link['merchant_id'],'checkout.sandbox_completed',$payment['id']);
                return ['payment_id'=>$payment['id'],'status'=>'paid','sandbox'=>true,'message'=>'Pagamento simulado. Nenhum valor foi transferido.'];
            });
            self::json($out,201); return;
        }

        $merchant = self::merchant();
        if ($method === 'GET' && $path === '/api/me') {
            $row = self::$db->one('SELECT id,business,email FROM merchants WHERE id=?',[$merchant]);
            self::json($row + ['sandbox'=>true]); return;
        }
        if ($method === 'GET' && $path === '/api/overview') {
            self::json(self::overview($merchant)); return;
        }
        if ($path === '/api/payments') {
            if ($method === 'GET') {
                $params = [$merchant];
                $q = 'SELECT * FROM payments WHERE merchant_id=?';
                foreach (['method'=>self::ALLOWED_METHODS,'status'=>['paid','pending','failed','refunded']] as $key=>$values) {
                    $value = $_GET[$key] ?? 'all';
                    if ($value !== 'all' && $value !== '') {
                        if (!is_string($value) || !in_array($value,$values,true)) self::fail('Filtro inválido');
                        $q .= " AND $key=?"; $params[] = $value;
                    }
                }
                self::json(self::$db->all($q.' ORDER BY created_at DESC LIMIT 200',$params)); return;
            }
            if ($method === 'POST') {
                $data = self::paymentPayload(self::body());
                self::json(self::$db->transaction(fn() => self::createPayment($merchant,$data)),201); return;
            }
        }
        if ($method === 'POST' && ($m = self::matched('~^/api/payments/([a-zA-Z0-9_-]+)/(settle|refund)$~',$path))) {
            $out = self::$db->transaction(function () use ($m,$merchant) {
                $payment = self::$db->one('SELECT * FROM payments WHERE id=? AND merchant_id=?',[$m[1],$merchant]);
                if (!$payment) self::fail('Cobrança não encontrada',404);
                if ($m[2] === 'settle') {
                    if ($payment['status'] !== 'pending') self::fail('Somente cobranças pendentes podem ser simuladas como pagas',409);
                    self::$db->run("UPDATE payments SET status='paid',paid_at=? WHERE id=? AND merchant_id=? AND status='pending'",[Database::stamp(),$m[1],$merchant]);
                    self::$db->audit($merchant,'payment.sandbox_approved',$m[1]);
                    return ['ok'=>true,'status'=>'paid','sandbox'=>true];
                }
                if ($payment['status'] !== 'paid') self::fail('Somente pagamentos aprovados podem ser estornados',409);
                self::$db->run("UPDATE payments SET status='refunded',refunded_at=? WHERE id=? AND merchant_id=? AND status='paid'",[Database::stamp(),$m[1],$merchant]);
                self::$db->audit($merchant,'payment.sandbox_refunded',$m[1]);
                return ['ok'=>true,'status'=>'refunded','sandbox'=>true];
            });
            self::json($out); return;
        }
        if ($path === '/api/customers') {
            if ($method === 'GET') {
                self::json(self::$db->all("SELECT c.*, COUNT(p.id) AS payments_count, COALESCE(SUM(CASE WHEN p.status='paid' THEN p.amount_cents ELSE 0 END),0) AS total_cents FROM customers c LEFT JOIN payments p ON c.email=p.customer_email AND c.merchant_id=p.merchant_id WHERE c.merchant_id=? GROUP BY c.id,c.merchant_id,c.name,c.email,c.created_at ORDER BY c.created_at DESC",[$merchant])); return;
            }
            if ($method === 'POST') {
                $body = self::body(); $name = self::text($body,'name',2,100); $email=self::email($body);
                if (self::$db->one('SELECT id FROM customers WHERE merchant_id=? AND email=?',[$merchant,$email])) self::fail('Este e-mail já está cadastrado',409);
                self::$db->transaction(function () use ($merchant,$name,$email) {
                    self::$db->run('INSERT INTO customers(id,merchant_id,name,email,created_at) VALUES (?,?,?,?,?)', [Database::uid('cus'),$merchant,$name,$email,Database::stamp()]);
                    self::$db->audit($merchant,'customer.created',$email);
                });
                self::json(['ok'=>true],201); return;
            }
        }
        if ($path === '/api/links') {
            if ($method === 'GET') {
                self::json(self::$db->all('SELECT l.*,COUNT(p.id) AS usage_count FROM links l LEFT JOIN payments p ON p.link_slug=l.slug AND p.merchant_id=l.merchant_id WHERE l.merchant_id=? GROUP BY l.slug,l.merchant_id,l.title,l.amount_cents,l.active,l.created_at ORDER BY l.created_at DESC',[$merchant])); return;
            }
            if ($method === 'POST') {
                $body = self::body(); $title=self::text($body,'title',3,100); $amount=self::amount($body);
                $slug=Database::slug();
                self::$db->transaction(function () use ($merchant,$title,$amount,$slug) {
                    self::$db->run('INSERT INTO links(slug,merchant_id,title,amount_cents,active,created_at) VALUES (?,?,?,?,?,?)',[$slug,$merchant,$title,$amount,1,Database::stamp()]);
                    self::$db->audit($merchant,'link.created',$slug);
                });
                self::json(['slug'=>$slug,'title'=>$title,'amount_cents'=>$amount,'active'=>1],201); return;
            }
        }
        if ($method === 'POST' && ($m = self::matched('~^/api/links/([a-zA-Z0-9_-]+)/toggle$~',$path))) {
            $out = self::$db->transaction(function () use ($m,$merchant) {
                $link=self::$db->one('SELECT * FROM links WHERE slug=? AND merchant_id=?',[$m[1],$merchant]);
                if (!$link) self::fail('Link não encontrado',404);
                $active=(int)!((bool)$link['active']);
                self::$db->run('UPDATE links SET active=? WHERE slug=? AND merchant_id=?',[$active,$m[1],$merchant]);
                self::$db->audit($merchant,'link.updated',$m[1].' active='.$active);
                return ['ok'=>true,'active'=>$active];
            });
            self::json($out); return;
        }
        if ($path === '/api/subscriptions') {
            if ($method === 'GET') {
                self::json(self::$db->all('SELECT * FROM subscriptions WHERE merchant_id=? ORDER BY created_at DESC',[$merchant])); return;
            }
            if ($method === 'POST') {
                $body=self::body(); $name=self::text($body,'name',2,100);$email=self::email($body);
                $plan=self::text($body,'plan',2,80);$amount=self::amount($body);$freq=$body['frequency']??'monthly';
                if (!in_array($freq,['weekly','monthly','yearly'],true)) self::fail('Recorrência inválida');
                $days=['weekly'=>7,'monthly'=>30,'yearly'=>365][$freq];$id=Database::uid('sub');
                self::$db->transaction(function () use ($id,$merchant,$name,$email,$plan,$amount,$freq,$days) {
                    self::$db->run('INSERT INTO subscriptions(id,merchant_id,name,email,plan,amount_cents,frequency,status,next_charge,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
                        [$id,$merchant,$name,$email,$plan,$amount,$freq,'active',gmdate('Y-m-d',time()+$days*86400),Database::stamp()]);
                    self::$db->audit($merchant,'subscription.created',$id);
                });
                self::json(['id'=>$id,'status'=>'active','sandbox'=>true],201); return;
            }
        }
        if ($method === 'POST' && ($m = self::matched('~^/api/subscriptions/([a-zA-Z0-9_-]+)/toggle$~',$path))) {
            $out=self::$db->transaction(function () use ($m,$merchant) {
                $sub=self::$db->one('SELECT * FROM subscriptions WHERE id=? AND merchant_id=?',[$m[1],$merchant]);
                if (!$sub) self::fail('Assinatura não encontrada',404);
                $status=$sub['status']==='active'?'paused':'active';
                self::$db->run('UPDATE subscriptions SET status=? WHERE id=? AND merchant_id=?',[$status,$m[1],$merchant]);
                self::$db->audit($merchant,'subscription.updated',$m[1].' '.$status);
                return ['status'=>$status];
            });
            self::json($out); return;
        }
        if ($path === '/api/splits') {
            if ($method === 'GET') {
                self::json(self::$db->all('SELECT * FROM split_rules WHERE merchant_id=? ORDER BY created_at DESC',[$merchant])); return;
            }
            if ($method === 'POST') {
                $body=self::body(); $name=self::text($body,'recipient',3,120); $percent=$body['percent']??null;
                if (!is_int($percent) || $percent<1 || $percent>100) self::fail('Percentual inválido');
                $out=self::$db->transaction(function () use ($merchant,$name,$percent) {
                    // No MySQL, serializa alterações de split para respeitar o limite de 100%.
                    if (self::$db->driver() === 'mysql') self::$db->one('SELECT id FROM merchants WHERE id=? FOR UPDATE',[$merchant]);
                    $total=(int)(self::$db->one('SELECT COALESCE(SUM(percent),0) AS total FROM split_rules WHERE merchant_id=?',[$merchant])['total']??0);
                    if ($total + $percent > 100) self::fail('O total das regras não pode ultrapassar 100%. Disponível: '.(100-$total).'%.',409);
                    $id=Database::uid('split');
                    self::$db->run('INSERT INTO split_rules(id,merchant_id,recipient,percent,created_at) VALUES (?,?,?,?,?)',[$id,$merchant,$name,$percent,Database::stamp()]);
                    self::$db->audit($merchant,'split.created',$name.' '.$percent.'% (simulado)');
                    return ['id'=>$id];
                });
                self::json($out,201); return;
            }
        }
        if ($method === 'DELETE' && ($m = self::matched('~^/api/splits/([a-zA-Z0-9_-]+)$~',$path))) {
            self::$db->transaction(function () use ($merchant,$m) {
                $count=self::$db->run('DELETE FROM split_rules WHERE id=? AND merchant_id=?',[$m[1],$merchant])->rowCount();
                if (!$count) self::fail('Regra não encontrada',404);
                self::$db->audit($merchant,'split.deleted',$m[1]);
            });
            self::json(['ok'=>true]); return;
        }
        if ($path === '/api/keys') {
            if ($method === 'GET') {
                self::json(self::$db->all('SELECT id,label,prefix,created_at,revoked_at FROM api_keys WHERE merchant_id=? ORDER BY created_at DESC',[$merchant])); return;
            }
            if ($method === 'POST') {
                $body=self::body();$label=self::text($body,'label',2,50);
                $secret='arg_test_'.Database::slug().Database::slug().Database::slug();$id=Database::uid('key');
                self::$db->transaction(function () use ($merchant,$label,$secret,$id) {
                    self::$db->run('INSERT INTO api_keys(id,merchant_id,label,key_hash,prefix,created_at,revoked_at) VALUES (?,?,?,?,?,?,?)',
                        [$id,$merchant,$label,hash('sha256',$secret),substr($secret,0,17).'…',Database::stamp(),null]);
                    self::$db->audit($merchant,'api_key.created',$label);
                });
                self::json(['id'=>$id,'key'=>$secret,'warning'=>'Copie agora. A chave completa não poderá ser consultada novamente.'],201);return;
            }
        }
        if ($method === 'DELETE' && ($m = self::matched('~^/api/keys/([a-zA-Z0-9_-]+)$~',$path))) {
            self::$db->transaction(function () use ($merchant,$m) {
                $changed=self::$db->run('UPDATE api_keys SET revoked_at=? WHERE id=? AND merchant_id=? AND revoked_at IS NULL',[Database::stamp(),$m[1],$merchant])->rowCount();
                if (!$changed) self::fail('Chave inexistente ou já revogada',404);
                self::$db->audit($merchant,'api_key.revoked',$m[1]);
            });
            self::json(['ok'=>true]);return;
        }
        if ($method === 'GET' && $path === '/api/events') {
            self::json(self::$db->all('SELECT * FROM events WHERE merchant_id=? ORDER BY created_at DESC LIMIT 100',[$merchant]));return;
        }
        if ($method === 'GET' && $path === '/api/reports/payments.csv') {
            self::csv($merchant);return;
        }
        self::fail('Rota não encontrada',404);
    }

    private static function apiChargeCreate(): void
    {
        $merchant = self::apiMerchant();
        $key = $_SERVER['HTTP_IDEMPOTENCY_KEY'] ?? '';
        if (!is_string($key) || strlen($key)<8 || strlen($key)>128) self::fail('Idempotency-Key obrigatório (8 a 128 caracteres)');
        $data = self::paymentPayload(self::body());
        // Hash canônico independente da ordem das chaves JSON no pedido.
        $bodyHash = hash('sha256',json_encode($data,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE));
        $keyHash = hash('sha256',$key);
        try {
            $payment=self::$db->transaction(function () use ($merchant,$bodyHash,$keyHash,$data) {
                $old = self::$db->one('SELECT payment_id,body_hash FROM idempotency WHERE merchant_id=? AND key_hash=?',[$merchant,$keyHash]);
                if ($old) {
                    if (!hash_equals($old['body_hash'],$bodyHash)) self::fail('Idempotency-Key reutilizada com corpo diferente',409);
                    return self::$db->one('SELECT * FROM payments WHERE id=? AND merchant_id=?',[$old['payment_id'],$merchant]);
                }
                $created=self::createPayment($merchant,$data);
                self::$db->run('INSERT INTO idempotency(merchant_id,key_hash,body_hash,payment_id) VALUES (?,?,?,?)',[$merchant,$keyHash,$bodyHash,$created['id']]);
                return $created;
            });
        } catch (PDOException $ex) {
            // Se outro processo inseriu a mesma chave em paralelo, recupera sua cobrança.
            $old=self::$db->one('SELECT payment_id,body_hash FROM idempotency WHERE merchant_id=? AND key_hash=?',[$merchant,$keyHash]);
            if (!$old) throw $ex;
            if (!hash_equals($old['body_hash'],$bodyHash)) self::fail('Idempotency-Key reutilizada com corpo diferente',409);
            $payment=self::$db->one('SELECT * FROM payments WHERE id=? AND merchant_id=?',[$old['payment_id'],$merchant]);
        }
        self::json($payment,201);
    }

    private static function overview(string $merchant): array
    {
        $payments=self::$db->all('SELECT * FROM payments WHERE merchant_id=? ORDER BY created_at DESC',[$merchant]);
        $paid=array_values(array_filter($payments,fn($p)=>$p['status']==='paid'));
        $pending=array_values(array_filter($payments,fn($p)=>$p['status']==='pending'));
        $revenue=array_sum(array_map(fn($p)=>(int)$p['amount_cents'],$paid));
        $pendingCents=array_sum(array_map(fn($p)=>(int)$p['amount_cents'],$pending));
        $breakdown=['pix'=>0,'card'=>0,'boleto'=>0];
        foreach ($paid as $p) $breakdown[$p['method']] += (int)$p['amount_cents'];
        $today=new DateTimeImmutable('today',new DateTimeZone('UTC'));
        $daily=[];
        for ($i=13;$i>=0;$i--) {
            $date=$today->modify("-$i days")->format('Y-m-d');
            $items=array_filter($paid,fn($p)=>substr($p['created_at'],0,10)===$date);
            $daily[]=['date'=>$date,'value'=>array_sum(array_map(fn($p)=>(int)$p['amount_cents'],$items)),'count'=>count($items)];
        }
        $total=count($payments);$approved=count($paid);
        $share=$revenue ? (int)round($breakdown['pix']/$revenue*100) : 0;
        $active=(int)(self::$db->one("SELECT COUNT(*) AS c FROM subscriptions WHERE merchant_id=? AND status='active'",[$merchant])['c']??0);
        $customers=(int)(self::$db->one('SELECT COUNT(*) AS c FROM customers WHERE merchant_id=?',[$merchant])['c']??0);
        return [
            'sandbox'=>true,'revenue_cents'=>$revenue,'pending_cents'=>$pendingCents,
            'payments_count'=>$total,'paid_count'=>$approved,'approval_rate'=>$total ? round($approved/$total*100,1):0,
            'average_ticket_cents'=>$approved ? (int)round($revenue/$approved):0,
            'active_subscriptions'=>$active,'customers_count'=>$customers,'daily'=>$daily,'breakdown'=>$breakdown,
            'recent'=>array_slice($payments,0,7),'insights'=>[
                ['title'=>'Seu Pix em destaque','body'=>"$share% do volume aprovado veio do Pix no período dos dados apresentados.",'icon'=>'zap'],
                ['title'=>'Acompanhe cobranças pendentes','body'=>count($pending).' cobranças estão aguardando conclusão. Organize lembretes antes do vencimento.','icon'=>'clock'],
                ['title'=>'Experiência de checkout','body'=>'Links compartilháveis reduzem etapas na jornada de pagamento. Faça testes no ambiente sandbox.','icon'=>'sparkles'],
            ],
        ];
    }

    private static function csv(string $merchant): void
    {
        $rows=self::$db->all('SELECT id,amount_cents,method,status,customer_name,customer_email,description,created_at,paid_at FROM payments WHERE merchant_id=? ORDER BY created_at DESC',[$merchant]);
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="argus-payments-transacoes-demo.csv"');
        $out=fopen('php://output','wb');
        $fields=['id','amount_cents','method','status','customer_name','customer_email','description','created_at','paid_at'];
        fputcsv($out,$fields,',','"','\\');
        foreach ($rows as $row) {
            $line=[];
            foreach ($fields as $field) {
                $value=(string)($row[$field]??'');
                if (preg_match('/^[=+\-@\t\r]/',$value)) $value="'".$value;
                $line[]=$value;
            }
            fputcsv($out,$line,',','"','\\');
        }
        fclose($out);
    }
}
