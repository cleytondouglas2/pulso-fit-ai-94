<?php
declare(strict_types=1);
namespace ArgusPayments;

use ArgusPayments\Integrations\MisticPayHttpClient;

/**
 * Strictly segregated LIVE API. Does not reuse the demo login, payment status
 * mutation endpoints or demo ledger. No transfers/refunds are ever initiated.
 */
final class LivePix
{
    public static function readiness(Database $db): array
    {
        $key = (string)getenv('ARGUS_MISTICPAY_PK');
        $secret = (string)getenv('ARGUS_MISTICPAY_SK');
        $base = (string)getenv('ARGUS_PUBLIC_BASE_URL');
        $token = (string)getenv('ARGUS_MISTICPAY_WEBHOOK_TOKEN');
        $operator = (string)getenv('ARGUS_LIVE_OPERATOR_TOKEN');
        $shared = in_array(strtolower((string)getenv('ARGUS_PGSQL_SHARED')), ['1','yes','true'], true);
        $temporaryPilot = $shared && $db->driver() === 'pgsql' && self::temporaryPilotAuthorized();
        $checks = [
            'explicit_activation'=>getenv('ARGUS_MISTICPAY_MODE') === 'live',
            'persistent_database'=>in_array($db->driver(), ['mysql','pgsql'], true),
            // Pilot excepcional do proprietario: no maximo R$ 100 por Pix,
            // expira antes do banco gratis. NAO substitui backup duravel.
            // A API real ainda exige aprovacao KYB individual e chave por lojista.
            'storage_policy'=>!$shared || $temporaryPilot,
            'provider_create_read_key'=>str_starts_with($key,'pk_') && strlen($key)>=12 && str_starts_with($secret,'sk_') && strlen($secret)>=12,
            'split_direction_authorized'=>getenv('ARGUS_MISTICPAY_SPLIT_MODE') === 'platform_to_merchant',
            'provider_split_confirmed'=>getenv('ARGUS_MISTICPAY_SPLIT_CONFIRMED') === 'yes',
            'strong_operator_secret'=>strlen($operator)>=32,
            'protected_webhook'=>strlen($token)>=32,
            'https_callback'=>str_starts_with($base,'https://') && filter_var($base,FILTER_VALIDATE_URL)!==false,
        ];
        return ['ready'=>!in_array(false,$checks,true),'checks'=>$checks,
            'provider'=>'MisticPay', 'api_family'=>'transactions-v1',
            'livemode'=>(getenv('ARGUS_MISTICPAY_MODE') === 'live'),
            'shared_database_risk'=>$shared,
            'temporary_pilot'=>$temporaryPilot,
            'temporary_pilot_expires_at'=>$temporaryPilot?'2026-12-10T00:00:00Z':null,
            'temporary_pilot_max_charge_cents'=>$temporaryPilot?10000:null];
    }

    public static function temporaryPilotAuthorized(?int $now=null): bool
    {
        // Explicit, time-boxed opt-in. A data final e FIXA no codigo, nao em env.
        // Requer aceite presente na Render; ambiente PostgreSQL sera verificado em readiness().
        $ack = getenv('ARGUS_TEMPORARY_PG_LIVE_ACK') === 'I_ACCEPT_TEMPORARY_RISK';
        return $ack && ($now ?? time()) < strtotime('2026-12-10T00:00:00Z');
    }

    private static function requireReady(Database $db): void
    {
        if (!self::readiness($db)['ready']) throw new ApiError('Conexão financeira ainda não configurada para produção',503);
    }
    private static function authenticatedOperator(): void
    {
        $expected = (string)getenv('ARGUS_LIVE_OPERATOR_TOKEN');
        $given = self::bearer();
        if (strlen($expected)<32 || !hash_equals($expected,$given)) throw new ApiError('Acesso operacional negado',401);
    }
    private static function bearer(): string
    {
        $value = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
        if (!is_string($value) || !preg_match('/^Bearer ([A-Za-z0-9_-]{24,140})$/D', $value,$m)) throw new ApiError('Authorization Bearer obrigatório',401);
        return $m[1];
    }
    private static function merchantAuth(Database $db): array
    {
        $token=self::bearer();
        if (!preg_match('/^arg_live_[a-f0-9]{48}$/D',$token)) throw new ApiError('Chave de lojista inválida',401);
        $row=$db->one("SELECT m.* FROM b2b_live_keys k JOIN b2b_merchants m ON m.id=k.merchant_id WHERE k.key_hash=? AND k.revoked_at IS NULL AND m.status='approved_live'",[hash('sha256',$token)]);
        if (!$row) throw new ApiError('Chave sem permissão',403);
        return $row;
    }
    private static function input(int $limit=8192): array
    {
        $raw=file_get_contents('php://input');
        if (!is_string($raw)||strlen($raw)>$limit) throw new ApiError('Requisição muito grande',413);
        try {$data=json_decode($raw,true,20,JSON_THROW_ON_ERROR);}catch(\JsonException){throw new ApiError('JSON inválido');}
        if (!is_array($data)||array_is_list($data)) throw new ApiError('Objeto JSON obrigatório');
        return $data;
    }
    private static function str(array $input,string $name,int $min,int $max): string
    {
        $v=$input[$name]??null;
        if(!is_string($v)||strlen(trim($v))<$min||strlen(trim($v))>$max) throw new ApiError("Campo $name inválido");
        return trim($v);
    }
    private static function json(mixed $value,int $status=200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode($value,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
        exit;
    }
    private static function client(): MisticPayHttpClient
    {
        return new MisticPayHttpClient((string)getenv('ARGUS_MISTICPAY_PK'),(string)getenv('ARGUS_MISTICPAY_SK'));
    }
    private static function publicCharge(array $c): array
    {
        return ['id'=>$c['id'],'merchant_id'=>$c['merchant_id'],'amount_cents'=>(int)$c['amount_cents'],
            'commission_estimate_cents'=>(int)$c['commission_cents'],
            'provider_cost_cents'=>null,'status'=>$c['status'],
            'pix_copy_paste'=>$c['qr_copy'] ?: null,
            'created_at'=>$c['created_at'],'paid_at'=>$c['paid_at']];
    }
    private static function audit(Database $db,string $chargeId,string $type,string $text): void
    {
        $db->run('INSERT INTO b2b_live_events(id,charge_id,type,note,created_at) VALUES (?,?,?,?,?)',
            [Database::uid('le'),$chargeId,$type,substr($text,0,300),Database::stamp()]);
    }

    public static function handle(Database $db,string $method,string $path): void
    {
        // Operator routes have a distinct secret. Never use the demonstration cookie.
        if ($method==='GET' && $path==='/api/live/operator/readiness') {
            self::authenticatedOperator();
            self::json(self::readiness($db));
        }
        if ($method==='POST'&&preg_match('~^/api/live/operator/merchants/([a-zA-Z0-9_-]+)/activate$~',$path,$m)) {
            self::authenticatedOperator();self::requireReady($db);
            $body=self::input();
            foreach (['kyb_verified','provider_approved','contract_signed','split_direction_confirmed'] as $flag) {
                if(($body[$flag]??false)!==true) throw new ApiError('É necessária comprovação: '.$flag,422);
            }
            $merchant=$db->one('SELECT * FROM b2b_merchants WHERE id=?',[$m[1]]);
            if(!$merchant)throw new ApiError('Lojista não encontrado',404);
            if (!filter_var($merchant['misticpay_email'],FILTER_VALIDATE_EMAIL))throw new ApiError('Conta recebedora MisticPay ausente',409);
            $db->run("UPDATE b2b_merchants SET status='approved_live',reviewed_at=? WHERE id=?",[Database::stamp(),$m[1]]);
            $db->run('INSERT INTO b2b_events(id,merchant_id,type,note,created_at) VALUES (?,?,?,?,?)',[
                Database::uid('bev'),$m[1],'merchant.activated_live','Aprovação declarada pelo operador autorizado; guardar comprovantes de KYB fora deste banco',Database::stamp()]);
            self::json(['ok'=>true,'merchant_id'=>$m[1],'status'=>'approved_live']);
        }
        if ($method==='POST'&&preg_match('~^/api/live/operator/merchants/([a-zA-Z0-9_-]+)/keys$~',$path,$m)) {
            self::authenticatedOperator();self::requireReady($db);
            $row=$db->one("SELECT id FROM b2b_merchants WHERE id=? AND status='approved_live'",[$m[1]]);
            if (!$row) throw new ApiError('Lojista ainda não aprovado em produção',403);
            $key='arg_live_'.bin2hex(random_bytes(24));
            $keyId=Database::uid('lk');
            $db->run('INSERT INTO b2b_live_keys(id,merchant_id,key_hash,created_at,revoked_at) VALUES (?,?,?,?,?)',[
                $keyId,$m[1],hash('sha256',$key),Database::stamp(),null]);
            self::json(['key_id'=>$keyId,'api_key'=>$key,'message'=>'Salve agora: esta chave não será exibida novamente'],201);
        }
        if ($method==='POST'&&preg_match('~^/api/live/operator/keys/([a-zA-Z0-9_-]+)/revoke$~',$path,$m)) {
            self::authenticatedOperator();
            $db->run('UPDATE b2b_live_keys SET revoked_at=? WHERE id=? AND revoked_at IS NULL',[Database::stamp(),$m[1]]);
            self::json(['ok'=>true]);
        }
        if ($method==='POST' && $path==='/api/live/pix/charges') {
            self::requireReady($db);
            $merchant=self::merchantAuth($db);
            $body=self::input();
            $amount=$body['amount_cents']??null;
            if (!is_int($amount)||$amount<100||$amount>100000000)throw new ApiError('Valor inválido (centavos)');
            if (self::readiness($db)['temporary_pilot'] && $amount>10000) {
                throw new ApiError('Piloto temporário: limite de R$ 100,00 por cobrança Pix',422);
            }
            $name=self::str($body,'payer_name',2,120);
            $doc=preg_replace('/\D/','',self::str($body,'payer_document',11,20));
            if(strlen($doc)!==11)throw new ApiError('CPF do pagador inválido');
            $desc=self::str($body,'description',3,140);
            $idem=$_SERVER['HTTP_IDEMPOTENCY_KEY']??'';
            if(!is_string($idem)||strlen($idem)<12||strlen($idem)>128)throw new ApiError('Idempotency-Key obrigatório (12-128 caracteres)');
            $keyHash=hash('sha256',$idem);
            $bodyHash=hash('sha256',json_encode([$amount,$name,$doc,$desc],JSON_THROW_ON_ERROR));
            $old=$db->one('SELECT * FROM b2b_live_pix WHERE merchant_id=? AND key_hash=?',[$merchant['id'],$keyHash]);
            if($old) {
                if(!hash_equals($old['body_hash'],$bodyHash))throw new ApiError('Idempotency-Key utilizado com dados diferentes',409);
                self::json(self::publicCharge($old),200);
            }
            $id=Database::uid('livepix');
            $bps=(int)$merchant['commission_bps'];
            $fee=intdiv($amount*$bps+5000,10000);
            // Reserve first. NEVER automatically retry an uncertain external create.
            try {
                $db->transaction(function()use($db,$id,$merchant,$amount,$fee,$name,$doc,$desc,$keyHash,$bodyHash){
                    $db->run('INSERT INTO b2b_live_pix(id,merchant_id,key_hash,body_hash,amount_cents,commission_cents,description,payer_name,payer_document_last4,provider_tx_id,qr_copy,status,created_at,paid_at,checked_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',[
                        $id,$merchant['id'],$keyHash,$bodyHash,$amount,$fee,$desc,$name,substr($doc,-4),null,null,'creating',Database::stamp(),null,null]);
                    self::audit($db,$id,'pix.create.reserved','Criada reserva idempotente; aguardando MisticPay');
                });
            } catch(\PDOException $ex) {
                $existing=$db->one('SELECT * FROM b2b_live_pix WHERE merchant_id=? AND key_hash=?',[$merchant['id'],$keyHash]);
                if(!$existing)throw $ex;
                if(!hash_equals($existing['body_hash'],$bodyHash))throw new ApiError('Idempotência conflitante',409);
                self::json(self::publicCharge($existing),200);
            }
            $callback=rtrim((string)getenv('ARGUS_PUBLIC_BASE_URL'),'/').'/api/live/misticpay/webhook/'.getenv('ARGUS_MISTICPAY_WEBHOOK_TOKEN');
            $payload=MisticPayHttpClient::splitRequest($merchant,$amount,$id,$name,$doc,$desc,$callback);
            try {
                $result=self::client()->createPix($payload);
                // Prevent fake success: even immediate COMPLETO is reconciled via check.
                $db->run("UPDATE b2b_live_pix SET provider_tx_id=?,qr_copy=?,status='pending' WHERE id=? AND status='creating'",[
                    $result['provider_id'],$result['copy_paste'],$id]);
                self::audit($db,$id,'pix.created','MisticPay retornou cobrança e QR; pagamento ainda não verificado');
                self::json(self::publicCharge($db->one('SELECT * FROM b2b_live_pix WHERE id=?',[$id])),201);
            } catch(\Throwable $ex) {
                $db->run("UPDATE b2b_live_pix SET status='unknown' WHERE id=? AND status='creating'",[$id]);
                self::audit($db,$id,'pix.create.unknown','Resultado incerto: exige conciliação; nenhuma segunda cobrança automática');
                error_log('ARGUS MisticPay create uncertain: '.get_class($ex));
                self::json(['id'=>$id,'status'=>'unknown','detail'=>'A criação não pôde ser confirmada. Não repita com outra chave até conciliar.'],502);
            }
        }
        if ($method==='GET'&&preg_match('~^/api/live/pix/charges/([a-zA-Z0-9_-]+)$~',$path,$m)) {
            self::requireReady($db);$merchant=self::merchantAuth($db);
            $row=$db->one('SELECT * FROM b2b_live_pix WHERE id=? AND merchant_id=?',[$m[1],$merchant['id']]);
            if(!$row)throw new ApiError('Cobrança não encontrada',404);
            self::json(self::publicCharge($row));
        }
        if ($method==='POST'&&preg_match('~^/api/live/pix/charges/([a-zA-Z0-9_-]+)/reconcile$~',$path,$m)) {
            self::requireReady($db);$merchant=self::merchantAuth($db);
            $row=$db->one('SELECT * FROM b2b_live_pix WHERE id=? AND merchant_id=?',[$m[1],$merchant['id']]);
            if(!$row)throw new ApiError('Cobrança não encontrada',404);
            self::reconcile($db,$row);
            self::json(self::publicCharge($db->one('SELECT * FROM b2b_live_pix WHERE id=?',[$row['id']])));
        }
        if ($method==='POST'&&preg_match('~^/api/live/misticpay/webhook/([a-zA-Z0-9_-]{32,128})$~',$path,$m)) {
            // Public webhook has no documented signature; token only limits noise.
            // Its status field NEVER changes financial state without authenticated PSP check.
            self::requireReady($db);
            if(!hash_equals((string)getenv('ARGUS_MISTICPAY_WEBHOOK_TOKEN'),$m[1])) throw new ApiError('Não autorizado',401);
            $event=self::input(16384);
            if(strtoupper((string)($event['transactionType']??''))!=='DEPOSITO' ||
               strtoupper((string)($event['transactionMethod']??''))!=='PIX') self::json(['ok'=>true,'ignored'=>true],202);
            $providerId=(string)($event['transactionId']??'');
            if($providerId===''||strlen($providerId)>120)self::json(['ok'=>true,'ignored'=>true],202);
            $row=$db->one('SELECT * FROM b2b_live_pix WHERE provider_tx_id=? OR id=? LIMIT 1',[$providerId,$providerId]);
            if(!$row)self::json(['ok'=>true,'ignored'=>true],202);
            $checked=$row['checked_at']??null;
            if ($checked && strtotime($checked)>time()-15) self::json(['ok'=>true,'rate_limited'=>true],202);
            self::reconcile($db,$row);
            self::json(['ok'=>true]);
        }
        throw new ApiError('Rota financeira inexistente',404);
    }

    public static function reconcile(Database $db,array $row, ?MisticPayHttpClient $client=null): void
    {
        if(empty($row['provider_tx_id']))throw new ApiError('Cobrança ainda sem ID MisticPay: concilie manualmente pelo ID interno',409);
        $provider=($client ?? self::client())->checkPix((string)$row['provider_tx_id']);
        $remoteId=(string)($provider['transactionId']??'');
        $remoteType=strtoupper((string)($provider['transactionType']??''));
        $remoteMethod=strtoupper((string)($provider['transactionMethod']??''));
        $status=strtoupper((string)$provider['transactionState']);
        if ($remoteId!== (string)$row['provider_tx_id'] || $remoteType!=='DEPOSITO' || $remoteMethod!=='PIX') {
            throw new ApiError('A resposta da MisticPay não corresponde à cobrança original',409);
        }
        if (in_array($status,['COMPLETO','DEVOLVIDO','DEVOLVIDO_PARCIAL'],true)) {
            // Provider check endpoint returns value in BRL, not integer cents.
            $brl=$provider['value']??null;
            if (!is_numeric($brl)||abs(round(((float)$brl)*100)-(int)$row['amount_cents'])>0) {
                throw new ApiError('Divergência de valor na conciliação MisticPay',409);
            }
        }
        $mapped=match($status){
            'COMPLETO'=>'paid', 'PENDENTE'=>'pending', 'DEVOLVIDO'=>'refunded',
            'DEVOLVIDO_PARCIAL'=>'refund_review', 'FALHA','CANCELADO'=>'failed',default=>'review',
        };
        $current=$db->one('SELECT * FROM b2b_live_pix WHERE id=?',[$row['id']]);
        if (!$current)throw new ApiError('Cobrança não encontrada',404);
        if ($current['status']==='refunded' && $mapped!=='refunded')$mapped='review';
        if ($current['status']==='paid' && in_array($mapped,['failed','pending'],true))$mapped='review';
        $db->transaction(function() use($db,$row,$mapped,$status,$current){
            $db->run('UPDATE b2b_live_pix SET status=?,paid_at=?,checked_at=? WHERE id=?',[
                $mapped,$mapped==='paid'?($current['paid_at']?:Database::stamp()):$current['paid_at'],Database::stamp(),$row['id']]);
            if($mapped!==$current['status'])self::audit($db,$row['id'],'pix.status.'.$mapped,'Estado autenticado MisticPay: '.$status);
        });
    }
}
