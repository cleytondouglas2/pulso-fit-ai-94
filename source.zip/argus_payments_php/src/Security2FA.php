<?php
declare(strict_types=1);
namespace ArgusPayments;

/** RFC 6238 TOTP; the server never exposes a stored secret to a normal authenticated session. */
final class Security2FA
{
    private const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    public static function newSecret(): string { return self::base32(random_bytes(20)); }
    public static function base32(string $bytes): string {
        $bits='';foreach(str_split($bytes) as $c)$bits.=str_pad(decbin(ord($c)),8,'0',STR_PAD_LEFT);
        $out='';foreach(str_split($bits,5) as $chunk){$out.=self::ALPHABET[bindec(str_pad($chunk,5,'0'))];}return $out;
    }
    private static function bytes(string $secret): string {
        if(!preg_match('/\A[A-Z2-7]{32}\z/D',$secret))throw new \InvalidArgumentException('Segredo TOTP inválido');
        $bits='';foreach(str_split($secret) as $char){$index=strpos(self::ALPHABET,$char);$bits.=str_pad(decbin($index),5,'0',STR_PAD_LEFT);}
        $result='';foreach(str_split($bits,8) as $group)if(strlen($group)===8)$result.=chr(bindec($group));return $result;
    }
    public static function token(string $secret,int $step): string {
        $counter=pack('N2', intdiv($step,4294967296), $step%4294967296);
        $digest=hash_hmac('sha1',$counter,self::bytes($secret),true);
        $offset=ord($digest[19])&15;
        $value=(unpack('N',substr($digest,$offset,4))[1]&0x7fffffff)%1000000;
        return str_pad((string)$value,6,'0',STR_PAD_LEFT);
    }
    /** The last used step makes each TOTP one-time, including across parallel payout requests. */
    public static function matchingStep(string $secret,string $code,int $lastUsed=-1,?int $now=null): ?int {
        if(!preg_match('/\A\d{6}\z/D',$code))return null;
        $step=intdiv($now??time(),30);
        for($s=$step-1;$s<=$step+1;$s++)if($s>$lastUsed&&hash_equals(self::token($secret,$s),$code))return $s;
        return null;
    }
    public static function key():string {
        $hex=(string)getenv('ARGUS_TOTP_ENCRYPTION_KEY');
        if(!preg_match('/\A[a-f0-9]{64}\z/iD',$hex)||!function_exists('sodium_crypto_secretbox'))throw new \RuntimeException('Chave 2FA de produção ausente');
        return sodium_hex2bin($hex);
    }
    public static function seal(string $plain):string {
        $nonce=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return base64_encode($nonce.sodium_crypto_secretbox($plain,$nonce,self::key()));
    }
    public static function unseal(string $cipher):string {
        $raw=base64_decode($cipher,true);if($raw===false||strlen($raw)<SODIUM_CRYPTO_SECRETBOX_NONCEBYTES+16)throw new \RuntimeException('2FA inválido');
        $nonce=substr($raw,0,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $decoded=sodium_crypto_secretbox_open(substr($raw,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),$nonce,self::key());
        if($decoded===false)throw new \RuntimeException('Não foi possível verificar o 2FA');return $decoded;
    }
    public static function uri(string $email,string $secret):string {
        return 'otpauth://totp/'.rawurlencode('ARGUS Payments:'.$email).'?secret='.$secret.'&issuer='.rawurlencode('ARGUS Payments').'&algorithm=SHA1&digits=6&period=30';
    }
}
