<?php
declare(strict_types=1);
namespace ArgusPayments;

require_once __DIR__ . '/Integrations/MisticPayPix.php';
use ArgusPayments\Integrations\MisticPayPix;
use PDOException;

/** B2B console — sandbox administrator only, NOT production merchant accounts. */
final class B2B
{
    private static Database $db;

    private static function reply(mixed $data, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        exit;
    }
    private static function error(string $message, int $status = 400): never { throw new ApiError($message,$status); }
    private static function input(): array
    {
        $raw = file_get_contents('php://input');
        if ($raw===false || strlen($raw)>8192) self::error('Payload inválido ou muito grande',413);
        try { $payload=json_decode($raw,true,20,JSON_THROW_ON_ERROR); }
        catch (\JsonException) { self::error('JSON inválido'); }
        if (!is_array($payload) || array_is_list($payload)) self::error('Corpo deve ser objeto JSON');
        return $payload;
    }
    private static function str(array $data, string $key, int $min, int $max): string
    {
        $v=$data[$key] ?? null;
        if (!is_string($v)) self::error("Campo $key obrigatório");
        $v=trim($v);
        $len=function_exists('mb_strlen')?mb_strlen($v):strlen($v);
        if($len<$min||$len>$max) self::error("Campo $key fora dos limites ($min-$max caracteres)");
        return $v;
    }
    private static function merchant(string $id): array
    {
        $m=self::$db->one('SELECT * FROM b2b_merchants WHERE id=?',[$id]);
        if(!$m) self::error('Empresa não encontrada',404);
        return $m;
    }
    private static function cash(int $amount, int $bps, string $email): array
    {
        return MisticPayPix::splitPreview($amount,$bps,$email);
    }
    private static function cnpjValid(string $cnpj): bool
    {
        if(strlen($cnpj)!==14 || preg_match('/^(\d)\1{13}$/',$cnpj))return false;
        $chars=array_map('intval',str_split($cnpj));
        foreach ([12,13] as $pos) {
            $weight=$pos===12 ? [5,4,3,2,9,8,7,6,5,4,3,2]:[6,5,4,3,2,9,8,7,6,5,4,3,2];
            $sum=0;foreach($weight as $i=>$w)$sum+=$chars[$i]*$w;
            $remainder=$sum%11;
            $digit=$remainder<2?0:11-$remainder;
            if($digit!==$chars[$pos])return false;
        }
        return true;
    }
    private static function event(string $merchantId,string $type,string $note): void
    {
        self::$db->run('INSERT INTO b2b_events(id,merchant_id,type,note,created_at) VALUES (?,?,?,?,?)',
            [Database::uid('bev'),$merchantId,$type,substr($note,0,350),Database::stamp()]);
    }
    private static function payment(string $id): array
    {
        $row=self::$db->one('SELECT * FROM b2b_charges WHERE id=?',[$id]);
        if(!$row)self::error('Cobrança não encontrada',404);
        return $row;
    }
    private static function ledger(string $chargeId,string $merchantId, int $gross,int $net,int $fee,string $postfix=''): void
    {
        // Two-way total always zero; these are demonstrative accounting balances ONLY.
        $sign=$postfix===''?1:-1;
        $entries=[
            ['cash_clearing'.$postfix,$sign*$gross],
            ['merchant_payable'.$postfix,-$sign*$net],
            ['argus_fee_revenue'.$postfix,-$sign*$fee],
        ];
        if (array_sum(array_column($entries,1)) !== 0) throw new \LogicException('Lançamentos desequilibrados');
        foreach($entries as [$account,$value])self::$db->run('INSERT INTO b2b_ledger(id,charge_id,merchant_id,account,amount_cents,created_at) VALUES (?,?,?,?,?,?)',
            [Database::uid('led'),$chargeId,$merchantId,$account,$value,Database::stamp()]);
    }
    public static function handle(Database $db,string $method,string $path): void
    {
        self::$db=$db;
        if($method==='GET' && $path==='/api/b2b/summary') {
            $m=self::$db->one('SELECT COUNT(*) total, SUM(CASE WHEN status=\'approved_demo\' THEN 1 ELSE 0 END) active FROM b2b_merchants');
            $p=self::$db->one("SELECT COUNT(*) total, COALESCE(SUM(CASE WHEN status='paid_demo' THEN amount_cents ELSE 0 END),0) paid, COALESCE(SUM(CASE WHEN status='paid_demo' THEN commission_cents ELSE 0 END),0) commissions FROM b2b_charges");
            self::reply(['sandbox'=>true,'provider'=>'MisticPay','provider_api'=>'pix-transactions-v1','connectivity'=>'disabled', 'provider_contract'=>'pending','provider_fee_known'=>false,'merchants'=>(int)$m['total'],'active_merchants'=>(int)($m['active']??0), 'charges'=>(int)$p['total'], 'volume_paid_demo_cents'=>(int)$p['paid'], 'commission_paid_demo_cents'=>(int)$p['commissions']]);
        }
        if($path==='/api/b2b/merchants') {
            if($method==='GET') self::reply(self::$db->all('SELECT * FROM b2b_merchants ORDER BY created_at DESC LIMIT 100'));
            if($method==='POST') {
                $data=self::input();
                $legal=self::str($data,'legal_name',3,180);
                $email=strtolower(self::str($data,'email',5,190));
                if(!filter_var($email,FILTER_VALIDATE_EMAIL)) self::error('E-mail inválido');
                $cnpj=preg_replace('/\D/','',self::str($data,'cnpj',14,20));
                if(!self::cnpjValid($cnpj)) self::error('CNPJ inválido: informe um CNPJ válido da empresa');
                $partnerEmail=strtolower(trim((string)($data['misticpay_email']??'')));
                if($partnerEmail!==''&&!filter_var($partnerEmail,FILTER_VALIDATE_EMAIL))self::error('E-mail MisticPay inválido');
                $bps=$data['commission_bps']??150;
                if(!is_int($bps)||$bps<0||$bps>1000)self::error('Comissão deve ficar entre 0 e 1000 pontos-base (0-10%)');
                if((int)(self::$db->one('SELECT COUNT(*) total FROM b2b_merchants')['total']??0)>=100)self::error('Limite da demonstração atingido',409);
                $id=Database::uid('mer');
                try {self::$db->transaction(function()use($id,$legal,$cnpj,$email,$partnerEmail,$bps){
                    self::$db->run('INSERT INTO b2b_merchants(id,legal_name,cnpj,email,misticpay_email,commission_bps,status,created_at,reviewed_at) VALUES (?,?,?,?,?,?,?,?,?)',
                        [$id,$legal,$cnpj,$email,$partnerEmail,$bps,'pending_review',Database::stamp(),null]);
                    self::event($id,'merchant.application','Solicitação recebida; KYB e contrato reais ainda não verificados');
                });}catch(PDOException $ex){if(self::$db->one('SELECT id FROM b2b_merchants WHERE cnpj=?',[$cnpj]))self::error('CNPJ já cadastrado',409);throw $ex;}
                self::reply(['id'=>$id,'status'=>'pending_review','sandbox'=>true],201);
            }
        }
        if($method==='POST' && preg_match('~^/api/b2b/merchants/([\w-]+)/status$~',$path,$match)){
            $m=self::merchant($match[1]);$data=self::input();
            $status=$data['status']??null;
            if(!in_array($status,['pending_review','approved_demo','suspended'],true))self::error('Status inválido');
            self::$db->transaction(function()use($m,$status){
                self::$db->run('UPDATE b2b_merchants SET status=?,reviewed_at=? WHERE id=?',[$status,Database::stamp(),$m['id']]);
                self::event($m['id'],'merchant.status','Novo estado: '.$status.' (somente demonstração)');
            });
            self::reply(['ok'=>true,'status'=>$status,'sandbox'=>true]);
        }
        if($method==='POST'&&$path==='/api/b2b/preview'){
            $data=self::input();$m=self::merchant(self::str($data,'merchant_id',5,120));
            $amount=$data['amount_cents']??0;
            if(!is_int($amount)||$amount<100||$amount>100000000) self::error('Valor inválido em centavos');
            self::reply(self::cash($amount,(int)$m['commission_bps'],(string)$m['misticpay_email'])+['sandbox'=>true,'provider'=>'MisticPay','split_status'=>'not_homologated']);
        }
        if($path==='/api/b2b/charges'){
            if($method==='GET')self::reply(self::$db->all('SELECT p.*,m.legal_name FROM b2b_charges p JOIN b2b_merchants m ON m.id=p.merchant_id ORDER BY p.created_at DESC LIMIT 100'));
            if($method==='POST'){
                $data=self::input();$m=self::merchant(self::str($data,'merchant_id',5,120));
                if($m['status']!=='approved_demo')self::error('Aprovação demonstrativa da empresa necessária',403);
                $amount=$data['amount_cents']??0;
                if(!is_int($amount)||$amount<100||$amount>100000000)self::error('Valor inválido em centavos');
                $desc=self::str($data,'description',3,180);
                $name=self::str($data,'payer_name',2,120);
                // Intentionally do not store CPF; only the last four digits for audit in sandbox.
                $doc=preg_replace('/\D/','',(string)($data['payer_document']??''));
                if($doc!==''&&strlen($doc)!==11)self::error('CPF deve conter 11 dígitos, se informado');
                $idempotency=$_SERVER['HTTP_IDEMPOTENCY_KEY']??'';
                if(!is_string($idempotency)||strlen($idempotency)<8||strlen($idempotency)>128)self::error('Idempotency-Key obrigatório (8-128 caracteres)');
                $bodyHash=hash('sha256',json_encode([$m['id'],$amount,$desc,$name,$doc],JSON_THROW_ON_ERROR));
                $keyHash=hash('sha256',$idempotency);
                $totals=self::cash($amount,(int)$m['commission_bps'],'');
                $create=function()use($m,$amount,$desc,$name,$doc,$bodyHash,$keyHash,$totals){
                    $old=self::$db->one('SELECT charge_id,body_hash FROM b2b_idempotency WHERE merchant_id=? AND key_hash=?',[$m['id'],$keyHash]);
                    if($old){if(!hash_equals($old['body_hash'],$bodyHash))self::error('Chave idempotente usada com dados diferentes',409);return self::payment($old['charge_id']);}
                    $id=Database::uid('b2b');
                    self::$db->run('INSERT INTO b2b_charges(id,merchant_id,amount_cents,commission_cents,merchant_net_cents,description,payer_name,payer_document_last4,provider,provider_id,status,created_at,paid_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
                        [$id,$m['id'],$amount,$totals['argus_commission_cents'],$totals['merchant_before_provider_fees_cents'],$desc,$name,substr($doc,-4),'misticpay_dryrun',null,'pending',Database::stamp(),null]);
                    self::$db->run('INSERT INTO b2b_idempotency(merchant_id,key_hash,body_hash,charge_id) VALUES (?,?,?,?)',[$m['id'],$keyHash,$bodyHash,$id]);
                    self::event($m['id'],'charge.created',$id.' (Pix simulado; API externa não acionada)');
                    return self::payment($id);
                };
                try{$result=self::$db->transaction($create);}catch(PDOException $ex){
                    $old=self::$db->one('SELECT charge_id,body_hash FROM b2b_idempotency WHERE merchant_id=? AND key_hash=?',[$m['id'],$keyHash]);
                    if(!$old)throw $ex;
                    if(!hash_equals($old['body_hash'],$bodyHash))self::error('Chave idempotente usada com dados diferentes',409);
                    $result=self::payment($old['charge_id']);
                }
                self::reply($result+['sandbox'=>true,'message'=>'Cobrança de ensaio; não é Pix válido.'],201);
            }
        }
        if($method==='POST'&&preg_match('~^/api/b2b/charges/([\w-]+)/(settle-test|refund-test)$~',$path,$match)){
            $charge=self::payment($match[1]);$action=$match[2];
            self::$db->transaction(function()use($charge,$action){
                if($action==='settle-test'){
                    if($charge['status']!=='pending')self::error('Somente pendente pode ser aprovado na demo',409);
                    self::$db->run("UPDATE b2b_charges SET status='paid_demo',paid_at=? WHERE id=? AND status='pending'",[Database::stamp(),$charge['id']]);
                    self::ledger($charge['id'],$charge['merchant_id'],(int)$charge['amount_cents'],(int)$charge['merchant_net_cents'],(int)$charge['commission_cents']);
                }else{
                    if($charge['status']!=='paid_demo')self::error('Somente demo paga pode ser revertida',409);
                    self::$db->run("UPDATE b2b_charges SET status='refunded_demo' WHERE id=? AND status='paid_demo'",[$charge['id']]);
                    self::ledger($charge['id'],$charge['merchant_id'],(int)$charge['amount_cents'],(int)$charge['merchant_net_cents'],(int)$charge['commission_cents'],'_reverse');
                }
                self::event($charge['merchant_id'],$action,$charge['id'].' operação de teste — não movimentou fundos');
            });
            self::reply(['ok'=>true,'status'=>$action==='settle-test'?'paid_demo':'refunded_demo','sandbox'=>true]);
        }
        if($method==='GET'&&$path==='/api/b2b/ledger'){
            self::reply(self::$db->all('SELECT l.*,m.legal_name FROM b2b_ledger l JOIN b2b_merchants m ON m.id=l.merchant_id ORDER BY l.created_at DESC LIMIT 250'));
        }
        if($method==='GET'&&$path==='/api/b2b/events'){
            self::reply(self::$db->all('SELECT e.*,m.legal_name FROM b2b_events e JOIN b2b_merchants m ON m.id=e.merchant_id ORDER BY e.created_at DESC LIMIT 80'));
        }
        if($method==='GET'&&$path==='/api/b2b/integration'){
            self::reply(['partner'=>'MisticPay','provider_url'=>MisticPayPix::API_BASE,'documentation'=>'https://app.misticpay.com/docs','mode'=>'DRY_RUN','real_payments'=>false,'provider_credentials_configured'=>false,'features'=>['pix_preview'=>true,'split_commission_preview'=>true,'merchant_onboarding_demo'=>true,'ledger_demo'=>true,'live_pix'=>false,'live_payout'=>false,'card'=>false,'boleto'=>false], 'requirements'=>['Contrato B2B MisticPay com split para terceiros','Habilitação e titularidade de recebedores','Definição contratual do destinatário do split','Chaves PK/SK com escopos mínimos e segregadas','Validação das cobranças via consulta autenticada, não via payload de webhook isolado','Banco permanente, login real, KYB, conformidade e homologação'], 'webhook_policy'=>'Não confirma pagamentos sem consulta autenticada ao PSP']);
        }
        if($method==='POST'&&$path==='/api/b2b/partner-request/preview'){
            $data=self::input();$m=self::merchant(self::str($data,'merchant_id',5,120));
            $amount=$data['amount_cents']??0;
            if(!is_int($amount)||$amount<100||$amount>100000000)self::error('Valor inválido');
            $requested=[ 'id'=>Database::uid('dry'), 'method'=>'pix','amount_cents'=>$amount,
                'payer_name'=>self::str($data,'payer_name',2,120),
                'payer_document'=>self::str($data,'payer_document',11,14),
                'description'=>self::str($data,'description',3,140)];
            try{$preview=MisticPayPix::buildRequest($requested,$m);}
            catch(\InvalidArgumentException $ex){self::error($ex->getMessage());}
            // Minimize sensitive payer data: redact in any browser response.
            $preview['body']['payerDocument']='********'.substr(preg_replace('/\D/','',$requested['payer_document']),-3);
            self::reply($preview);
        }
        if($method==='POST'&&$path==='/api/b2b/webhook/misticpay'){
            // FAIL CLOSED: public docs do not establish a trustworthy webhook signature.
            // Requires provider status check with scoped credentials before processing money.
            self::reply(['ok'=>false,'detail'=>'Webhook financeiro bloqueado até autenticação e reconciliação com MisticPay.'],503);
        }
        self::error('Rota B2B inexistente',404);
    }
}
