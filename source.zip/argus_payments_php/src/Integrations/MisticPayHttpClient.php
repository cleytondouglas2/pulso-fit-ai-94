<?php
declare(strict_types=1);
namespace ArgusPayments\Integrations;

/**
 * MisticPay PIX transactions v1 (https://api.misticpay.com/api).
 * IMPORTANT: different from api.finance.misticpay.com (amounts in cents there).
 * This adapter sends amounts in BRL, accepts only create/check, and never uses
 * cash-out credentials. External calls are impossible without valid pk_/sk_.
 */
final class MisticPayHttpClient
{
    public const BASE = 'https://api.misticpay.com/api';
    private $sender;

    public function __construct(private string $clientId, private string $clientSecret, ?callable $sender = null)
    {
        if (!preg_match('/^pk_[A-Za-z0-9_-]{8,}$/D', $clientId) ||
            !preg_match('/^sk_[A-Za-z0-9_-]{8,}$/D', $clientSecret)) {
            throw new \InvalidArgumentException('Credenciais MisticPay pk_/sk_ não configuradas');
        }
        $this->sender = $sender;
    }

    public static function splitRequest(array $merchant, int $amountCents, string $chargeId,
        string $payerName, string $payerDocument, string $description, string $webhookUrl): array
    {
        $email = strtolower(trim((string)($merchant['misticpay_email'] ?? '')));
        $bps = (int)($merchant['commission_bps'] ?? -1);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new \InvalidArgumentException('Conta MisticPay do lojista não vinculada');
        if ($bps < 0 || $bps > 1000) throw new \InvalidArgumentException('Comissão inválida');
        if ($amountCents < 100 || $amountCents > 100000000) throw new \InvalidArgumentException('Valor inválido');
        if (!preg_match('/^[A-Za-z0-9_-]{8,120}$/D', $chargeId)) throw new \InvalidArgumentException('ID da cobrança inválido');
        if (strlen(trim($payerName)) < 2 || strlen(trim($payerName)) > 120) throw new \InvalidArgumentException('Pagador inválido');
        $doc = preg_replace('/\D/', '', $payerDocument);
        if (strlen($doc) !== 11) throw new \InvalidArgumentException('CPF do pagador obrigatório');
        if (strlen(trim($description)) < 3 || strlen(trim($description)) > 140) throw new \InvalidArgumentException('Descrição inválida');
        if (!filter_var($webhookUrl, FILTER_VALIDATE_URL) || parse_url($webhookUrl, PHP_URL_SCHEME) !== 'https') {
            throw new \InvalidArgumentException('Webhook seguro obrigatório');
        }
        // Credential is ARGUS's platform account; splitUser must be the verified
        // seller account. The documented splitTax percentage goes TO splitUser.
        // Merchant gets 100% minus the contracted ARGUS commission, before PSP fees.
        return [
            'amount' => ((float)$amountCents) / 100,
            'payerName' => trim($payerName),
            'payerDocument' => $doc,
            'transactionId' => $chargeId,
            'description' => trim($description),
            'projectWebhook' => $webhookUrl,
            'splitUser' => $email,
            'splitTax' => (10000 - $bps) / 100,
        ];
    }

    public function createPix(array $payload): array
    {
        $result = $this->post('/transactions/create', $payload);
        $data = $result['data'] ?? null;
        if (!is_array($data) || empty($data['transactionId'])) {
            throw new \RuntimeException('MisticPay não retornou o identificador da cobrança');
        }
        $providerId = (string)$data['transactionId'];
        if (strlen($providerId) > 120 || !preg_match('/^[A-Za-z0-9_.:-]+$/D', $providerId)) {
            throw new \RuntimeException('ID retornado pela MisticPay inválido');
        }
        $code = $data['copyPaste'] ?? '';
        if (!is_string($code) || strlen($code) > 6000 || strlen($code) < 20) {
            throw new \RuntimeException('Cobrança sem Pix copia e cola válido na resposta');
        }
        return ['provider_id' => $providerId, 'copy_paste' => $code,
                'status' => strtoupper((string)($data['transactionState'] ?? 'PENDENTE'))];
    }

    public function checkPix(string $providerId): array
    {
        if ($providerId === '' || strlen($providerId) > 120 || !preg_match('/^[A-Za-z0-9_.:-]+$/D', $providerId)) {
            throw new \InvalidArgumentException('ID de transação inválido');
        }
        $result = $this->post('/transactions/check', ['transactionId' => $providerId]);
        $transaction = $result['transaction'] ?? null;
        if (!is_array($transaction) || !is_string($transaction['transactionState'] ?? null)) {
            throw new \RuntimeException('Consulta MisticPay sem estado válido');
        }
        return $transaction;
    }

    private function post(string $path, array $payload): array
    {
        $headers = [
            'Authorization: Basic ' . base64_encode($this->clientId . ':' . $this->clientSecret),
            'Content-Type: application/json', 'Accept: application/json',
        ];
        // Injectable transport is used only by automated tests.
        if ($this->sender !== null) {
            $result = ($this->sender)(self::BASE . $path, $payload, $headers);
            if (!is_array($result)) throw new \RuntimeException('Transporte de teste inválido');
            return $result;
        }
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
        $ctx = stream_context_create([
            'http' => ['method'=>'POST', 'header'=>implode("\r\n", $headers),
                'content'=>$json, 'timeout'=>9, 'ignore_errors'=>true,
                'follow_location'=>0, 'max_redirects'=>0, 'protocol_version'=>1.1],
            'ssl' => ['verify_peer'=>true, 'verify_peer_name'=>true],
        ]);
        $body = @file_get_contents(self::BASE . $path, false, $ctx);
        if ($body === false) throw new \RuntimeException('Não foi possível consultar a MisticPay; transação pode estar em estado indeterminado');
        $statusLine = $http_response_header[0] ?? '';
        $status = preg_match('/\s(\d{3})\s/', $statusLine, $m) ? (int)$m[1] : 0;
        if ($status < 200 || $status >= 300) {
            if ($status === 429) throw new \RuntimeException('MisticPay: limite de requisições; tente novamente mais tarde');
            throw new \RuntimeException('MisticPay recusou a requisição (HTTP '.$status.')');
        }
        if (strlen($body) > 1000000) throw new \RuntimeException('Resposta MisticPay excessiva');
        $decoded = json_decode($body, true, 32);
        if (!is_array($decoded)) throw new \RuntimeException('MisticPay retornou JSON inválido');
        return $decoded;
    }
}
