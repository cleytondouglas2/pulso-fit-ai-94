<?php
declare(strict_types=1);
namespace ArgusPayments\Integrations;

/**
 * MisticPay /api/transactions/create PIX adapter — strictly DRY RUN.
 * Docs: https://app.misticpay.com/docs (provider's second public API uses
 * distinct routes AND amount units; deliberately do not mix them).
 * This class never performs HTTP, never accepts secrets and cannot settle funds.
 */
final class MisticPayPix
{
    public const API_BASE = 'https://api.misticpay.com/api';
    public const API_VERSION = 'legacy-transactions-v1';

    public static function splitPreview(int $amountCents, int $feeBps, string $recipientEmail): array
    {
        if ($amountCents < 100 || $amountCents > 100000000) throw new \InvalidArgumentException('Valor fora dos limites do protótipo');
        if ($feeBps < 0 || $feeBps > 10000) throw new \InvalidArgumentException('Percentual inválido');
        if ($recipientEmail !== '' && !filter_var($recipientEmail,FILTER_VALIDATE_EMAIL)) throw new \InvalidArgumentException('Email do recebedor inválido');
        $fee = intdiv($amountCents*$feeBps + 5000,10000); // HALF UP, centavos
        return [
            'amount_cents'=>$amountCents,
            'argus_commission_cents'=>$fee,
            'merchant_before_provider_fees_cents'=>$amountCents-$fee,
            'argus_commission_bps'=>$feeBps,
            'provider_fee_cents'=>null,
            'provider_cost_known'=>false,
            'recipient_email'=>$recipientEmail,
        ];
    }

    public static function buildRequest(array $payment, array $merchant, ?string $webhook = null): array
    {
        if (($payment['method']??'pix') !== 'pix') throw new \InvalidArgumentException('API MisticPay examinada permite Pix apenas');
        $cents = (int)($payment['amount_cents']??0);
        $commission = (int)($merchant['commission_bps']??0);
        $recipient = (string)(getenv('ARGUS_MISTICPAY_COMMISSION_EMAIL') ?: '');
        $split = self::splitPreview($cents,$commission,$recipient);
        $payerDoc=preg_replace('/\D/','',(string)($payment['payer_document']??''));
        if (!in_array(strlen($payerDoc),[11],true)) throw new \InvalidArgumentException('CPF do pagador obrigatório para Pix MisticPay');
        if ($split['recipient_email']==='') throw new \InvalidArgumentException('Conta de recebimento MisticPay ainda não vinculada');
        // Modelo ainda NÃO homologado: conta-origem = conta do lojista; destinatário de split = ARGUS.
        // Aqui mostramos a estrutura proposta para aprovação contratual; nenhuma chamada HTTP é feita.
        $body=[
            'amount'=>$cents/100,
            'payerName'=>trim((string)($payment['payer_name']??'')),
            'payerDocument'=>$payerDoc,
            'transactionId'=>(string)($payment['id']??''),
            'description'=>trim((string)($payment['description']??'')),
            'splitUser'=>$split['recipient_email'],
            'splitTax'=>$commission/100,
        ];
        if ($webhook && preg_match('~^https://[^\s/]+(?:/[^\s]*)?$~i',$webhook)) $body['projectWebhook']=$webhook;
        return ['enabled'=>false,'dry_run'=>true,'method'=>'POST','endpoint'=>self::API_BASE.'/transactions/create','body'=>$body,'assumptions'=>[
            'A credencial de criação de cobrança pertence à conta MisticPay do lojista.',
            'splitUser representa a conta ARGUS que receberá a comissão em splitTax.',
            'Papel e direção do split dependem de confirmação escrita da MisticPay.',
            'Não foi habilitada cobrança real, estorno ou saque.',
        ]];
    }

    public static function mapProviderStatus(string $state): string
    {
        return match(strtoupper($state)) {
            'COMPLETO'=>'paid',
            'DEVOLVIDO'=>'refunded',
            'DEVOLVIDO_PARCIAL'=>'partially_refunded',
            'FALHA','CANCELADO'=>'failed',
            default=>'pending',
        };
    }
}
