<?php
declare(strict_types=1);
namespace ArgusPayments\Integrations;

/** Cash-out credentials must be distinct from the cash-in split/checkout key. */
final class MisticPayPayout
{
    private const BASE='https://api.misticpay.com/api';
    private $sender;
    public function __construct(private string $key,private string $secret,?callable $sender=null) {
        if(!preg_match('/\Apk_[A-Za-z0-9_-]{8,}\z/D',$key)||!preg_match('/\Ask_[A-Za-z0-9_-]{8,}\z/D',$secret))throw new \InvalidArgumentException('Chaves de saque MisticPay não configuradas');
        $this->sender=$sender;
    }
    public static function validatePixKey(string $type,string $value): string {
        $value=trim($value);if(!in_array($type,['CPF','CNPJ','EMAIL','TELEFONE','CHAVE_ALEATORIA'],true))throw new \InvalidArgumentException('Tipo de chave Pix inválido');
        if($type==='EMAIL'&&(!filter_var($value,FILTER_VALIDATE_EMAIL)||strlen($value)>190))throw new \InvalidArgumentException('E-mail Pix inválido');
        if($type==='CPF'||$type==='CNPJ'){$value=preg_replace('/\D/','',$value);if(strlen($value)!==($type==='CPF'?11:14))throw new \InvalidArgumentException('CPF/CNPJ da chave Pix inválido');}
        if($type==='TELEFONE'&&!preg_match('/\A\+55[1-9][0-9]{9,10}\z/D',$value))throw new \InvalidArgumentException('Telefone Pix deve começar com +55');
        if($type==='CHAVE_ALEATORIA'&&!preg_match('/\A[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\z/iD',$value))throw new \InvalidArgumentException('Chave aleatória Pix inválida');
        return $value;
    }
    public function balance():int {
        $result=$this->call('GET','/users/balance');$v=$result['data']['balance']??null;
        if(!is_numeric($v)||!is_finite((float)$v)||(float)$v<0)throw new \RuntimeException('MisticPay não retornou saldo válido');
        return (int)round(((float)$v)*100);
    }
    public function withdraw(int $cents,string $type,string $pixKey,string $desc,string $idempotencyKey):array {
        if($cents<100||$cents>10000)throw new \InvalidArgumentException('Piloto limita transferências a R$ 1–100');
        $key=self::validatePixKey($type,$pixKey);if(strlen($desc)<3||strlen($desc)>120)throw new \InvalidArgumentException('Descrição inválida');
        if(!preg_match('/\A[A-Za-z0-9_-]{16,120}\z/D',$idempotencyKey))throw new \InvalidArgumentException('Idempotência inválida');
        $result=$this->call('POST','/transactions/withdraw',['amount'=>$cents/100,'pixKey'=>$key,'pixKeyType'=>$type,'description'=>$desc],$idempotencyKey);
        $data=$result['data']??null;if(!is_array($data)||empty($data['transactionId']))throw new \RuntimeException('Saque sem identificador de transação');
        return ['transaction_id'=>(string)$data['transactionId'],'job_id'=>(string)($data['jobId']??''),'status'=>strtoupper((string)($data['status']??'QUEUED'))];
    }
    public function status(string $providerId):array {
        if(!preg_match('/\A[a-zA-Z0-9_.:-]{1,120}\z/D',$providerId))throw new \InvalidArgumentException('ID Pix inválido');
        $r=$this->call('POST','/transactions/check',['transactionId'=>$providerId]);$t=$r['transaction']??null;
        if(!is_array($t)||strtoupper((string)($t['transactionType']??''))!=='RETIRADA')throw new \RuntimeException('Transação não é saque Pix');
        $state=strtoupper((string)($t['transactionState']??''));
        if(!in_array($state,['PENDENTE','COMPLETO','FALHA','CANCELADO','DEVOLVIDO','DEVOLVIDO_PARCIAL'],true))throw new \RuntimeException('Estado de saque desconhecido');
        return ['state'=>$state,'transaction_id'=>(string)($t['transactionId']??$providerId)];
    }
    private function call(string $method,string $path,?array $payload=null,?string $idempotencyKey=null):array {
        $headers=['Authorization: Basic '.base64_encode($this->key.':'.$this->secret),'Accept: application/json','Content-Type: application/json'];
        if($idempotencyKey)$headers[]='X-Idempotency-Key: '.$idempotencyKey;
        if($this->sender){$r=($this->sender)($method,self::BASE.$path,$payload,$headers);if(!is_array($r))throw new \RuntimeException('Resposta de teste inválida');return $r;}
        $options=['method'=>$method,'header'=>implode("\r\n",$headers),'timeout'=>10,'ignore_errors'=>true,'follow_location'=>0,'max_redirects'=>0];
        if($payload!==null)$options['content']=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
        $ctx=stream_context_create(['http'=>$options,'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]]);
        $raw=@file_get_contents(self::BASE.$path,false,$ctx);if($raw===false)throw new \RuntimeException('Resposta MisticPay indisponível; não repita automaticamente o saque');
        preg_match('/\s(\d{3})\s/',$http_response_header[0]??'',$m);$status=(int)($m[1]??0);
        if($status<200||$status>=300)throw new \RuntimeException('MisticPay recusou operação (HTTP '.$status.')');
        if(strlen($raw)>200000)throw new \RuntimeException('Resposta muito grande');
        $v=json_decode($raw,true,24);if(!is_array($v))throw new \RuntimeException('JSON MisticPay inválido');return $v;
    }
}
