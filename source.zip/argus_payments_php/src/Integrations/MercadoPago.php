<?php
declare(strict_types=1);
namespace ArgusPayments\Integrations;

/**
 * EXEMPLO NÃO ATIVADO: integração com o PSP (Mercado Pago).
 * Não vincular este arquivo ao checkout demo sem homologação, verificação
 * de pagamento no provedor, conciliação, idempotência e controles de produção.
 */
final class MercadoPago
{
    private const BASE = 'https://api.mercadopago.com';

    public static function createPix(
        string $token, int $amountCents, string $description, string $email,
        string $externalReference, string $idempotencyKey, ?string $notificationUrl = null
    ): array {
        if ($amountCents < 100 || $amountCents > 100_000_000) throw new \InvalidArgumentException('Valor inválido');
        if (!filter_var($email,FILTER_VALIDATE_EMAIL)) throw new \InvalidArgumentException('E-mail inválido');
        if ($notificationUrl !== null && !str_starts_with($notificationUrl,'https://')) {
            throw new \InvalidArgumentException('Webhook deve usar HTTPS');
        }
        if (strlen($idempotencyKey) < 8) throw new \InvalidArgumentException('Chave de idempotência inválida');
        $body = [
            'transaction_amount'=>$amountCents / 100,
            'description'=>(function_exists('mb_substr') ? mb_substr($description,0,140) : substr($description,0,140)),
            'payment_method_id'=>'pix',
            'payer'=>['email'=>$email],
            'external_reference'=>$externalReference,
        ];
        if ($notificationUrl !== null) $body['notification_url']=$notificationUrl;
        $data=self::call('POST','/v1/payments',$token,$body,$idempotencyKey);
        $info=$data['point_of_interaction']['transaction_data']??[];
        return [
            'provider_id'=>(string)($data['id']??''),
            'status'=>$data['status']??null,
            'qr_code'=>$info['qr_code']??null,
            'qr_code_base64'=>$info['qr_code_base64']??null,
            'ticket_url'=>$info['ticket_url']??null,
        ];
    }

    public static function getPayment(string $token,string $paymentId): array
    {
        if (!ctype_digit($paymentId)) throw new \InvalidArgumentException('ID do provedor inválido');
        return self::call('GET','/v1/payments/'.$paymentId,$token);
    }

    public static function verifyWebhookSignature(string $signatureHeader,string $requestId,string $dataId,string $secret,int $maxAgeSeconds=300): bool
    {
        if ($secret==='' || $requestId==='' || $dataId==='' || $signatureHeader==='') return false;
        $parts=[];
        foreach (explode(',',$signatureHeader) as $chunk) {
            $piece=explode('=',trim($chunk),2);
            if (count($piece)===2) $parts[trim($piece[0])]=trim($piece[1]);
        }
        $ts=$parts['ts']??'';$sig=$parts['v1']??'';
        if (!ctype_digit($ts) || !preg_match('/^[0-9a-f]{64}$/i',$sig)) return false;
        $seconds=(int)$ts;
        if ($seconds > 10_000_000_000) $seconds = intdiv($seconds,1000);
        if (abs(time()-$seconds)>$maxAgeSeconds) return false;
        $message="id:$dataId;request-id:$requestId;ts:$ts;";
        return hash_equals(hash_hmac('sha256',$message,$secret),strtolower($sig));
    }

    private static function call(string $method,string $path,string $token,?array $body=null,?string $key=null): array
    {
        if ($token==='') throw new \RuntimeException('Credencial do PSP não configurada');
        if (!function_exists('curl_init')) throw new \RuntimeException('Extensão PHP cURL necessária para integrar o PSP');
        $ch=curl_init(self::BASE.$path);
        $headers=['Authorization: Bearer '.$token,'Accept: application/json','Content-Type: application/json'];
        if ($key !== null) $headers[]='X-Idempotency-Key: '.$key;
        curl_setopt_array($ch,[
            CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>12,CURLOPT_CONNECTTIMEOUT=>5,
            CURLOPT_HTTPHEADER=>$headers,CURLOPT_CUSTOMREQUEST=>$method,
            CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,
        ]);
        if ($body !== null) curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($body,JSON_THROW_ON_ERROR));
        $resp=curl_exec($ch);
        $http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
        if ($resp === false) throw new \RuntimeException('Falha de conectividade com o PSP');
        if ($http < 200 || $http >= 300) throw new \RuntimeException('PSP retornou HTTP '.$http);
        $data=json_decode($resp,true);
        if (!is_array($data)) throw new \RuntimeException('Resposta inesperada do PSP');
        return $data;
    }
}
