<?php
declare(strict_types=1);
namespace ArgusPayments\Integrations;

/**
 * Dedicated MisticPay Finance QRCODES API. Unlike legacy split charges, a Finance
 * charge needs only amountCents + description; payer PII is neither invented nor sent.
 * Credentials must be obtained separately from Configurações > API QR Codes.
 */
/** Safe provider error metadata; credentials and raw bodies are never exposed. */
final class MisticPayFinanceHttpException extends \RuntimeException
{
    public function __construct(public readonly int $httpStatus, public readonly string $providerCode, public readonly string $providerRequestId='')
    {
        parent::__construct('MisticPay Finance respondeu HTTP '.$httpStatus.' ('.$providerCode.')');
    }
}

final class MisticPayFinance
{
    private const BASE = 'https://api.finance.misticpay.com';
    private $sender;

    public function __construct(private string $clientId, private string $clientSecret, ?callable $sender=null)
    {
        if (strlen(trim($clientId)) < 8 || strlen(trim($clientSecret)) < 12 ||
            preg_match('/[\r\n]/', $clientId.$clientSecret)) {
            throw new \InvalidArgumentException('Credencial MisticPay Finance QRCODES ausente');
        }
        $this->sender=$sender;
    }

    public static function configured(): bool
    {
        return strlen(trim((string)getenv('ARGUS_FINANCE_QR_CLIENT_ID'))) >= 8 &&
            strlen(trim((string)getenv('ARGUS_FINANCE_QR_CLIENT_SECRET'))) >= 12;
    }

    /** Read-only authorization probe. A random nonexistent charge should return 404 CHARGE_NOT_FOUND. */
    public function credentialsStatus():array
    {
        try {
            $this->request('GET','/v1/public/charges/argus_probe_'.bin2hex(random_bytes(8)));
            return ['status'=>'unverified','http_status'=>200];
        } catch (MisticPayFinanceHttpException $e) {
            $status=match(true){
                $e->httpStatus===404 && $e->providerCode==='CHARGE_NOT_FOUND' => 'verified',
                $e->httpStatus===401 => 'invalid_credentials',
                $e->httpStatus===403 => 'access_denied',
                $e->httpStatus===404 => 'unverified',
                $e->httpStatus===429 => 'rate_limited',
                default => 'unavailable',
            };
            return ['status'=>$status,'http_status'=>$e->httpStatus,'provider_code'=>$e->providerCode];
        } catch (\Throwable $e) {
            return ['status'=>'unavailable','http_status'=>0];
        }
    }

    public function create(int $amountCents,string $idem,string $description):array
    {
        if($amountCents<100||$amountCents>10000)throw new \InvalidArgumentException('Pix limitado entre R$ 1 e R$ 100 no piloto');
        if(!preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/iD',$idem)) {
            throw new \InvalidArgumentException('Identificador de idempotência UUID obrigatório');
        }
        $result=$this->request('POST','/v1/public/charges',['amountCents'=>$amountCents,'description'=>$description],$idem);
        return $this->normalize($result, true);
    }

    public function check(string $id):array
    {
        if(!preg_match('/^[A-Za-z0-9_-]{4,120}$/D',$id))throw new \InvalidArgumentException('ID de cobrança inválido');
        return $this->normalize($this->request('GET','/v1/public/charges/'.rawurlencode($id)),false);
    }

    private function normalize(array $result,bool $requireQr):array
    {
        $data=$result['data']??$result;
        if(isset($data['charge'])&&is_array($data['charge']))$data=$data['charge'];
        if(!is_array($data))throw new \RuntimeException('MisticPay Finance retornou objeto inválido');
        $id=$data['id']??$data['charge_id']??$data['chargeId']??null;
        $qr=$data['qr_code']??$data['qrCode']??$data['pix_copy_paste']??$data['copyPaste']??'';
        $status=strtoupper((string)($data['status']??'PENDING'));
        if(!is_string($id)||!preg_match('/^[A-Za-z0-9_-]{4,120}$/D',$id))throw new \RuntimeException('MisticPay Finance não retornou ID válido');
        if(!is_string($qr)||strlen($qr)>10000||($requireQr&&strlen($qr)<20))throw new \RuntimeException('MisticPay Finance não retornou Pix Copia e Cola válido');
        $amount=$data['amount_cents']??$data['amountCents']??null;
        if($amount!==null&&(!ctype_digit((string)$amount)||((int)$amount)<1))throw new \RuntimeException('Valor na resposta da MisticPay inválido');
        return ['provider_id'=>$id,'qr_code'=>$qr,'status'=>$status,'amount_cents'=>$amount===null?null:(int)$amount];
    }

    private function request(string $method,string $path,?array $payload=null,?string $idem=null):array
    {
        $headers=['Authorization: Basic '.base64_encode($this->clientId.':'.$this->clientSecret),'Accept: application/json'];
        if($payload!==null)$headers[]='Content-Type: application/json';
        if($idem!==null)$headers[]='x-idempotency-key: '.$idem;
        // Testing uses a fake transport; never contacts the real processor.
        if($this->sender!==null){
            $response=($this->sender)($method,self::BASE.$path,$payload,$headers);
            if(!is_array($response))throw new \RuntimeException('Resposta simulada inválida');
            if((int)($response['statusCode']??0)>=400){
                $code=(string)($response['code']??'UNCLASSIFIED');
                if(!preg_match('/^[A-Z0-9_]{1,64}$/D',$code))$code='UNCLASSIFIED';
                throw new MisticPayFinanceHttpException((int)$response['statusCode'],$code);
            }
            return $response;
        }
        $json=$payload===null?'':json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
        $context=stream_context_create([
            'http'=>['method'=>$method,'header'=>implode("\r\n",$headers),'content'=>$json,
                'timeout'=>10,'ignore_errors'=>true,'follow_location'=>0,'max_redirects'=>0,'protocol_version'=>1.1],
            'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true],
        ]);
        $response=@file_get_contents(self::BASE.$path,false,$context);
        $headers=$http_response_header??[];
        $first=$headers[0]??'';
        $status=preg_match('/\s(\d{3})(?:\s|$)/',$first,$m)?(int)$m[1]:0;
        if($status>=400){
            $error=is_string($response)?json_decode(substr($response,0,16000),true):null;
            $code=is_array($error)?strtoupper((string)($error['code']??'UNCLASSIFIED')):'UNCLASSIFIED';
            if(!preg_match('/^[A-Z0-9_]{1,64}$/D',$code))$code='UNCLASSIFIED';
            $requestId=is_array($error)?(string)($error['requestId']??''):'';
            if(!preg_match('/^[a-zA-Z0-9_-]{8,80}$/D',$requestId))$requestId='';
            throw new MisticPayFinanceHttpException($status,$code,$requestId);
        }
        if($response===false||$status===0)throw new \RuntimeException('Resposta da MisticPay indisponível; não repita a emissão automaticamente');
        if($status<200||$status>=300)throw new \RuntimeException('Resposta HTTP inesperada da MisticPay');
        if(strlen($response)>1000000)throw new \RuntimeException('Resposta da MisticPay excessiva');
        $parsed=json_decode($response,true,30);
        if(!is_array($parsed))throw new \RuntimeException('Resposta JSON inválida da MisticPay');
        return $parsed;
    }
}
