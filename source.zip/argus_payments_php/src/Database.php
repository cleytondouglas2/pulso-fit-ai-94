<?php
declare(strict_types=1);
namespace ArgusPayments;

use PDO;
use PDOException;

final class Database
{
    private PDO $pdo;
    private string $driver;

    public function __construct(array $config)
    {
        $this->driver = (string) $config['driver'];
        if (!in_array($this->driver, ['sqlite', 'mysql'], true)) {
            throw new \RuntimeException('Driver de banco indisponível. Use sqlite ou mysql.');
        }
        if ($this->driver === 'sqlite') {
            $path = (string) $config['sqlite_path'];
            if (!is_dir(dirname($path)) && !mkdir(dirname($path), 0700, true) && !is_dir(dirname($path))) {
                throw new \RuntimeException('Não foi possível criar diretório privado do banco.');
            }
            $dsn = 'sqlite:' . $path;
            $this->pdo = new PDO($dsn, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            $this->pdo->exec('PRAGMA journal_mode = WAL');
            $this->pdo->exec('PRAGMA busy_timeout = 20000');
            $this->pdo->exec('PRAGMA foreign_keys = ON');
        } else {
            $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', $config['mysql_host'], $config['mysql_port'], $config['mysql_database']);
            $this->pdo = new PDO($dsn, $config['mysql_user'], $config['mysql_password'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        }
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }

    public function pdo(): PDO { return $this->pdo; }
    public function driver(): string { return $this->driver; }

    public function run(string $sql, array $args = []): \PDOStatement
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(array_values($args));
        return $stmt;
    }

    public function one(string $sql, array $args = []): ?array
    {
        $row = $this->run($sql, $args)->fetch();
        return $row === false ? null : $row;
    }

    public function all(string $sql, array $args = []): array { return $this->run($sql, $args)->fetchAll(); }

    public function transaction(callable $fn): mixed
    {
        $this->pdo->beginTransaction();
        try {
            $value = $fn($this);
            $this->pdo->commit();
            return $value;
        } catch (\Throwable $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            throw $e;
        }
    }

    public function installAndSeed(): void
    {
        $mysql = $this->driver === 'mysql';
        $k = $mysql ? 'VARCHAR(120)' : 'TEXT';
        $s = $mysql ? 'VARCHAR(255)' : 'TEXT';
        $email = $mysql ? 'VARCHAR(190)' : 'TEXT';
        $n = $mysql ? 'BIGINT' : 'INTEGER';
        $small = $mysql ? 'INT' : 'INTEGER';
        $detail = $mysql ? 'TEXT' : 'TEXT';
        $schema = [
            "CREATE TABLE IF NOT EXISTS merchants (id $k PRIMARY KEY, business $s NOT NULL, email $email NOT NULL)",
            "CREATE TABLE IF NOT EXISTS sessions (secret_hash VARCHAR(64) PRIMARY KEY, merchant_id $k NOT NULL, expires_at $n NOT NULL)",
            "CREATE TABLE IF NOT EXISTS payments (id $k PRIMARY KEY, merchant_id $k NOT NULL, amount_cents $n NOT NULL, method VARCHAR(12) NOT NULL, customer_name $s NOT NULL, customer_email $email NOT NULL, description $s NOT NULL, status VARCHAR(15) NOT NULL DEFAULT 'pending', provider VARCHAR(24) NOT NULL DEFAULT 'sandbox', created_at VARCHAR(32) NOT NULL, paid_at VARCHAR(32), link_slug VARCHAR(60), refunded_at VARCHAR(32))",
            "CREATE TABLE IF NOT EXISTS customers (id $k PRIMARY KEY, merchant_id $k NOT NULL, name $s NOT NULL, email $email NOT NULL, created_at VARCHAR(32) NOT NULL, UNIQUE(merchant_id,email))",
            "CREATE TABLE IF NOT EXISTS links (slug VARCHAR(60) PRIMARY KEY, merchant_id $k NOT NULL, title $s NOT NULL, amount_cents $n NOT NULL, active $small NOT NULL DEFAULT 1, created_at VARCHAR(32) NOT NULL)",
            "CREATE TABLE IF NOT EXISTS subscriptions (id $k PRIMARY KEY, merchant_id $k NOT NULL, name $s NOT NULL, email $email NOT NULL, plan $s NOT NULL, amount_cents $n NOT NULL, frequency VARCHAR(10) NOT NULL, status VARCHAR(12) NOT NULL, next_charge VARCHAR(12) NOT NULL, created_at VARCHAR(32) NOT NULL)",
            "CREATE TABLE IF NOT EXISTS split_rules (id $k PRIMARY KEY, merchant_id $k NOT NULL, recipient $s NOT NULL, percent $small NOT NULL, created_at VARCHAR(32) NOT NULL)",
            "CREATE TABLE IF NOT EXISTS api_keys (id $k PRIMARY KEY, merchant_id $k NOT NULL, label $s NOT NULL, key_hash VARCHAR(64) NOT NULL UNIQUE, prefix VARCHAR(40) NOT NULL, created_at VARCHAR(32) NOT NULL, revoked_at VARCHAR(32))",
            "CREATE TABLE IF NOT EXISTS idempotency (merchant_id $k NOT NULL, key_hash VARCHAR(64) NOT NULL, body_hash VARCHAR(64) NOT NULL, payment_id $k NOT NULL, PRIMARY KEY(merchant_id,key_hash))",
            "CREATE TABLE IF NOT EXISTS events (id $k PRIMARY KEY, merchant_id $k NOT NULL, action VARCHAR(90) NOT NULL, detail $detail NOT NULL, created_at VARCHAR(32) NOT NULL)",
        ];
        foreach ($schema as $sql) $this->pdo->exec($sql);

        // Todos os registros iniciais são fictícios e usados somente para demonstração.
        if ($this->one('SELECT id FROM merchants WHERE id=?', ['merchant_demo']) === null) {
            $this->run('INSERT INTO merchants(id,business,email) VALUES (?,?,?)', ['merchant_demo', 'Loja Aurora', 'demo@arguspayments.local']);
        }
        $count = (int) ($this->one('SELECT COUNT(*) as total FROM payments WHERE merchant_id=?', ['merchant_demo'])['total'] ?? 0);
        if ($count > 0) return;
        $this->transaction(function (Database $db): void {
            $names = [
                ['Ana Ferreira','ana@exemplo.com'], ['Bruno Costa','bruno@exemplo.com'],
                ['Mariana Silva','mariana@exemplo.com'], ['Rafael Lima','rafael@exemplo.com'],
                ['Camila Rocha','camila@exemplo.com'], ['Lucas Mendes','lucas@exemplo.com'],
                ['Fernanda Alves','fernanda@exemplo.com'], ['Pedro Martins','pedro@exemplo.com'],
            ];
            $amounts = [12990,24990,7990,39900,15990,5990,8990,19990,42990,12990,9990,7490,28990,5990,16990,32990,14990,59900,7990,21990,3990,18590,11590,29590,8990,13490,7390,26990];
            $methods = ['pix','card','pix','pix','boleto','card','pix'];
            $descs = ['Assinatura Pro','Compra na loja','Consultoria digital','Plano Premium'];
            foreach ($amounts as $i => $amount) {
                [$name, $email] = $names[$i % count($names)];
                $date = gmdate('Y-m-d\TH:i:s\Z', time() - intdiv($i * 7, count($amounts)) * 86400 - (($i * 3) % 15) * 3600 - $i * 420);
                $status = $i % 7 !== 4 && $i % 7 !== 6 ? 'paid' : ($i % 7 === 4 ? 'pending' : 'failed');
                $db->run('INSERT INTO payments(id,merchant_id,amount_cents,method,customer_name,customer_email,description,status,provider,created_at,paid_at,link_slug,refunded_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    [self::uid('pay'),'merchant_demo',$amount,$methods[$i % count($methods)],$name,$email,$descs[$i % 4],$status,'sandbox',$date,$status === 'paid' ? $date : null,null,null]);
                $db->ensureCustomer('merchant_demo',$name,$email,$date);
            }
            foreach (array_slice($names,0,4) as $i => [$name,$email]) {
                $frequency = $i === 3 ? 'weekly' : 'monthly';
                $db->run('INSERT INTO subscriptions(id,merchant_id,name,email,plan,amount_cents,frequency,status,next_charge,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
                    [self::uid('sub'),'merchant_demo',$name,$email,['Pro','Essencial','Business','Plus'][$i],[3990,1990,8990,2990][$i],$frequency,$i === 2 ? 'paused' : 'active',gmdate('Y-m-d',time() + (6 + $i * 4) * 86400),self::stamp()]);
            }
            foreach ([['Plano Premium',4990],['Consultoria express',14990],['Produto digital',2990]] as [$title,$amount]) {
                $db->run('INSERT INTO links(slug,merchant_id,title,amount_cents,active,created_at) VALUES (?,?,?,?,?,?)',
                    [self::slug(),'merchant_demo',$title,$amount,1,self::stamp()]);
            }
            $db->audit('merchant_demo','sandbox.initialized','Amostras ilustrativas criadas, sem transações reais.');
        });
    }

    public function ensureCustomer(string $merchantId, string $name, string $email, ?string $date = null): void
    {
        if ($this->one('SELECT id FROM customers WHERE merchant_id=? AND email=?', [$merchantId,$email])) return;
        try {
            $this->run('INSERT INTO customers(id,merchant_id,name,email,created_at) VALUES (?,?,?,?,?)',
                [self::uid('cus'),$merchantId,$name,$email,$date ?? self::stamp()]);
        } catch (PDOException $ex) {
            // Uma criação simultânea do mesmo cliente não deve duplicar o cadastro.
            if ($this->one('SELECT id FROM customers WHERE merchant_id=? AND email=?', [$merchantId,$email])) return;
            throw $ex;
        }
    }

    public function audit(string $merchantId, string $action, string $detail): void
    {
        $this->run('INSERT INTO events(id,merchant_id,action,detail,created_at) VALUES (?,?,?,?,?)',
            [self::uid('evt'),$merchantId,$action,substr($detail,0,500),self::stamp()]);
    }

    public static function uid(string $prefix): string { return $prefix . '_' . bin2hex(random_bytes(7)); }
    public static function slug(): string { return rtrim(strtr(base64_encode(random_bytes(9)),'+/','-_'),'='); }
    public static function stamp(): string { return gmdate('Y-m-d\TH:i:s\Z'); }
}
