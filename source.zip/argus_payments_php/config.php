<?php
declare(strict_types=1);
return array_replace([
    'driver' => getenv('ARGUS_DB_DRIVER') ?: 'sqlite',
    'sqlite_path' => getenv('ARGUS_SQLITE_PATH') ?: __DIR__ . '/storage/argus_payments.sqlite',
    'pgsql_url' => getenv('ARGUS_PGSQL_URL') ?: '',
    'pgsql_schema' => getenv('ARGUS_PGSQL_SCHEMA') ?: 'argus_payments_b2b',
    'pgsql_host' => getenv('ARGUS_PGSQL_HOST') ?: 'localhost',
    'pgsql_port' => getenv('ARGUS_PGSQL_PORT') ?: '5432',
    'pgsql_database' => getenv('ARGUS_PGSQL_DATABASE') ?: 'argus',
    'pgsql_user' => getenv('ARGUS_PGSQL_USER') ?: 'argus',
    'pgsql_password' => getenv('ARGUS_PGSQL_PASSWORD') ?: '',
    'mysql_host' => getenv('ARGUS_MYSQL_HOST') ?: 'localhost',
    'mysql_port' => getenv('ARGUS_MYSQL_PORT') ?: '3306',
    'mysql_database' => getenv('ARGUS_MYSQL_DATABASE') ?: 'argus_payments',
    'mysql_user' => getenv('ARGUS_MYSQL_USER') ?: 'root',
    'mysql_password' => getenv('ARGUS_MYSQL_PASSWORD') ?: '',
    'cookie_secure' => filter_var(getenv('ARGUS_COOKIE_SECURE') ?: 'false', FILTER_VALIDATE_BOOLEAN),
    'sandbox' => true, // Trava intencional: este projeto nunca aciona pagamentos reais
], is_file(__DIR__ . '/config.local.php') ? require __DIR__ . '/config.local.php' : []);
