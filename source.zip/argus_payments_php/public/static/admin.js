'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const state={user:null,merchants:[],payments:[],payers:[],keys:[],overview:null,page:'dashboard'};
const fmt=n=>(Number(n||0)/100).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const time=s=>s?new Date(s).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo'}):'—';
const csrf=()=>decodeURIComponent((document.cookie.match(/(?:^|;\s*)arg_admin_csrf=([^;]*)/)||[])[1]||'');
let toastTimer;
function toast(s,bad=false){const el=$('#toast');el.textContent=s;el.classList.toggle('bad',bad);el.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.hidden=true,6500)}
async function api(path,options={}){const cfg={credentials:'same-origin',cache:'no-store',...options};if(cfg.body&&typeof cfg.body!=='string')cfg.body=JSON.stringify(cfg.body);if(cfg.body){cfg.headers={'Content-Type':'application/json','X-CSRF-Token':csrf(),...(cfg.headers||{})}}const resp=await fetch(path,cfg);let result;try{result=await resp.json()}catch{throw Error('Resposta inesperada do servidor')};if(!resp.ok){const e=Error(result.detail||`Erro ${resp.status}`);e.status=resp.status;throw e}return result}
const post=(url,body={})=>api(url,{method:'POST',body});
let displayedStage='';
function view(name){
 const screens={login:$('#login-screen'),password:$('#password-screen'),mfa:$('#mfa-screen'),workspace:$('#workspace')};
 for(const [key,el] of Object.entries(screens)){
  const show=key===name;el.hidden=!show;
  if(show&&name!==displayedStage){el.classList.remove('scene-enter');void el.offsetWidth;el.classList.add('scene-enter')}
 }
 displayedStage=name;
 const boot=$('#boot-screen');if(boot&&!boot.hidden)boot.hidden=true;
} 
const canWrite=()=>state.user&&['admin','superadmin'].includes(state.user.role);
function dialog(title,content,subtitle='ADMINISTRAÇÃO'){ $('#modal-title').textContent=title;$('#modal-subtitle').textContent=subtitle;$('#modal-content').innerHTML=content;$('#modal').showModal()}
function closeDialog(){$('#modal').close()}
$('#modal-close').onclick=closeDialog;
$('#modal').addEventListener('click',e=>{if(e.target===$('#modal'))closeDialog()});
function formValues(form){return Object.fromEntries(new FormData(form).entries())}
function badge(status){const label={pending_review:'Em análise',approved_live:'Aprovado',suspended:'Suspenso',rejected:'Rejeitado',pending:'Aguardando Pix',paid:'Pago',creating:'Criando',unknown:'Verificar',failed:'Falhou',expired:'Expirou',active:'Ativo'}[status]||status;return `<span class="status-badge ${esc(status)}">${esc(label)}</span>`}
function empty(col,text='Nenhum registro encontrado'){return `<tr><td class="empty" colspan="${col}">${esc(text)}</td></tr>`}
let pageSequence=0;
function navigate(page){
 if(page==='users'&&state.user?.role!=='superadmin')return;
 if(page==='wallet'&&state.user?.role!=='superadmin')return;
 if(page==='charge-create'&&!canWrite())return;
 if(state.page===page&&!$('#page-'+page).hidden&&$('#page-progress').hidden===false)return;
 state.page=page;const seq=++pageSequence;if(location.hash.slice(1)!==page)history.replaceState(null,'','#'+page);
 $$('[data-nav]').forEach(el=>el.classList.toggle('active',el.dataset.nav===page));
 $$('.page').forEach(el=>{const next=el.id===`page-${page}`;el.hidden=!next;
   if(next){el.classList.remove('page-enter');void el.offsetWidth;el.classList.add('page-enter')}});
 const names={dashboard:'Visão geral',merchants:'Empresas e split',payers:'Clientes e pagadores',payments:'Transações','charge-create':'Gerar Pix',wallet:'Saldo e transferências',keys:'Chaves de API',reports:'Relatórios financeiros',audit:'Auditoria',users:'Equipe e permissões'};
 $('#crumb').textContent=names[page];$('#page-heading').textContent=names[page];
 $('#page-progress').hidden=false;
 Promise.resolve(loadPage(page)).catch(err=>{if(seq===pageSequence)toast(err.message,true)}).finally(()=>{if(seq===pageSequence)$('#page-progress').hidden=true});
 closeMobileMenu();window.scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
}
function closeMobileMenu(){const side=$('#admin-sidebar'),back=$('#mobile-menu-backdrop'),btn=$('#mobile-menu-toggle');if(side)side.classList.remove('mobile-open');if(back)back.hidden=true;if(btn)btn.setAttribute('aria-expanded','false')}
const navToggle=$('#mobile-menu-toggle');if(navToggle){const backdrop=document.createElement('div');backdrop.id='mobile-menu-backdrop';backdrop.className='mobile-menu-backdrop';backdrop.hidden=true;$('#workspace').insertBefore(backdrop,$('#admin-sidebar'));navToggle.onclick=()=>{const open=!$('#admin-sidebar').classList.contains('mobile-open');$('#admin-sidebar').classList.toggle('mobile-open',open);backdrop.hidden=!open;navToggle.setAttribute('aria-expanded',String(open))};backdrop.onclick=closeMobileMenu;window.addEventListener('keydown',e=>{if(e.key==='Escape')closeMobileMenu()})}
$$('[data-nav]').forEach(btn=>btn.onclick=()=>navigate(btn.dataset.nav));$$('[data-shortcut]').forEach(btn=>btn.onclick=()=>navigate(btn.dataset.shortcut));
function signin(data){state.user=data.user;$('#account-name').textContent=data.user.display_name;$('#account-role').textContent=data.user.role==='superadmin'?'Super Admin':data.user.role==='admin'?'Administrador':'Analista';$('.avatar').textContent=data.user.display_name.slice(0,2).toUpperCase();$$('.super-only').forEach(x=>x.hidden=data.user.role!=='superadmin');$$('.editor-only').forEach(x=>x.hidden=!canWrite());if(data.user.must_change_password){view('password')}else if(!data.user.mfa_verified){view('mfa');showMfa(data.user.mfa_enabled).catch(e=>toast(e.message,true))}else{view('workspace');const requested=location.hash.slice(1);navigate(['payments','charge-create','dashboard','merchants','payers','wallet','keys','reports','audit','users'].includes(requested)?requested:'dashboard')}}
let mfaSetupSecret='';
async function showMfa(enabled){$('#mfa-enroll').hidden=!!enabled;$('#mfa-challenge').hidden=!enabled;if(!enabled){const d=await api('/api/admin/mfa/setup');mfaSetupSecret=d.secret;$('#mfa-secret').textContent=d.secret}else{mfaSetupSecret='';$('#mfa-secret').textContent=''}}
$('#mfa-copy').onclick=async()=>{try{await navigator.clipboard.writeText(mfaSetupSecret);toast('Chave do autenticador copiada')}catch{toast('Selecione a chave e copie manualmente',true)}};
$('#mfa-form').onsubmit=async e=>{e.preventDefault();const code=String(new FormData(e.target).get('code')||'');try{await post(mfaSetupSecret?'/api/admin/mfa/activate':'/api/admin/mfa/verify',{code});mfaSetupSecret='';e.target.reset();const data=await api('/api/admin/session');signin(data);toast('Autenticação 2FA confirmada')}catch(err){toast(err.message,true)}};
$('#mfa-logout').onclick=async()=>{try{await post('/api/admin/logout')}catch{}mfaSetupSecret='';state.user=null;view('login')};
$('#login-form').addEventListener('submit',async e=>{e.preventDefault();const btn=e.target.querySelector('button');btn.disabled=true;btn.setAttribute('aria-busy','true');try{const data=await post('/api/admin/login',formValues(e.target));signin(data);e.target.reset()}catch(err){toast(err.message,true)}finally{btn.disabled=false;btn.removeAttribute('aria-busy')}});
$('#password-form').addEventListener('submit',async e=>{e.preventDefault();const d=formValues(e.target);if(d.new_password!==d.repeat_password){toast('As senhas não coincidem',true);return}try{await post('/api/admin/change-password',{current_password:d.current_password,new_password:d.new_password});view('login');toast('Senha alterada. Entre novamente com sua nova senha.');e.target.reset()}catch(err){toast(err.message,true)}});
$('#logout').onclick=async()=>{try{await post('/api/admin/logout')}catch{}state.user=null;view('login')};
async function loadPage(page){if(page==='dashboard')return loadDashboard();if(page==='charge-create')return loadCreatePix();if(page==='wallet')return loadWallet();if(page==='merchants')return loadMerchants();if(page==='payers')return loadPayers();if(page==='payments')return loadPayments();if(page==='keys')return loadKeys();if(page==='reports')return loadReports();if(page==='audit')return loadAudit();if(page==='users')return loadUsers()}
async function loadDashboard(){const v=await api('/api/admin/overview');state.overview=v;const m=v.merchants,p=v.pix;$('#kpi-merchants').textContent=m.total;$('#kpi-approved').textContent=m.active;$('#kpi-pending').textContent=`${m.pending} em análise · ${m.suspended} suspensos`;$('#kpi-paid').textContent=fmt(p.paid_cents);$('#kpi-fees').textContent=fmt(p.commission_estimate_cents);const r=v.integration;$('#integration-pill').textContent=r.ready?'API habilitada':'Configuração pendente';$('#integration-pill').style.opacity=r.ready?'1':'.65';const names={explicit_activation:'Modo Pix real',persistent_database:'Banco persistente',storage_policy:'Política de armazenamento',provider_create_read_key:'Chaves MisticPay',split_direction_authorized:'Direção do split',provider_split_confirmed:'Split habilitado',strong_operator_secret:'Acesso de operador',payer_blocklist_secret:'Bloqueio por CPF',protected_webhook:'Webhook protegido',https_callback:'Callback HTTPS'};$('#checks').innerHTML=Object.entries(r.checks||{}).map(([k,val])=>`<span class="check ${val?'':'missing'}">${val?'✓':'!'} ${esc(names[k]||k)}</span>`).join('');$('#payment-mode').textContent=r.livemode?'Pix real':'Desativado';$('#db-mode').textContent=r.shared_database_risk?'PostgreSQL compartilhado':'Banco exclusivo';$('#pix-limit').textContent=r.temporary_pilot?fmt(r.temporary_pilot_max_charge_cents):'Conforme contrato';$('#pilot-end').textContent=r.temporary_pilot?time(r.temporary_pilot_expires_at):'Não se aplica';void loadDemoInsights()}
async function loadDemoInsights(){
 const today=new Date(),from=new Date(today.valueOf()-13*86400000),day=d=>d.toISOString().slice(0,10);const first=day(from),last=day(today);
 const startEl=$('#trend-start'),endEl=$('#trend-end');if(startEl)startEl.textContent=from.toLocaleDateString('pt-BR',{day:'2-digit',month:'short'});if(endEl)endEl.textContent=today.toLocaleDateString('pt-BR',{day:'2-digit',month:'short'});
 const [reports,charges]=await Promise.allSettled([api(`/api/admin/reports?from=${encodeURIComponent(first)}&to=${encodeURIComponent(last)}`),api('/api/admin/charges?status=all&merchant=')]);
 if(reports.status==='fulfilled'){
  const rows=reports.value.daily||[],totals=new Map(rows.map(x=>[x.day,Number(x.paid_cents)||0]));const values=Array.from({length:14},(_,i)=>totals.get(day(new Date(from.valueOf()+i*86400000)))||0);
  $('#trend-total').textContent=fmt(values.reduce((a,b)=>a+b,0));const high=Math.max(1,...values),w=700,h=150,pad=9;const pt=values.map((v,i)=>[pad+(i/(values.length-1))*(w-2*pad),h-pad-(v/high)*(h-2*pad)]);
  const path=pt.map(([x,y],i)=>`${i?'L':'M'}${x.toFixed(1)} ${y.toFixed(1)}`).join(' ');const area=`${path} L${(w-pad).toFixed(1)} ${h} L${pad} ${h} Z`;
  $('#trend-graph').innerHTML=`<svg viewBox="0 0 700 170" preserveAspectRatio="none" role="img" aria-label="Volume recebido em Pix, últimos catorze dias" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="gold-area" x1="0" x2="0" y1="0" y2="1"><stop stop-color="#d9b16b" stop-opacity=".26"/><stop offset="1" stop-color="#d9b16b" stop-opacity="0"/></linearGradient></defs><g stroke="#34383b" stroke-width="1"><path d="M9 18H691 M9 55H691 M9 93H691 M9 130H691"/></g><path d="${area}" fill="url(#gold-area)"/><path d="${path}" fill="none" stroke="#e2b66d" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/></svg>`;
 }else{$('#trend-total').textContent='Indisponível';$('#trend-graph').textContent='Não foi possível consultar o relatório. Atualize o painel.'}
 if(charges.status==='fulfilled'){
  const rows=charges.value.slice(0,5);$('#recent-activity').innerHTML=rows.map(x=>`<div class="recent-line"><span class="recent-icon">↗</span><div class="recent-info"><b>${esc(x.legal_name)}</b><small>${esc(x.payer_name)} · ${time(x.created_at)}</small></div><div class="recent-amount"><b>${fmt(x.amount_cents)}</b><small>${esc(({paid:'Pago',pending:'Pendente',unknown:'Conferir',failed:'Falha',expired:'Expirado'})[x.status]||x.status)}</small></div></div>`).join('')||'<div class="charge-placeholder" style="padding:25px 10px"><p>Nenhuma transação Pix real registrada até agora.</p></div>';
 }else{$('#recent-activity').textContent='Não foi possível consultar as transações.'}
}
function pixAmountCents(){
 const raw=$('#simple-pix-value').value.trim().replace(/\s/g,'');
 if(!/^(?:\d{1,5})(?:[,.]\d{1,2})?$/.test(raw))return 0;
 return Math.round(Number(raw.replace(',','.'))*100);
}
let financePixConfigured=null;
function refreshPixButton(){
 const cents=pixAmountCents(),submit=$('#charge-submit');
 submit.disabled=!!submit.dataset.busy||cents<100||cents>10000;
 if(cents>10000){$('#simple-pix-help').textContent='Piloto Pix: máximo de R$ 100 por cobrança.'}
 else if(cents>0&&cents<100){$('#simple-pix-help').textContent='Valor mínimo para a cobrança: R$ 1,00.'}
 else{$('#simple-pix-help').textContent='Recebimento na conta ARGUS Payments. Não há split com empresas nesta modalidade.'}
}
$('#simple-pix-value').addEventListener('input',refreshPixButton);
async function loadCreatePix(){
 const warning=$('#pix-config-alert');warning.hidden=true;
 refreshPixButton();
 try{
  const cfg=await api('/api/admin/quick-pix/config');
  financePixConfigured=!!cfg.configured;
  if(!cfg.ready){warning.textContent='O piloto Pix não está disponível. Confirme a ativação no dashboard.';warning.hidden=false;return}
  if(!financePixConfigured){warning.textContent='Para emitir o Pix real somente com valor, falta a credencial QRCODES da MisticPay Finance. Configure ARGUS_FINANCE_QR_CLIENT_ID e ARGUS_FINANCE_QR_CLIENT_SECRET na Render. Você pode digitar o valor, mas nenhuma cobrança será enviada até configurar as chaves.';warning.hidden=false}
 }catch(err){warning.textContent='Falha ao verificar a API Pix. '+err.message;warning.hidden=false}
}

let chargeLastId='';
$('#charge-create-form').onsubmit=async event=>{
 event.preventDefault();if(!canWrite())return;
 const form=event.target,v=formValues(form),amount=Math.round(Number(String(v.amount).trim().replace(',','.'))*100);
 if(!Number.isInteger(amount)||amount<100||amount>10000){toast('No piloto, o Pix deve ser entre R$ 1 e R$ 100.',true);return}
 if(financePixConfigured===false){const w=$('#pix-config-alert');w.hidden=false;w.textContent='Pix com somente valor indisponível até cadastrar o Client ID e Client Secret da MisticPay Finance na Render.';toast('Faltam credenciais QRCODES da MisticPay Finance. Nenhum Pix foi criado.',true);return}
 if(!confirm('Gerar cobrança PIX REAL de '+fmt(amount)+' na conta ARGUS Payments? O recebimento nesta modalidade não usa split de lojistas.'))return;
 const key=form.dataset.idempotencyKey||crypto.randomUUID();form.dataset.idempotencyKey=key;
 const btn=$('#charge-submit');btn.dataset.busy='1';btn.disabled=true;btn.setAttribute('aria-busy','true');
 try{
  const result=await post('/api/admin/quick-pix',{amount_cents:amount,idempotency_key:key});
  if(result.status==='unknown'||result.status==='creating')throw Error('Não foi possível confirmar a emissão. Não gere outro Pix até conferir o protocolo '+result.id);
  showChargeReceipt(result);
  form.reset();delete form.dataset.idempotencyKey;
  toast('Pix gerado na MisticPay Finance. Pagamento ainda não confirmado.');
 }catch(err){toast(err.message,true);$('#charge-note').textContent='Se a criação ficou incerta, não emita novamente com outra chave. Guarde o protocolo e solicite conciliação.'}
 finally{btn.removeAttribute('aria-busy');delete btn.dataset.busy;refreshPixButton()}
};
function showChargeReceipt(data){
 chargeLastId=data.id||'';$('#charge-placeholder').hidden=true;$('#charge-receipt').hidden=false;$('#charge-receipt-id').textContent=data.id||'—';$('#charge-amount').textContent=fmt(data.amount_cents);$('#charge-receipt-state').textContent=data.status==='paid'?'Pago':'Aguardando pagamento';$('#charge-code').value=data.pix_copy_paste||'';$('#charge-copy').disabled=!data.pix_copy_paste;$('#charge-note').textContent=data.pix_copy_paste?'Pix emitido. A confirmação financeira só ocorre após consulta autenticada à MisticPay.':'Sem Pix Copia e Cola disponível. Verifique a cobrança e não crie duplicatas.'
}
$('#charge-copy').onclick=async()=>{try{await navigator.clipboard.writeText($('#charge-code').value);toast('Pix Copia e Cola copiado')}catch{try{$('#charge-code').select();document.execCommand('copy');toast('Código copiado')}catch{toast('Selecione o código e copie manualmente',true)}}};
$('#charge-reconcile').onclick=async()=>{if(!chargeLastId)return;try{const result=await post('/api/admin/quick-pix/'+encodeURIComponent(chargeLastId)+'/reconcile');const status=result.charge?.status||result.status;$('#charge-receipt-state').textContent=status==='paid'?'Pago e confirmado':status==='pending'?'Aguardando pagamento':status;toast('Consulta autenticada à MisticPay: '+status)}catch(err){toast(err.message,true)}};
async function loadMerchants(){state.merchants=await api('/api/admin/merchants');renderMerchants()}
function renderMerchants(){const q=$('#merchant-search').value.toLowerCase(),filter=$('#merchant-status-filter').value;const merchants=state.merchants.filter(m=>(filter==='all'||m.status===filter)&&`${m.legal_name} ${m.cnpj} ${m.email}`.toLowerCase().includes(q));$('#merchant-rows').innerHTML=merchants.map(m=>`<tr><td><b>${esc(m.legal_name)}</b><small>${esc(m.email)}</small></td><td>${esc(m.cnpj)}</td><td>${(m.commission_bps/100).toFixed(2).replace('.',',')}%</td><td>${badge(m.status)}</td><td>${Number(m.active_keys)||0}</td><td><div class="actions">${canWrite()?`<button class="mini" data-edit="${esc(m.id)}">Editar</button>${m.status!=='approved_live'?`<button class="mini" data-approve="${esc(m.id)}">Aprovar</button>`:''}${m.status==='approved_live'?`<button class="mini" data-genkey="${esc(m.id)}">+ Chave</button>`:''}${m.status==='suspended'||m.status==='rejected'?`<button class="mini" data-reopen="${esc(m.id)}">Reabrir</button>`:`<button class="mini danger" data-suspend="${esc(m.id)}">Suspender</button>`}`:'Somente leitura'}</div></td></tr>`).join('')||empty(6);$('#payment-merchant').innerHTML='<option value="">Todas as empresas</option><option value="ARGUS">ARGUS Payments · Pix simples</option>'+state.merchants.map(m=>`<option value="${esc(m.id)}">${esc(m.legal_name)}</option>`).join('')}
$('#merchant-search').oninput=()=>renderMerchants();$('#merchant-status-filter').onchange=()=>renderMerchants();
function merchantForm(m=null){dialog(m?'Editar empresa':'Nova empresa',`<form id="merchant-modal-form" class="modal-form"><label>Razão social<input name="legal_name" required maxlength="180" value="${esc(m?.legal_name||'')}"></label>${m?'':`<label>CNPJ<input name="cnpj" required maxlength="20" placeholder="00.000.000/0000-00" inputmode="numeric"></label>`}<div class="modal-row"><label>E-mail da empresa<input name="email" type="email" required value="${esc(m?.email||'')}"></label><label>Recebedor na MisticPay<input name="misticpay_email" type="email" required value="${esc(m?.misticpay_email||'')}"></label></div><label>Comissão ARGUS (%)<input name="fee" type="number" required min="0" max="10" step="0.01" value="${m?(m.commission_bps/100).toFixed(2):'1.50'}"></label>${m?'<p class="subtle-warning">Alterar o e-mail recebedor suspende as chaves e exige nova aprovação.</p>':''}<div class="modal-actions"><button type="button" class="btn secondary" id="merchant-cancel">Cancelar</button><button class="btn primary" type="submit">Salvar</button></div></form>`,'CADASTRO E COMISSÕES');$('#merchant-cancel').onclick=closeDialog;$('#merchant-modal-form').onsubmit=async e=>{e.preventDefault();const f=formValues(e.target);const payload={legal_name:f.legal_name,email:f.email,misticpay_email:f.misticpay_email,commission_bps:Math.round(Number(f.fee)*100)};if(!m)payload.cnpj=f.cnpj;try{m?await post(`/api/admin/merchants/${encodeURIComponent(m.id)}/update`,payload):await post('/api/admin/merchants',payload);closeDialog();await loadMerchants();toast('Cadastro salvo com sucesso')}catch(err){toast(err.message,true)}}}
$('#new-merchant').onclick=()=>merchantForm();
async function generationKey(id){if(!confirm('Gerar uma chave de integração para esta empresa? Ela será exibida somente uma vez.'))return;try{const result=await post(`/api/admin/merchants/${encodeURIComponent(id)}/keys`);dialog('Chave de API gerada',`<p class="subtle-warning">Guarde esta chave em local seguro e entregue ao lojista por canal privado. Ela não poderá ser recuperada depois.</p><div id="shown-key" class="secret"></div><div class="modal-actions"><button id="copy-secret" class="btn primary">Copiar chave</button></div>`,'ACESSO INDIVIDUAL');$('#shown-key').textContent=result.api_key;$('#copy-secret').onclick=async()=>{try{await navigator.clipboard.writeText(result.api_key);toast('Chave copiada')}catch{toast('Selecione e copie a chave manualmente',true)}};await loadMerchants()}catch(err){toast(err.message,true)}}
function approveMerchant(id){const m=state.merchants.find(x=>x.id===id);if(!m)return;dialog('Aprovar empresa',`<p class="subtle-warning">Você declara ter verificado os documentos e a autorização da empresa <b>${esc(m.legal_name)}</b>. Esta ação permite emitir chaves reais de Pix.</p><form id="approve-form" class="modal-form">${[['kyb_verified','Documentos e responsáveis verificados (KYB)'],['provider_approved','Empresa habilitada pela MisticPay'],['contract_signed','Contrato com o lojista assinado'],['split_direction_confirmed','Split e recebedor conferidos']].map(([k,label])=>`<label class="checkline"><input type="checkbox" name="${k}" required><span>${label}</span></label>`).join('')}<div class="modal-actions"><button type="button" id="cancel-approve" class="btn secondary">Cancelar</button><button type="submit" class="btn primary">Confirmar aprovação</button></div></form>`,'ANÁLISE DE CADASTRO');$('#cancel-approve').onclick=closeDialog;$('#approve-form').onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.target).entries());try{await post(`/api/admin/merchants/${encodeURIComponent(id)}/approve`,Object.fromEntries(Object.keys(data).map(k=>[k,true])));closeDialog();await loadMerchants();toast('Empresa aprovada. Gere sua chave de API quando necessário.')}catch(err){toast(err.message,true)}}}
async function merchantAction(action,id){const reason=prompt(`${action==='suspend'?'Motivo do bloqueio':'Motivo da reabertura'} (mínimo 5 caracteres):`);if(reason===null)return;try{await post(`/api/admin/merchants/${encodeURIComponent(id)}/${action}`,{reason});await loadMerchants();toast(action==='suspend'?'Empresa suspensa e chaves revogadas':'Empresa reaberta para análise')}catch(err){toast(err.message,true)}}
$('#merchant-rows').onclick=e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.edit){const m=state.merchants.find(x=>x.id===b.dataset.edit);if(m)merchantForm(m)}else if(b.dataset.approve)approveMerchant(b.dataset.approve);else if(b.dataset.genkey)generationKey(b.dataset.genkey);else if(b.dataset.suspend)merchantAction('suspend',b.dataset.suspend);else if(b.dataset.reopen)merchantAction('reopen',b.dataset.reopen)};
async function loadPayers(){const [rows,blocks,merchants]=await Promise.all([api('/api/admin/payers'),api('/api/admin/blocks'),api('/api/admin/merchants')]);state.merchants=merchants;$('#payer-rows').innerHTML=rows.map(x=>`<tr><td><b>${esc(x.payer_name)}</b></td><td>${esc(x.legal_name)}</td><td>•••• ${esc(x.payer_document_last4)}</td><td>${x.charge_count}</td><td>${fmt(x.paid_cents)}</td></tr>`).join('')||empty(5);$('#blocked-rows').innerHTML=blocks.map(x=>`<tr><td>${esc(x.legal_name)}</td><td>•••• ${esc(x.document_last4)}</td><td>${esc(x.reason)}</td><td>${x.released_at?badge('active'):badge('suspended')}</td><td>${!x.released_at&&canWrite()?`<button class="mini" data-release="${esc(x.id)}">Desbloquear</button>`:'—'}</td></tr>`).join('')||empty(5)}
$('#new-payer-block').onclick=()=>{dialog('Bloquear pagador',`<form class="modal-form" id="block-form"><label>Empresa<select name="merchant_id" required>${state.merchants.map(x=>`<option value="${esc(x.id)}">${esc(x.legal_name)}</option>`).join('')}</select></label><label>CPF do pagador<input name="payer_document" required maxlength="20" inputmode="numeric" placeholder="000.000.000-00"></label><label>Motivo<input name="reason" required minlength="5" maxlength="300"></label><p class="subtle-warning">O CPF é convertido em identificador criptográfico; somente os últimos quatro dígitos ficam armazenados.</p><div class="modal-actions"><button type="submit" class="btn danger">Bloquear novas cobranças Pix</button></div></form>`,'CONTROLE DE RISCO');$('#block-form').onsubmit=async e=>{e.preventDefault();try{await post('/api/admin/blocks',formValues(e.target));closeDialog();await loadPayers();toast('Pagador bloqueado para novos Pix')}catch(err){toast(err.message,true)}}};
$('#blocked-rows').onclick=async e=>{const b=e.target.closest('button[data-release]');if(!b||!confirm('Liberar esse CPF para novas cobranças Pix?'))return;try{await post(`/api/admin/blocks/${encodeURIComponent(b.dataset.release)}/release`);await loadPayers();toast('Pagador liberado')}catch(err){toast(err.message,true)}};
async function loadPayments(){
 // Preserve the complete live ledger and load merchant choices from real approved/pending registrations.
 const [payments,merchants]=await Promise.all([
  api('/api/admin/charges?status=all&merchant='),
  api('/api/admin/merchants').catch(()=>state.merchants)
 ]);
 state.payments=payments;
 if(Array.isArray(merchants)){
  state.merchants=merchants;
  const select=$('#payment-merchant'),selected=select.value;
  select.innerHTML='<option value="">Todas as empresas</option><option value="ARGUS">ARGUS Payments · Pix simples</option>'+
   merchants.map(m=>`<option value="${esc(m.id)}">${esc(m.legal_name)}</option>`).join('');
  select.value=[...select.options].some(o=>o.value===selected)?selected:'';
 }
 renderPaymentsDemo();
}
function renderPaymentsDemo(){
 const query=$('#payment-search').value.trim().toLocaleLowerCase('pt-BR');
 const status=$('#payment-status').value;
 const method=$('#payment-method').value;
 const merchant=$('#payment-merchant').value;
 const rows=state.payments.filter(p=>
  (status==='all'||p.status===status)&&
  (method==='all'||method==='pix')&&
  (!merchant||p.merchant_id===merchant)&&
  (!query||[p.id,p.payer_name,p.legal_name,p.description,p.provider_tx_id].some(x=>String(x??'').toLocaleLowerCase('pt-BR').includes(query)))
 );
 $('#payment-count').textContent=String(rows.length);
 $('#payment-rows').innerHTML=rows.map(p=>{
  const name=String(p.payer_name||'').trim();
  const unnamed=!name||name==='—';
  const display=unnamed?'Pagador não identificado':name;
  const secondary=String(p.legal_name||'ARGUS Payments');
  const initials=unnamed?'PX':display.split(/\s+/).slice(0,2).map(s=>s.slice(0,1).toLocaleUpperCase('pt-BR')).join('');
  const stateLabel={paid:'Aprovado',pending:'Pendente',creating:'Em criação',unknown:'Não confirmado',failed:'Recusado',expired:'Expirado'}[p.status]||p.status;
  const chip=['paid','pending','failed'].includes(p.status)?p.status:p.status==='expired'?'failed':'pending';
  const action=`<button class="mini" data-viewpix="${esc(p.id)}">Ver Pix</button>${canWrite()&&p.provider_tx_id?` <button class="mini" data-reconcile="${esc(p.id)}">Conciliar</button>`:''}`;
  return `<tr><td data-label="CLIENTE"><div class="demo-customer-cell"><span class="demo-person-avatar">${esc(initials)}</span><span class="demo-customer-names"><strong>${esc(display)}</strong><small>${esc(secondary)} · ${esc(p.id)}</small></span></div></td><td data-label="VALOR"><strong>${fmt(p.amount_cents)}</strong></td><td data-label="MÉTODO"><span class="demo-method-pill">Pix</span></td><td data-label="STATUS"><span class="demo-status-pill demo-status-${chip}">${esc(stateLabel)}</span></td><td data-label="DATA">${time(p.created_at)}</td><td data-label="AÇÕES"><div class="demo-row-actions">${action}</div></td></tr>`;
 }).join('')||'<tr class="demo-empty-row"><td colspan="6"><div class="demo-blank-state"><span class="blank-icon">◈</span><h3>Nenhuma transação encontrada</h3><p>Altere os filtros ou gere sua primeira cobrança Pix.</p></div></td></tr>';
}
$('#payment-search').oninput=renderPaymentsDemo;
$('#payment-status').onchange=renderPaymentsDemo;
$('#payment-method').onchange=renderPaymentsDemo;
$('#payment-merchant').onchange=renderPaymentsDemo;
$('#refresh-payments').onclick=()=>loadPayments().catch(e=>toast(e.message,true));
$('#payment-export').onclick=()=>{
 const end=new Date(),start=new Date(end.valueOf()-30*86400000),date=x=>x.toISOString().slice(0,10);
 location.href=`/api/admin/reports.csv?from=${date(start)}&to=${date(end)}`;
};
$('#payment-rows').onclick=async e=>{const b=e.target.closest('button');if(!b)return;try{if(b.dataset.viewpix){
 const v=await api('/api/admin/charges/'+encodeURIComponent(b.dataset.viewpix));
 dialog('Cobrança Pix',`<p class="muted">Cobrança ${esc(v.id)} · ${badge(v.status)}</p><h3>${fmt(v.amount_cents)}</h3><p>Pix Copia e Cola</p><textarea readonly rows="5" id="modal-pix-copy">${esc(v.pix_copy_paste||'Sem código disponível')}</textarea><p class="muted">Valor somente confirmado após conciliação autenticada.</p>`,'CONTROLE DE COBRANÇAS');
 }else if(b.dataset.reconcile){const data=await post(`/api/admin/charges/${encodeURIComponent(b.dataset.reconcile)}/reconcile`);toast('Status consultado na MisticPay: '+data.charge.status);await loadPayments()}}
 catch(err){toast(err.message,true)}
};
async function loadKeys(){const rows=await api('/api/admin/keys');$('#key-rows').innerHTML=rows.map(x=>`<tr><td>${esc(x.legal_name)}</td><td class="narrow-break">${esc(x.id)}</td><td>${time(x.created_at)}</td><td>${x.revoked_at?badge('suspended'):badge('active')}</td><td>${!x.revoked_at&&canWrite()?`<button class="mini danger" data-revoke="${esc(x.id)}">Revogar</button>`:'—'}</td></tr>`).join('')||empty(5)}
$('#key-rows').onclick=async e=>{const b=e.target.closest('button[data-revoke]');if(!b)return;if(!confirm('Revogar permanentemente esta chave? O lojista precisará receber uma nova.'))return;try{await post(`/api/admin/keys/${encodeURIComponent(b.dataset.revoke)}/revoke`);await loadKeys();toast('Chave revogada')}catch(err){toast(err.message,true)}};
const today=new Date();$('#report-to').value=today.toISOString().slice(0,10);$('#report-from').value=today.toISOString().slice(0,7)+'-01';
async function loadReports(){const a=$('#report-from').value,b=$('#report-to').value;const q=`from=${encodeURIComponent(a)}&to=${encodeURIComponent(b)}`;const v=await api(`/api/admin/reports?${q}`);$('#report-rows').innerHTML=v.daily.map(x=>`<tr><td><b>${esc(x.day)}</b></td><td>${x.quantity}</td><td>${fmt(x.gross_cents)}</td><td>${fmt(x.paid_cents)}</td><td>${fmt(x.commission_estimate_cents)}</td></tr>`).join('')||empty(5);$('#report-csv').href='/api/admin/reports.csv?'+q}
$('#report-form').onsubmit=e=>{e.preventDefault();loadReports().catch(err=>toast(err.message,true))};
async function loadAudit(){const rows=await api('/api/admin/audit');$('#audit-rows').innerHTML=rows.map(x=>`<tr><td>${time(x.created_at)}</td><td>${esc(x.actor_email)}</td><td><b>${esc(x.action)}</b></td><td>${esc(x.entity_type)} · <small>${esc(x.entity_id)}</small></td><td>${esc(x.detail)}</td></tr>`).join('')||empty(5)}
async function loadUsers(){const rows=await api('/api/admin/users');$('#user-rows').innerHTML=rows.map(x=>`<tr><td><b>${esc(x.display_name)}</b><small>${esc(x.email)}</small></td><td>${esc(x.role)}</td><td>${badge(x.status)}${x.must_change_password?' <small>Troca de senha pendente</small>':''} ${x.mfa_enabled?' <small>2FA ativo</small>':' <small>2FA pendente</small>'}</td><td>${time(x.last_login_at)}</td><td>${x.role!=='superadmin'?`<div class="actions"><button class="mini" data-reset="${esc(x.id)}">Redefinir</button><button class="mini ${x.status==='active'?'danger':''}" data-toggle="${esc(x.id)}" data-next="${x.status==='active'?'suspend':'activate'}">${x.status==='active'?'Bloquear':'Liberar'}</button></div>`:'Proprietário'}</td></tr>`).join('')||empty(5)}
$('#new-user').onclick=()=>{dialog('Novo usuário interno',`<form id="user-form" class="modal-form"><label>Nome<input name="display_name" required minlength="2" maxlength="180"></label><label>E-mail<input type="email" name="email" required></label><label>Perfil<select name="role"><option value="admin">Administrador — gerencia lojistas e chaves</option><option value="analyst">Analista — somente consulta</option></select></label><div class="modal-actions"><button type="submit" class="btn primary">Criar acesso</button></div></form>`,'PERMISSÕES DE ACESSO');$('#user-form').onsubmit=async e=>{e.preventDefault();try{const result=await post('/api/admin/users',formValues(e.target));closeDialog();await loadUsers();showTemporary(result.temporary_password)}catch(err){toast(err.message,true)}}};
function showTemporary(pwd){dialog('Senha temporária criada',`<p class="subtle-warning">Senha exibida somente agora. Entregue-a ao responsável por um canal privado; será obrigatória a troca no primeiro login.</p><div class="secret" id="tmp-pwd"></div><div class="modal-actions"><button type="button" class="btn primary" id="copy-pwd">Copiar senha</button></div>`,'ENTREGA DE ACESSO');$('#tmp-pwd').textContent=pwd;$('#copy-pwd').onclick=async()=>{try{await navigator.clipboard.writeText(pwd);toast('Senha copiada')}catch{toast('Copie manualmente',true)}}}
$('#user-rows').onclick=async e=>{const b=e.target.closest('button');if(!b)return;try{if(b.dataset.reset){if(!confirm('Redefinir a senha deste usuário?'))return;const r=await post(`/api/admin/users/${encodeURIComponent(b.dataset.reset)}/reset-password`);showTemporary(r.temporary_password)}else if(b.dataset.toggle){if(!confirm('Confirmar alteração de acesso?'))return;await post(`/api/admin/users/${encodeURIComponent(b.dataset.toggle)}/${b.dataset.next}`);await loadUsers();toast('Permissão atualizada')}}catch(err){toast(err.message,true)}};
async function bootstrap(){
 const retry=$('#boot-retry'),message=$('#boot-message');retry.hidden=true;message.textContent='Verificando sua sessão com segurança...';
 try{const data=await api('/api/admin/session');signin(data)}
 catch(err){
  if(err.status===401||err.status===403){view('login')}
  else{message.textContent='Não foi possível confirmar sua sessão. Confira a conexão e tente novamente.';retry.hidden=false}
 }
}
$('#boot-retry').addEventListener('click',bootstrap);
bootstrap();

