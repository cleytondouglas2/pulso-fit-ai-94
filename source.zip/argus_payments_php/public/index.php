<?php
declare(strict_types=1);
ini_set('display_errors', '0'); // Não exibe dados internos em respostas públicas
require_once dirname(__DIR__) . '/src/Gateway.php';
\ArgusPayments\Gateway::dispatch();
