# ARGUS Payments + MisticPay — integração real Pix, com ativação segura

**Status:** conector e endpoints implementados; pagamentos reais **não ativados** até configurar segredos, banco persistente, KYB e contas aprovadas. Esta documentação descreve a API oficial `https://api.misticpay.com/api` (valores em reais), NÃO `api.finance.misticpay.com` (valores em centavos).

## Variáveis do servidor (Render > ARGUS Payments B2B MisticPay > Environment)

Defina estes valores **diretamente no Render, nunca em código, GitHub ou no chat**:

- `ARGUS_DB_DRIVER=pgsql` ou `ARGUS_DB_DRIVER=mysql` (SQLite da demo está impedido para dinheiro real).
- PostgreSQL: `ARGUS_PGSQL_HOST`, `ARGUS_PGSQL_PORT`, `ARGUS_PGSQL_DATABASE`, `ARGUS_PGSQL_USER`, `ARGUS_PGSQL_PASSWORD` (banco gerenciado com backups, SSL e retenção adequada). MySQL usa as variáveis `ARGUS_MYSQL_*` do projeto.
- `ARGUS_MISTICPAY_PK` e `ARGUS_MISTICPAY_SK`: credenciais **pk_/sk_**, com apenas os escopos `TRANSACTION_CREATE` e `TRANSACTION_READ`. NÃO habilitar saque.
- `ARGUS_LIVE_OPERATOR_TOKEN`: segredo aleatório exclusivo de, no mínimo, 32 caracteres, usado pelo administrador de produção, distinto da senha da demo.
- `ARGUS_MISTICPAY_WEBHOOK_TOKEN`: segredo aleatório exclusivo de, no mínimo, 32 caracteres para a URL do callback. O token deve ser protegido em logs e rotacionado se houver exposição.
- `ARGUS_PUBLIC_BASE_URL=https://argus-payments-b2b-misticpay.onrender.com` (ou domínio HTTPS próprio).
- `ARGUS_MISTICPAY_SPLIT_MODE=platform_to_merchant` e `ARGUS_MISTICPAY_SPLIT_CONFIRMED=yes` **somente após confirmar por escrito** com a MisticPay que a conta ARGUS inicia o Pix, o `splitUser` representa o lojista e `splitTax` representa a parcela do lojista. Essa é a premissa implementada.
- `ARGUS_MISTICPAY_MODE=live` somente após todos os testes, KYB, aprovação, compliance e verificação de infraestrutura. O padrão é **desligado**.

**Cuidado:** Render free tem disco efêmero, sem garantias de persistência. Não use SQLite nem banco gratuito temporário para operações financeiras. A implantação atual usa o servidor PHP de desenvolvimento e precisa de PHP-FPM/Nginx e segurança de produção antes de operar.

## API de produção separada da demo

As rotas abaixo **não aceitam** o cookie de demonstração nem `arg_test_`. Exigem `Authorization: Bearer ...` e respostas JSON. Cada lojista só enxerga suas próprias cobranças.

1. Operador verifica checklist: `GET /api/live/operator/readiness` com `Bearer ARGUS_LIVE_OPERATOR_TOKEN`.
2. Após KYB, contrato e conta MisticPay aprovados, operador autoriza `POST /api/live/operator/merchants/{id}/activate`, com JSON `{"kyb_verified":true,"provider_approved":true,"contract_signed":true,"split_direction_confirmed":true}`. Guarde os comprovantes fora desta tabela.
3. Operador emite a chave individual **uma única vez** via `POST /api/live/operator/merchants/{id}/keys`. Retorna `api_key` (`arg_live_...`) e `key_id`. Armazene apenas o hash no banco. É possível revogar por `POST /api/live/operator/keys/{key_id}/revoke`.
4. O backend da empresa envia `POST /api/live/pix/charges`, com Bearer `arg_live_...`, header `Idempotency-Key` exclusivo (12–128 caracteres), JSON:

```json
{
  "amount_cents": 10000,
  "payer_name": "Nome do pagador",
  "payer_document": "CPF do pagador",
  "description": "Pedido da loja"
}
```

A ARGUS envia R$ 100,00 à MisticPay, com `splitUser` igual ao e-mail MisticPay do lojista aprovado e `splitTax` igual a `100% - comissão ARGUS`. O retorno JSON contém o ID e `pix_copy_paste`, status `pending`. **Não trate Pix criado como pago.**

5. `GET /api/live/pix/charges/{id}` retorna situação local. `POST /api/live/pix/charges/{id}/reconcile` consulta `POST /api/transactions/check` com as credenciais do servidor. Só marca `paid` se tipo, método, ID e valor baterem com a cobrança original.
6. A callback `POST /api/live/misticpay/webhook/{ARGUS_MISTICPAY_WEBHOOK_TOKEN}` recebe eventos MisticPay. **O corpo da notificação não é confiável como prova de recebimento**: ele provoca consulta autenticada ao PSP. Webhooks duplicados são idempotentes. Estorno integral vira `refunded`; parcial vira `refund_review`, exigindo verificação manual.
7. Se a criação cair em timeout ou responder sem ID/QR válido, o status permanece `unknown`; nunca repita a cobrança com outra chave sem conciliar. O ID interno é enviado como `transactionId` à MisticPay, permitindo localização junto ao suporte.

### Ações não disponíveis

Nenhuma rota de saque, payout, devolução ativa ou emissão de cartão/boleto foi habilitada. Split só ocorrerá se a MisticPay autorizar as regras e as credenciais corresponderem à conta correta. Percentuais exibidos são estimativas **antes de tarifas do parceiro**. Não existe prova de dinheiro liquidado na ARGUS pela simples confirmação de uma transação.

### Pendências operacionais

Aprovação cadastral e antifraude de cada empresa, análise jurídica do modelo e tarifas, contratos, política de LGPD, ambiente com MFA/RBAC, monitoramento, logs sem dados sensíveis, reconciliação e relatórios de liquidação PSP, testes supervisionados e auditoria. Banco e servidor de desenvolvimento atuais **não são adequados para dinheiro real**. Não colocar `ARGUS_MISTICPAY_MODE=live` até concluir isso.


### Banco temporário compartilhado (proibido para cobranças reais)

Se a ARGUS for usada **somente em testes** no banco existente do PulsoFit,
configure `ARGUS_PGSQL_SHARED=true` e o schema `argus_payments_b2b`.
A verificação de produção `dedicated_database` permanecerá `false`, mesmo
com todas as outras credenciais configuradas. Remova o bloqueio só quando
existir um banco exclusivo com backup, permissões próprias e homologação.


## Exceção temporária de operação real solicitada pelo proprietário (18/11/2026)

A instância PostgreSQL é compartilhada e gratuita, sem backups. Para um **piloto financeiro restrito** (não rollout para todos os clientes), a aplicação aceita `ARGUS_TEMPORARY_PG_LIVE_ACK=I_ACCEPT_TEMPORARY_RISK` juntamente com `ARGUS_MISTICPAY_MODE=live`. A exceção fica **irreversivelmente desativada em 10/12/2026 às 00:00 UTC**, antes da expiração do banco em 18/12/2026. A exceção limita cobranças reais a **R$ 100,00 por operação** e **não pula aprovação KYB, contrato nem chaves individuais de lojista**. Os dados podem ser perdidos mesmo antes da migração; exporte e restaure backups externos verificáveis e migre para banco dedicado. A modalidade não oferece processamento irrestrito e não deve ser divulgada como infraestrutura financeira de produção robusta.
