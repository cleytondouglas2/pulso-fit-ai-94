# ARGUS Payments + MisticPay — plano de execução B2B

**Estado em 18/11/2026:** implementação de software **somente em demonstração**. Nenhum dinheiro real é cobrado, transferido ou estornado. A funcionalidade do painel `/operacao` fica atrás do acesso de demonstração existente. **Não há autenticação ou segregação real de contas de lojistas.**

## Modelo escolhido

ARGUS Payments: plataforma B2B, painel/checkout/API e remuneração por serviços próprios ou split contratado. MisticPay: parceira proposta para captura Pix e liquidação conforme seus contratos; cada lojista deve ser devidamente habilitado pelo parceiro. Sem assumir custódia de valores da clientela pela ARGUS.

## Fontes oficiais consultadas

- https://app.misticpay.com/docs — API `https://api.misticpay.com/api`, `POST /transactions/create`, HTTP Basic com par `pk_/sk_`, campos `splitUser`, `splitTax`, Pix, `POST /transactions/check`, webhooks de depósito e estorno.
- https://app.misticpay.com/split-pagamento — divulgação do split para marketplaces (informações comerciais a contratar).
- https://docs.finance.misticpay.com — **OUTRA família de APIs**, com valores em centavos e `https://api.finance.misticpay.com`. Esta versão **não é usada** no conector, para evitar erro de valores e autenticação.

**Riscos de integração:** a documentação `app.misticpay.com/docs` informa que não existe sandbox separado para operações reais. A direção do split (quem cria a cobrança e quem recebe `splitUser`/`splitTax`), titularidade da conta e tarifas precisam ser confirmadas por escrito com a MisticPay. O exemplo de payload é desativado; uso eventual de endpoint é proibido até conclusão do contrato e homologação. Os campos da API analisada recebem **reais**, enquanto a ARGUS armazena **centavos** internamente.

## Código instalado

- `src/Integrations/MisticPayPix.php`: normalização de Pix/split, prévia de payload e mapeamento de status; sem envio HTTP e sem acesso a credenciais.
- `src/B2B.php`: endpoints administrativos de demonstração, análise de cadastros, taxa por lojista, cobrança com idempotência, pagamentos e estornos de teste, razão contábil e bloqueio de webhook não autenticado.
- `src/Database.php`: tabelas adicionais `b2b_merchants`, `b2b_charges`, `b2b_idempotency`, `b2b_ledger` e `b2b_events` (SQLite ou MySQL).
- `public/static/operacao.html/css/js`: interface B2B responsiva.
- `tests/b2b_unit.php`: testes de cálculos, API pretendida e lançamentos contábeis.

### Rotas demonstrativas

- `GET /operacao` — painel B2B
- `GET /api/b2b/summary` — indicadores
- `GET/POST /api/b2b/merchants` — empresas
- `POST /api/b2b/merchants/{id}/status` — aprovação **fictícia**
- `POST /api/b2b/preview` — cálculo de split, não financeiro
- `GET/POST /api/b2b/charges` — transações fictícias, `POST` exige `Idempotency-Key`
- `POST /api/b2b/charges/{id}/settle-test` — simulação de aprovação
- `POST /api/b2b/charges/{id}/refund-test` — simulação de estorno
- `GET /api/b2b/ledger` — razão da demonstração
- `GET /api/b2b/events` — auditoria
- `GET /api/b2b/integration` — status real dos recursos
- `POST /api/b2b/webhook/misticpay` — retorna erro 503 (recusa valores até reconciliação confiável)

Todas exigem sessão de **administrador demonstrativo** (exceto a página HTML, protegida por HTTP Basic no Render). Nenhum endpoint habilita cobrança real. CPFs completos não são retidos nas cobranças de teste. Em produção é necessário login por pessoa, permissões RBAC, MFA e revisão de privacidade e minimização.

## Checklist de produção — bloqueadores reais

1. **Parceria**: contratar MisticPay com autorização expressa para uso por múltiplas empresas e para cobrar comissão de serviços da ARGUS. Confirmar rateio, prazos, tarifas, retenções, estornos, reservas, repasses, responsabilização e encerramento.
2. **Regulatório**: advogado especializado avaliar se o modelo da ARGUS é tecnologia, marketplace, subcredenciadora ou atividade sujeita a autorização; validar tratamento de dados (LGPD), regras de arranjos e responsabilidades por prevenção à fraude e AML/KYB.
3. **Contas e cadastro**: aprovação KYB/KYC e beneficiário final de cada empresa, aceite e versão de contratos; aprovação MisticPay de cada recebedor.
4. **Infraestrutura**: banco gerenciado persistente (Postgres ou MySQL), migrações versionadas, backups criptografados/restauráveis, servidor web PHP-FPM com proxy reverso, monitoramento, logs sanitizados, alertas, filas, auditoria, recuperação, testes de carga e disaster recovery.
5. **Segurança**: autenticação individual e MFA, isolamento estrito multi-tenant, RBAC, proteção de ações sensíveis, rate limiting, gestão de chaves em cofre de segredos, segregação de escopos `TRANSACTION_CREATE`/`TRANSACTION_READ`, privilégio mínimo, revisão de dependências e pentest.
6. **Pix**: enviar cobranças via MisticPay com chave específica, validar respostas e associar identificador externo. A confirmação deve ser feita consultando `POST /api/transactions/check` sob credencial legítima antes de registrar liquidação; não confiar apenas na entrada do webhook. Tratar duplicações, eventos fora de ordem, estorno parcial e MED.
7. **Contabilidade**: conciliar transações com relatórios do parceiro, modelar custos próprios/tributos e taxas do PSP, usar razão de partidas dobradas com correções, documentar repasses e retenções. Comissões da demo não são saldos reais.
8. **Cartão/boleto**: negociar e confirmar APIs de produto com MisticPay separadamente antes de ativar qualquer opção real. Para cartão, usar apenas componentes/tokenização autorizados e requisitos PCI DSS aplicáveis.
9. **Homologação**: a documentação MisticPay usada não dispõe de sandbox; **não** mandar transação real sem aprovação do parceiro, autorização expressa do titular e processo supervisionado.

**As credenciais não devem ser enviadas neste chat**. Quando o contrato e a homologação estiverem aprovados, configure-as diretamente no painel de segredos da Render. A atual `ARGUS_DEMO_PASSWORD` serve apenas para limitar a demonstração, não para autenticar comerciantes finais.
