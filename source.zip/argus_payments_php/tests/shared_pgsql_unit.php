<?php
// Smoke test das regras de namespace compartilhado, sem precisar de credenciais.
declare(strict_types=1);
require __DIR__.'/../src/Database.php';
use ArgusPayments\Database;
if (Database::validatedPgSchema('argus_payments_b2b') !== 'argus_payments_b2b') throw new RuntimeException('Schema padrao');
foreach (['public','pg_catalog','information_schema','puls o','other;DROP TABLE x','Argus',''] as $unsafe) {
    try { Database::validatedPgSchema($unsafe); throw new RuntimeException('Aceitou schema perigoso: '.$unsafe); }
    catch (RuntimeException $e) {if (str_starts_with($e->getMessage(),'Aceitou'))throw $e;}
}
if (!class_exists('PDO')) throw new RuntimeException('PDO ausente');
echo "PASS: namespace PostgreSQL isolado, bloqueio de schemas inseguros.\n";
