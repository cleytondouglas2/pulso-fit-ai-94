<?php
declare(strict_types=1);
/** End-to-end HTTP smoke test. Runs only during Docker build, uses a TEMP SQLite path. */
$root=dirname(__DIR__);
$port=11981;
$base="http://127.0.0.1:$port";
$tmp=sys_get_temp_dir().'/argus-b2b-smoke-'.bin2hex(random_bytes(5)).'.sqlite';
$pass='render_build_test_only';
$env=array_merge($_ENV,['ARGUS_DEMO_PASSWORD'=>$pass,'ARGUS_SQLITE_PATH'=>$tmp,'ARGUS_DB_DRIVER'=>'sqlite','ARGUS_COOKIE_SECURE'=>'false']);
$cmd=[PHP_BINARY,'-d','auto_prepend_file='.$root.'/demo_guard.php','-S','127.0.0.1:'.$port,'-t',$root.'/public',$root.'/public/router.php'];
$p=proc_open($cmd,[0=>['pipe','r'],1=>['file',sys_get_temp_dir().'/argus-b2b-http.log','a'],2=>['file',sys_get_temp_dir().'/argus-b2b-http.log','a']],$pipes,$root,$env);
if(!is_resource($p))throw new RuntimeException('Não iniciou HTTP');
$session='';
function assertSmoke(bool $ok,string $message): void { if(!$ok)throw new RuntimeException($message); }
function httpCall(string $method,string $path,?array $body=null,array $extra=[]): array{
    global $base,$pass,$session;
    $headers=['Authorization: Basic '.base64_encode('argus:'.$pass),'Accept: application/json'];
    if($body!==null)$headers[]='Content-Type: application/json';
    if($session!=='')$headers[]='Cookie: arg_session='.$session;
    foreach($extra as $k=>$v)$headers[]=$k.': '.$v;
    $context=stream_context_create(['http'=>['method'=>$method,'header'=>implode("\r\n",$headers),'content'=>$body===null?'':json_encode($body,JSON_THROW_ON_ERROR),'ignore_errors'=>true,'timeout'=>8]]);
    $raw=@file_get_contents($base.$path,false,$context);
    $http=$http_response_header ?? [];
    if($raw===false)throw new RuntimeException('Falha HTTP: '.$path);
    preg_match('/\s(\d{3})\s/',(string)($http[0]??''),$m);
    $status=(int)($m[1]??0);
    foreach($http as $h){if(preg_match('/^Set-Cookie:\s*arg_session=([^;]+)/i',$h,$c))$session=$c[1];}
    $data=json_decode($raw,true);
    return [$status, $data??$raw];
}
try{
    $ok=false;for($i=0;$i<30;$i++){$socket=@fsockopen('127.0.0.1',$port,$err,$reason,0.3);if($socket){fclose($socket);$ok=true;break;}usleep(200000);}assertSmoke($ok,'Servidor não iniciou');
    [$s,$d]=httpCall('GET','/health');assertSmoke($s===200 && ($d['ok']??false)===true,'Health check: '.json_encode($d));
    [$s,$d]=httpCall('GET','/api/b2b/summary');assertSmoke($s===401,'Demo session obrigatória');
    [$s,$d]=httpCall('POST','/api/auth/demo',[]);assertSmoke($s===200 && $session!=='','Login demo');
    [$s,$d]=httpCall('POST','/api/b2b/merchants',['legal_name'=>'Empresa Testes LTDA','cnpj'=>'11.222.333/0001-81','email'=>'test@example.com','misticpay_email'=>'lojista@example.com','commission_bps'=>150]);
    assertSmoke($s===201 && isset($d['id']), 'Cadastro: '.json_encode($d));$id=$d['id'];
    [$s,$d]=httpCall('POST',"/api/b2b/merchants/$id/status",['status'=>'approved_demo']);assertSmoke($s===200 && $d['status']==='approved_demo','Aprovação demo');
    $data=['merchant_id'=>$id,'amount_cents'=>10000,'description'=>'Teste Pix B2B','payer_name'=>'Teste Pagador'];
    [$s,$d]=httpCall('POST','/api/b2b/preview',['merchant_id'=>$id,'amount_cents'=>10000]);assertSmoke($s===200 && $d['argus_commission_cents']===150,'Split preview');
    [$s,$d]=httpCall('POST','/api/b2b/charges',$data,['Idempotency-Key'=>'pedido-teste-000001']);assertSmoke($s===201 && isset($d['id']), 'Criar cobrança: '.json_encode($d));$charge=$d['id'];
    [$s,$d]=httpCall('POST','/api/b2b/charges',$data,['Idempotency-Key'=>'pedido-teste-000001']);assertSmoke($s===201 && $d['id']===$charge,'Idempotência');
    [$s,$d]=httpCall('POST','/api/b2b/charges',array_replace($data,['amount_cents'=>11000]),['Idempotency-Key'=>'pedido-teste-000001']);assertSmoke($s===409,'Conflito chave usada em corpo diferente');
    [$s,$d]=httpCall('POST',"/api/b2b/charges/$charge/settle-test",[]);assertSmoke($s===200 && $d['status']==='paid_demo','Liquidar teste');
    [$s,$d]=httpCall('GET','/api/b2b/ledger');assertSmoke($s===200 && count($d)===3,'Três lançamentos');assertSmoke(array_sum(array_column($d,'amount_cents'))===0,'Razão 0');
    [$s,$d]=httpCall('POST',"/api/b2b/charges/$charge/refund-test",[]);assertSmoke($s===200 && $d['status']==='refunded_demo','Reversão');
    [$s,$d]=httpCall('GET','/api/b2b/ledger');assertSmoke(count($d)===6 && array_sum(array_column($d,'amount_cents'))===0,'Razão com reversão 0');
    [$s,$d]=httpCall('POST','/api/b2b/webhook/misticpay',[]);assertSmoke($s===503,'Webhook financeiro não habilitado');
    [$s,$d]=httpCall('GET','/api/b2b/integration');assertSmoke($s===200 && $d['real_payments']===false,'Nenhum pagamento live habilitado');
    [$s,$d]=httpCall('GET','/api/live/operator/readiness');assertSmoke($s===401,'Token de operador real obrigatório');
    [$s,$d]=httpCall('POST','/api/live/pix/charges',['amount_cents'=>10000,'payer_name'=>'Teste','payer_document'=>'12345678909','description'=>'Teste Pix'],['Idempotency-Key'=>'real-should-not-run-123']);assertSmoke($s===503,'Chaves ausentes e banco SQLite bloqueiam dinheiro real');
    [$s,$d]=httpCall('POST','/api/live/misticpay/webhook/'.str_repeat('a',40),['transactionId'=>'fake','transactionType'=>'DEPOSITO','transactionMethod'=>'PIX']);assertSmoke($s===503,'Webhook real permanece desligado');
    echo "PASS: 17 testes HTTP: B2B demo, segregação de produção, auth operador e webhook bloqueado.\n";
}finally{
    proc_terminate($p);proc_close($p);
    foreach([$tmp,$tmp.'-wal',$tmp.'-shm'] as $f)@unlink($f);
}
