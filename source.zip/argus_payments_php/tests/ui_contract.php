<?php
declare(strict_types=1);
// Static UI regression checks; no provider requests and no financial writes.
$root=dirname(__DIR__).'/public/static/';
$html=file_get_contents($root.'admin.html');
$js=file_get_contents($root.'admin.js');
$css=file_get_contents($root.'polish.css');
$checks=[
 'Safe dialog wrapper without an enclosing form'=>str_contains($html,'<dialog id="modal"><div class="modal-window">')&&!str_contains($html,'<dialog id="modal"><form'),
 'Create-user form is standalone and bound to POST'=>str_contains($js,"$('#user-form').onsubmit=async")&&str_contains($js,"post('/api/admin/users',formValues(form))"),
 'Temporary password presented before independent reload'=>strpos($js,'closeDialog();showTemporary(result.temporary_password)')<strpos($js,"loadUsers().catch(err=>toast('Usuário criado."),
 'Dashboard greeting personalized and time-aware'=>str_contains($html,'id="daily-greeting"')&&str_contains($html,'id="daily-message"')&&str_contains($js,'function renderDailyGreeting(')&&str_contains($js,'now.getHours()'),
 'Money input uses cents mask'=>str_contains($js,'function pixMoneyMask(')&&str_contains($js,'function pixAmountCents(')&&str_contains($html,'inputmode="numeric" autocomplete="off" value="0,00"'),
 'Money input has no nested focus ring'=>str_contains($css,'.money-input input:focus-visible')&&str_contains($css,'border:0!important;outline:0!important;box-shadow:none!important;'),
 'Pix submit still enforces existing pilot and provider gate'=>str_contains($js,'amount<100||amount>10000')&&str_contains($js,"financePixAccess!=='verified'"),
];
foreach($checks as $label=>$ok){if(!$ok){fwrite(STDERR,'FAIL: '.$label.PHP_EOL);exit(1);}}
echo 'PASS: '.count($checks).' UI contracts for greeting, money mask, staff creation and Pix safeguards.'.PHP_EOL;
