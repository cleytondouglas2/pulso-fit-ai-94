#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! php -m | grep -qi 'pdo_sqlite'; then
  echo 'SKIP: pdo_sqlite não habilitado neste PHP. Habilite a extensão para o teste.'
  exit 77
fi
export ARGUS_DB_DRIVER=sqlite
export ARGUS_SQLITE_PATH="$(mktemp /tmp/arguspayments-php-test-XXXXXX.sqlite)"
PORT=18873
php -S 127.0.0.1:$PORT -t public public/router.php >/tmp/arguspayments-php-test.log 2>&1 &
PID=$!
COOKIE=$(mktemp)
trap 'kill "$PID" 2>/dev/null || true; rm -f "$ARGUS_SQLITE_PATH" "$ARGUS_SQLITE_PATH-wal" "$ARGUS_SQLITE_PATH-shm" "$COOKIE"' EXIT
sleep 1
BASE="http://127.0.0.1:$PORT"
request() { curl -fsS -b "$COOKIE" -c "$COOKIE" -H 'Content-Type: application/json' "$@"; }
request -X POST "$BASE/api/auth/demo" > /tmp/arguspayments-login.json
request "$BASE/api/overview" > /tmp/arguspayments-overview.json
request -X POST "$BASE/api/payments" -d '{"amount_cents":4500,"method":"pix","customer_name":"Pessoa Teste","customer_email":"teste@example.com","description":"Compra Sandbox"}' > /tmp/arguspayments-pay.json
PAY_ID=$(python3 -c 'import json;print(json.load(open("/tmp/arguspayments-pay.json"))["id"])')
request -X POST "$BASE/api/payments/$PAY_ID/settle" > /tmp/arguspayments-settle.json
request -X POST "$BASE/api/payments/$PAY_ID/refund" > /tmp/arguspayments-refund.json
request -X POST "$BASE/api/links" -d '{"title":"Produto de Teste","amount_cents":1990}' > /tmp/arguspayments-link.json
SLUG=$(python3 -c 'import json;print(json.load(open("/tmp/arguspayments-link.json"))["slug"])')
request "$BASE/api/public/links/$SLUG" > /tmp/arguspayments-public.json
request -X POST "$BASE/api/public/links/$SLUG/simulate" -d '{"customer_name":"Cliente Teste","customer_email":"client@example.com","method":"card"}' > /tmp/arguspayments-checkout.json
request -X POST "$BASE/api/keys" -d '{"label":"Teste de integracao"}' > /tmp/arguspayments-key.json
KEY=$(python3 -c 'import json;print(json.load(open("/tmp/arguspayments-key.json"))["key"])')
request -X POST "$BASE/api/v1/charges" -H "Authorization: Bearer $KEY" -H 'Idempotency-Key: compra-000001' -d '{"amount_cents":9900,"method":"pix","customer_name":"Cliente API","customer_email":"api@example.com","description":"Compra API"}' > /tmp/arguspayments-api1.json
request -X POST "$BASE/api/v1/charges" -H "Authorization: Bearer $KEY" -H 'Idempotency-Key: compra-000001' -d '{"amount_cents":9900,"method":"pix","customer_name":"Cliente API","customer_email":"api@example.com","description":"Compra API"}' > /tmp/arguspayments-api2.json
python3 - <<'PY'
import json
load=lambda name:json.load(open('/tmp/arguspayments-'+name+'.json'))
assert load('overview')['sandbox'] is True
assert load('pay')['status']=='pending'
assert load('settle')['status']=='paid'
assert load('refund')['status']=='refunded'
assert load('checkout')['sandbox'] is True
assert load('api1')['id']==load('api2')['id'], 'Idempotência falhou'
print('PASS: sessão, dashboard, criação, aprovação, estorno, checkout e API idempotente')
PY
