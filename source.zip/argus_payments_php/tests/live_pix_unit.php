<?php
declare(strict_types=1);
require dirname(__DIR__).'/src/Database.php';
require dirname(__DIR__).'/src/Gateway.php';
use ArgusPayments\Database;
use ArgusPayments\LivePix;
use ArgusPayments\Integrations\MisticPayHttpClient;

function ensure(bool $ok,string $description):void {if(!$ok)throw new RuntimeException('FALHA: '.$description);}
$mockCalls=[];
$provider = new MisticPayHttpClient('pk_mockabcdefghijk','sk_mockabcdefghijk',
    function(string $url,array $body,array $headers)use(&$mockCalls):array{
        $mockCalls[]=['url'=>$url,'body'=>$body,'headers'=>$headers];
        if(str_ends_with($url,'/transactions/create')) return ['data'=>['transactionId'=>'PROV123','copyPaste'=>str_repeat('000201',12),'transactionState'=>'PENDENTE']];
        return ['transaction'=>['transactionId'=>'PROV123','transactionType'=>'DEPOSITO','transactionMethod'=>'PIX','transactionState'=>'COMPLETO','value'=>100.00]];
    });
$merchant=['misticpay_email'=>'loja@example.com','commission_bps'=>150];
$body=MisticPayHttpClient::splitRequest($merchant,10000,'livepix_12345','Nome do pagador','123.456.789-09','Compra na loja','https://example.com/webhook/secure');
ensure($body['amount']===100.0,'Valor deve ser enviado em reais');
ensure($body['splitTax']===98.5,'Loja recebe 98,5%, ARGUS retém 1,5% antes das tarifas');
ensure($body['splitUser']==='loja@example.com','Destinatário é o lojista');
ensure($body['payerDocument']==='12345678909','CPF sem pontuação');
$result=$provider->createPix($body);
ensure($result['provider_id']==='PROV123','Criação com ID');
ensure(strlen($result['copy_paste'])===72,'QRCode copia e cola');
ensure(($provider->checkPix('PROV123')['transactionState']??'')==='COMPLETO','Status remoto');
ensure(count($mockCalls)===2,'Somente chamadas explícitas');
ensure(str_contains(implode('|',$mockCalls[0]['headers']),'Authorization: Basic '),'Credenciais via Basic');
foreach (['http://example.com/webhook/x','file:///tmp/x'] as $url) {
    try {MisticPayHttpClient::splitRequest($merchant,10000,'livepix_12345','Nome','12345678909','Compra',$url);throw new RuntimeException('Webhook inseguro aceito');}
    catch(InvalidArgumentException){}
}
if(!in_array('sqlite',PDO::getAvailableDrivers(),true)){
    echo "PASS: MisticPay client mock, split, Basic Auth e validações; banco indisponível neste ambiente.\n";
    exit;
}
$tmp=sys_get_temp_dir().'/argus-live-'.bin2hex(random_bytes(6)).'.sqlite';
try{
    $db=new Database(['driver'=>'sqlite','sqlite_path'=>$tmp]);$db->installAndSeed();
    $db->run('INSERT INTO b2b_merchants(id,legal_name,cnpj,email,misticpay_email,commission_bps,status,created_at) VALUES (?,?,?,?,?,?,?,?)',
        ['m_test','Loja Teste','11222333000181','loja@example.com','loja@example.com',150,'approved_live',Database::stamp()]);
    $db->run('INSERT INTO b2b_live_pix(id,merchant_id,key_hash,body_hash,amount_cents,commission_cents,description,payer_name,payer_document_last4,provider_tx_id,qr_copy,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
        ['livepix_12345','m_test',hash('sha256','abc'),hash('sha256','payload'),10000,150,'Compra','Nome','8909','PROV123',null,'pending',Database::stamp()]);
    $row=$db->one('SELECT * FROM b2b_live_pix WHERE id=?',['livepix_12345']);
    LivePix::reconcile($db,$row,$provider);
    ensure($db->one('SELECT status FROM b2b_live_pix WHERE id=?',['livepix_12345'])['status']==='paid','Reconcile via PSP autenticado');
    LivePix::reconcile($db,$row,$provider);
    ensure((int)$db->one('SELECT COUNT(*) c FROM b2b_live_events')['c']===1,'Webhook duplicado não duplica auditoria');
    $fake=new MisticPayHttpClient('pk_mockabcdefghijk','sk_mockabcdefghijk', fn()=>['transaction'=>['transactionId'=>'PROV123','transactionType'=>'DEPOSITO','transactionMethod'=>'PIX','transactionState'=>'COMPLETO','value'=>10.00]]);
    try{LivePix::reconcile($db,$row,$fake);throw new RuntimeException('Valor divergente aceito');}catch(\ArgusPayments\ApiError $e){ensure($e->status===409,'Reconciliacao divergente 409');}
    ensure($db->one('SELECT status FROM b2b_live_pix WHERE id=?',['livepix_12345'])['status']==='paid','Divergência preserva estado');
    ensure(LivePix::readiness($db)['ready']===false,'SQLite nunca ativa operações financeiras');
    echo "PASS: MisticPay real adapter, ledger separado, reconciliação autenticada e guardas de produção.\n";
}finally {foreach([$tmp,$tmp.'-shm',$tmp.'-wal']as $f)@unlink($f);}
