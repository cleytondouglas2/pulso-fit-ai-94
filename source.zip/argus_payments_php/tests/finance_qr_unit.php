<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/src/Integrations/MisticPayFinance.php';
use ArgusPayments\Integrations\MisticPayFinance;
$seen=[];
$mock=function($method,$url,$payload,$headers)use(&$seen){
    $seen=compact('method','url','payload','headers');
    if($method==='POST')return ['data'=>['id'=>'ch_1234abcd','qr_code'=>str_repeat('000201',10),'status'=>'PENDING','amount_cents'=>'350']];
    return ['id'=>'ch_1234abcd','status'=>'PAID','amount_cents'=>'350'];
};
$finance=new MisticPayFinance('client_id_12345678','client_secret_9876543210',$mock);
$idem='9b25d3ca-12c6-4e68-870b-f7af7fb0caa8';
$created=$finance->create(350,$idem,'Cobrança ARGUS qpx_abcdef');
if($created['provider_id']!=='ch_1234abcd'||$created['amount_cents']!==350)throw new RuntimeException('Create parsing incorrect');
if($seen['url']!=='https://api.finance.misticpay.com/v1/public/charges'||array_keys($seen['payload'])!==['amountCents','description'])throw new RuntimeException('Only amount and description allowed');
if(!in_array('x-idempotency-key: '.$idem,$seen['headers'],true))throw new RuntimeException('Idempotency header missing');
$checked=$finance->check('ch_1234abcd');
if($seen['method']!=='GET'||$checked['status']!=='PAID'||$checked['amount_cents']!==350)throw new RuntimeException('Status request invalid');
try{$finance->create(15000,$idem,'high amount');throw new RuntimeException('high amount accepted');}catch(InvalidArgumentException){}
echo "PASS: Finance QR Codes value-only payload, provider verification, limits and idempotency.\n";
