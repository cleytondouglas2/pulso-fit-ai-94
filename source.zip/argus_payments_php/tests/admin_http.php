<?php
declare(strict_types=1);
/** Financially inert end-to-end administrative tests; all DB writes use TEMP SQLite. */
require_once __DIR__.'/../src/Security2FA.php';
$root=dirname(__DIR__);$port=12317;$base='http://127.0.0.1:'.$port;
$dbFile=sys_get_temp_dir().'/argus-admin-'.bin2hex(random_bytes(6)).'.sqlite';
$email='testowner@argus.invalid';$first='StartAdmin123456789long';$new='SecondAdmin123456789long';
$env=array_merge($_ENV,[
 'ARGUS_DB_DRIVER'=>'sqlite','ARGUS_SQLITE_PATH'=>$dbFile,'ARGUS_COOKIE_SECURE'=>'false',
 'ARGUS_OPERATION_MODE'=>'production','ARGUS_MISTICPAY_MODE'=>'disabled',
 'ARGUS_SUPERADMIN_BOOTSTRAP_EMAIL'=>$email,'ARGUS_SUPERADMIN_BOOTSTRAP_HASH'=>password_hash($first,PASSWORD_DEFAULT),
 'ARGUS_PAYER_HMAC_KEY'=>str_repeat('keytest',10),
 'ARGUS_TOTP_ENCRYPTION_KEY'=>str_repeat('f',64),
 'ARGUS_PAYOUTS_ENABLED'=>'no',
]);
$cmd=[PHP_BINARY,'-d','auto_prepend_file='.$root.'/demo_guard.php','-S','127.0.0.1:'.$port,'-t',$root.'/public',$root.'/public/router.php'];
$p=proc_open($cmd,[0=>['pipe','r'],1=>['file',sys_get_temp_dir().'/argus-admin-http.log','a'],2=>['file',sys_get_temp_dir().'/argus-admin-http.log','a']],$pipes,$root,$env);
if(!is_resource($p))throw new RuntimeException('HTTP server failed');
$cookie=[];$assertions=0;
function checkAdmin(bool $ok,string $msg):void {global $assertions;$assertions++;if(!$ok)throw new RuntimeException('FAIL '.$msg);}
function requestAdmin(string $method,string $path,?array $body=null,bool $csrf=true):array {
 global $base,$cookie;
 $headers=['Accept: application/json','Origin: '.$base];if($body!==null)$headers[]='Content-Type: application/json';
 if($cookie)$headers[]='Cookie: '.implode('; ',array_map(fn($k)=>$k.'='.$cookie[$k],array_keys($cookie)));
 if($body!==null&&$csrf&&isset($cookie['arg_admin_csrf']))$headers[]='X-CSRF-Token: '.$cookie['arg_admin_csrf'];
 $context=stream_context_create(['http'=>['method'=>$method,'header'=>implode("\r\n",$headers),'content'=>$body===null?'':json_encode($body,JSON_THROW_ON_ERROR),'ignore_errors'=>true,'timeout'=>12]]);
 $raw=@file_get_contents($base.$path,false,$context);$hs=$http_response_header??[];
 if($raw===false)throw new RuntimeException('No response '.$path);
 preg_match('/\s(\d{3})\s/',(string)($hs[0]??''),$m);$status=(int)($m[1]??0);
 foreach($hs as $h)if(preg_match('/^Set-Cookie:\s*(arg_admin_session|arg_admin_csrf)=([^;]*)/i',$h,$x))$cookie[$x[1]]=$x[2];
 $decoded=json_decode($raw,true);return [$status,$decoded??$raw];
}
try {
 $running=false;for($i=0;$i<60;$i++){$s=@fsockopen('127.0.0.1',$port,$eno,$estr,0.2);if($s){fclose($s);$running=true;break;}usleep(150000);}checkAdmin($running,'HTTP server started');
 [$s,$a]=requestAdmin('GET','/admin');checkAdmin($s===200&&str_contains($a,'Centro de operações'),'Real admin page exists');
 [$s,$a]=requestAdmin('GET','/api/b2b/summary');checkAdmin($s===404,'Demo B2B API disabled');
 [$s,$a]=requestAdmin('POST','/api/auth/demo',[]);checkAdmin($s===404,'Demo login removed');
 [$s,$a]=requestAdmin('GET','/api/admin/overview');checkAdmin($s===401,'Overview requires login');
 [$s,$a]=requestAdmin('POST','/api/admin/login',['email'=>$email,'password'=>'wrong']);checkAdmin($s===401,'Wrong password rejected');
 [$s,$a]=requestAdmin('POST','/api/admin/login',['email'=>$email,'password'=>$first]);checkAdmin($s===200&&$a['user']['role']==='superadmin'&&$a['user']['must_change_password'],'Owner bootstrapped');
 [$s,$a]=requestAdmin('GET','/api/admin/overview');checkAdmin($s===403,'Forced password change enforced');
 [$s,$a]=requestAdmin('POST','/api/admin/change-password',['current_password'=>$first,'new_password'=>$new],false);checkAdmin($s===403,'CSRF required');
 [$s,$a]=requestAdmin('POST','/api/admin/change-password',['current_password'=>$first,'new_password'=>$new]);checkAdmin($s===200,'Owner password changed');
 [$s,$a]=requestAdmin('POST','/api/admin/login',['email'=>$email,'password'=>$new]);checkAdmin($s===200&&!$a['user']['must_change_password'],'New password logs in');
 [$s,$a]=requestAdmin('GET','/api/admin/overview');checkAdmin($s===403,'2FA mandatory after password login');
 [$s,$a]=requestAdmin('GET','/api/admin/mfa/setup');checkAdmin($s===200&&strlen($a['secret'])===32,'Authenticator must be registered');$otpSecret=$a['secret'];
 [$s,$a]=requestAdmin('POST','/api/admin/mfa/activate',['code'=>'123']);checkAdmin($s===400,'Invalid TOTP syntax rejected');
 [$s,$a]=requestAdmin('POST','/api/admin/mfa/activate',['code'=>\ArgusPayments\Security2FA::token($otpSecret,intdiv(time(),30))]);checkAdmin($s===200,'Authenticator enrollment verified');
 [$s,$a]=requestAdmin('GET','/api/admin/session');checkAdmin($s===200&&$a['user']['mfa_enabled']&&$a['user']['mfa_verified'],'Session now 2FA verified');
 [$s,$a]=requestAdmin('GET','/api/admin/wallet/balance');checkAdmin($s===503,'Payouts blocked without separate credentials');
 [$s,$a]=requestAdmin('GET','/api/admin/payouts');checkAdmin($s===200&&count($a)===0,'Real payout history available');
 [$s,$a]=requestAdmin('GET','/api/admin/overview');checkAdmin($s===200&&(int)$a['pix']['total']===0&&(int)$a['merchants']['total']===0,'Only real business data in dashboard');
 [$s,$a]=requestAdmin('POST','/api/admin/merchants',['legal_name'=>'Empresa Testes LTDA','cnpj'=>'11.222.333/0001-81','email'=>'testmerchant@example.com','misticpay_email'=>'recipient@example.com','commission_bps'=>150]);checkAdmin($s===201,'Onboard merchant');$mid=$a['id'];
 [$s,$a]=requestAdmin('POST','/api/admin/merchants/'.$mid.'/approve',['kyb_verified'=>true]);checkAdmin($s===422,'Cannot approve without checklist');
 [$s,$a]=requestAdmin('POST','/api/admin/merchants/'.$mid.'/approve',['kyb_verified'=>true,'provider_approved'=>true,'contract_signed'=>true,'split_direction_confirmed'=>true]);checkAdmin($s===200&&$a['status']==='approved_live','Approved merchant');
 [$s,$a]=requestAdmin('POST','/api/admin/merchants/'.$mid.'/keys',[]);checkAdmin($s===201&&str_starts_with($a['api_key'],'arg_live_'),'Live API key generated');
 [$s,$a]=requestAdmin('POST','/api/admin/blocks',['merchant_id'=>$mid,'payer_document'=>'123.456.789-09','reason'=>'Bloqueio do teste']);checkAdmin($s===201,'Payer can be blocked by HMAC');
 [$s,$a]=requestAdmin('GET','/api/admin/blocks');checkAdmin($s===200&&count($a)===1&&strlen($a[0]['document_last4'])===4&&!str_contains(json_encode($a),'12345678909'),'No full CPF stored');
 [$s,$a]=requestAdmin('POST','/api/admin/merchants/'.$mid.'/suspend',['reason'=>'Suspensão por solicitação']);checkAdmin($s===200&&$a['status']==='suspended','Merchant suspended');
 [$s,$a]=requestAdmin('GET','/api/admin/keys');checkAdmin($s===200&&count($a)===1&&!empty($a[0]['revoked_at']),'Suspension revokes API key');
 [$s,$a]=requestAdmin('GET','/api/admin/reports?from=2026-11-01&to=2026-11-30');checkAdmin($s===200&&is_array($a['daily']),'Real reports available');
 [$s,$a]=requestAdmin('POST','/api/admin/users',['display_name'=>'Auditor Externo','email'=>'analyst@example.com','role'=>'analyst']);checkAdmin($s===201&&strlen($a['temporary_password'])>=32,'Create read-only staff');
 [$s,$a]=requestAdmin('GET','/api/admin/audit');checkAdmin($s===200&&count($a)>=5,'Admin audit recorded');
 [$s,$a]=requestAdmin('POST','/api/admin/logout',[]);checkAdmin($s===200,'Owner logout');
 [$s,$a]=requestAdmin('POST','/api/admin/login',['email'=>$email,'password'=>$new]);checkAdmin($s===200&&!$a['user']['mfa_verified'],'Existing owner must do MFA on next login');
 [$s,$a]=requestAdmin('GET','/api/admin/overview');checkAdmin($s===403,'MFA cannot be bypassed after relogin');
 [$s,$a]=requestAdmin('POST','/api/admin/login',['email'=>'analyst@example.com','password'=>str_repeat('a',5)]);checkAdmin($s===401,'Analyst temp not guessable');
 echo 'PASS: '.$assertions.' admin HTTP assertions including owner bootstrap, mandatory password reset, session, CSRF, company review, live API keys, payer blocks, reports and audit.' . PHP_EOL;
} finally {proc_terminate($p);proc_close($p);foreach([$dbFile,$dbFile.'-wal',$dbFile.'-shm'] as $f)@unlink($f);}
