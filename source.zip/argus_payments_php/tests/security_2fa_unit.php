<?php
declare(strict_types=1);
require __DIR__.'/../src/Security2FA.php';
require __DIR__.'/../src/Integrations/MisticPayPayout.php';
use ArgusPayments\Security2FA;
use ArgusPayments\Integrations\MisticPayPayout;
function a(bool $value,string $what):void{if(!$value)throw new RuntimeException($what);}
putenv('ARGUS_TOTP_ENCRYPTION_KEY='.str_repeat('a',64));
$secret=Security2FA::newSecret();a(strlen($secret)===32,'Secret must be 160-bit Base32');
$sealed=Security2FA::seal($secret);a(Security2FA::unseal($sealed)===$secret,'Encrypted OTP persists');a(!str_contains($sealed,$secret),'Secret not in ciphertext');
$known=Security2FA::base32('12345678901234567890');a(Security2FA::token($known,1)==='287082','RFC 6238 vector');
$code=Security2FA::token($secret,10000);a(Security2FA::matchingStep($secret,$code,-1,10000*30)===10000,'Valid TOTP');a(Security2FA::matchingStep($secret,$code,10000,10000*30)===null,'Prevents OTP replay');
a(Security2FA::matchingStep($secret,'123',-1,10000*30)===null,'Requires 6 digits');
$called=0;$sender=function($method,$url,$payload,$headers)use(&$called){$called++;a(str_contains(implode('|',$headers),'X-Idempotency-Key: transfer_unique_001'),'Idempotency header');a($method==='POST'&&str_ends_with($url,'/transactions/withdraw'),'Only cashout route');a((float)$payload['amount']===10.0,'Use BRL decimals');return ['data'=>['transactionId'=>12345,'jobId'=>'job_test','status'=>'QUEUED']];};
$payout=new MisticPayPayout('pk_TESTKEY123456','sk_TESTKEY123456',$sender);
$out=$payout->withdraw(1000,'EMAIL','example@example.com','Teste de pagamento','transfer_unique_001');a($out['status']==='QUEUED'&&$called===1,'Withdraw adapter validated');
$refused=false;try{$payout->withdraw(11000,'EMAIL','example@example.com','Teste de pagamento','transfer_unique_002');}catch(InvalidArgumentException){$refused=true;}a($refused&&$called===1,'Hard cap enforced prior to network');
$refused=false;try{MisticPayPayout::validatePixKey('EMAIL','not-an-email');}catch(InvalidArgumentException){$refused=true;}a($refused,'Reject invalid target key');
$balanceClient=new MisticPayPayout('pk_TESTKEY123456','sk_TESTKEY123456',function($method,$url,$body,$h){a($method==='GET'&&str_ends_with($url,'/users/balance'),'Balance GET');return ['data'=>['balance'=>12.34]];});
a($balanceClient->balance()===1234,'Balance in cents');
echo "PASS: TOTP encryption/replay, cashout limits, balance and provider idempotency.\n";
