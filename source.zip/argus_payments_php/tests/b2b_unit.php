<?php
declare(strict_types=1);
require dirname(__DIR__).'/src/Database.php';
require dirname(__DIR__).'/src/Integrations/MisticPayPix.php';
require dirname(__DIR__).'/src/B2B.php';
use ArgusPayments\Database;
use ArgusPayments\Integrations\MisticPayPix;
use ArgusPayments\B2B;

function check(bool $ok,string $message): void { if(!$ok)throw new RuntimeException($message); }
$split=MisticPayPix::splitPreview(10000,150,'argus@example.com');
check($split['argus_commission_cents']===150,'Comissão 1,5% de R$100');
check($split['merchant_before_provider_fees_cents']===9850,'Saldo antes da tarifa do PSP');
$round=MisticPayPix::splitPreview(1999,125,'argus@example.com');
check($round['argus_commission_cents']===25,'Arredondamento monetário');
check(MisticPayPix::mapProviderStatus('COMPLETO')==='paid','Status pago');
check(MisticPayPix::mapProviderStatus('DEVOLVIDO_PARCIAL')==='partially_refunded','Status refund parcial');
putenv('ARGUS_MISTICPAY_COMMISSION_EMAIL=argus@example.com');
$preview=MisticPayPix::buildRequest(['method'=>'pix','amount_cents'=>10000,'id'=>'dry_1','payer_name'=>'Teste','payer_document'=>'12345678909','description'=>'Pedido de teste'],['commission_bps'=>150,'misticpay_email'=>'lojista@example.com']);
check($preview['enabled']===false && (float)$preview['body']['amount']===100.0 && $preview['body']['splitTax']===1.5,'Payload split PIX em BRL');
check($preview['body']['splitUser']==='argus@example.com','Comissão precisa ser direcionada ao recipient ARGUS');
try{MisticPayPix::buildRequest(['method'=>'card','amount_cents'=>10000],['commission_bps'=>150]);throw new RuntimeException('Cartão não foi bloqueado');}catch(InvalidArgumentException){}
// Database tests require PDO SQLite, available in the Render PHP Docker image.
if(!in_array('sqlite',PDO::getAvailableDrivers(),true)){
    echo "PASS: 7 testes do conector; testes de SQL não executados (PDO SQLite ausente).\n";
    exit(0);
}
$tmp=sys_get_temp_dir().'/argus-b2b-'.bin2hex(random_bytes(6)).'.sqlite';
try{
    $db=new Database(['driver'=>'sqlite','sqlite_path'=>$tmp]);
    $db->installAndSeed();
    $db->run('INSERT INTO b2b_merchants(id,legal_name,cnpj,email,misticpay_email,commission_bps,status,created_at,reviewed_at) VALUES (?,?,?,?,?,?,?,?,?)', ['merchant_test','Teste Eireli','11222333000181','teste@example.com','lojista@example.com',150,'approved_demo',Database::stamp(),null]);
    $db->run('INSERT INTO b2b_charges(id,merchant_id,amount_cents,commission_cents,merchant_net_cents,description,payer_name,payer_document_last4,provider,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)', ['charge_test','merchant_test',10000,150,9850,'Simulação','Tester','8909','misticpay_dryrun','pending',Database::stamp()]);
    $ref=new ReflectionClass(B2B::class);
    $dbProp=$ref->getProperty('db');$dbProp->setValue(null,$db);
    $ledger=$ref->getMethod('ledger');
    $db->transaction(function()use($ledger){$ledger->invoke(null,'charge_test','merchant_test',10000,9850,150);});
    $rows=$db->all('SELECT * FROM b2b_ledger WHERE charge_id=?',['charge_test']);
    check(count($rows)===3,'Três contas do razão');
    check(array_sum(array_map(fn($r)=>(int)$r['amount_cents'],$rows))===0,'Contas sempre equilibradas');
    $db->transaction(function()use($ledger){$ledger->invoke(null,'charge_test','merchant_test',10000,9850,150,'_reverse');});
    $rows=$db->all('SELECT * FROM b2b_ledger WHERE charge_id=?',['charge_test']);
    check(count($rows)===6,'Estorno demo gera três contrapartidas');
    check(array_sum(array_map(fn($r)=>(int)$r['amount_cents'],$rows))===0,'Razão zerado após reversão');
    try{$db->transaction(function()use($ledger){$ledger->invoke(null,'charge_test','merchant_test',10000,9850,150);});throw new RuntimeException('Duplicação de razão foi aceita');}catch(PDOException){}
    echo "PASS: conector, esquema SQLite, ledger balanceado, reversão e proteção de duplicidade.\n";
}finally{
    foreach([$tmp,$tmp.'-shm',$tmp.'-wal'] as $f)@unlink($f);
}
