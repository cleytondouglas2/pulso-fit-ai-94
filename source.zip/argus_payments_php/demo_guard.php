<?php
declare(strict_types=1);
// Basic-auth isolating the public demonstration. Never use it as merchant authentication.
$path = (string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
if ($path !== '/health') {
    $expected = getenv('ARGUS_DEMO_PASSWORD') ?: '';
    if ($expected === '') {
        http_response_code(503);
        header('Content-Type: text/plain; charset=utf-8');
        exit('Demonstração ainda não configurada.');
    }
    $name = (string) ($_SERVER['PHP_AUTH_USER'] ?? '');
    $password = (string) ($_SERVER['PHP_AUTH_PW'] ?? '');
    if (!hash_equals('argus', $name) || !hash_equals($expected, $password)) {
        header('WWW-Authenticate: Basic realm="ARGUS Payments Demo", charset="UTF-8"');
        header('Cache-Control: no-store');
        http_response_code(401);
        exit('Acesso restrito à demonstração.');
    }
}
