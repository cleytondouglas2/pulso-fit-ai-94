<?php
declare(strict_types=1);
// The legacy shared HTTP Basic demonstration password is no longer accepted.
// Admin routes authenticate individually through secure, database-backed sessions.
if (PHP_SAPI === 'cli') return;
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
header('Cache-Control: no-store, private');
header("Content-Security-Policy: default-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'");
