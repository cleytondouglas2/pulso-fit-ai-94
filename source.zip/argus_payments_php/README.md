# ARGUS Payments — Centro de operações B2B

Aplicação PHP 8.3 / Apache, integração MisticPay Pix, PostgreSQL em schema isolado. Esta versão oferece **painel administrativo autenticado**; o login e os pagamentos fictícios da demonstração anterior foram removidos da interface e da API pública.

## Acesso ao painel

- `/admin` é a central administrativa; `/` redireciona visualmente para o mesmo painel.
- Super Admin inicial: `Cleyton.douglas2@gmail.com` (case-insensitive).
- Uma senha inicial aleatória é criada **fora do repositório**, e só seu hash bcrypt fica em `ARGUS_SUPERADMIN_BOOTSTRAP_HASH` na Render.
- O primeiro acesso exige troca imediata da senha. Login usa cookie de sessão HttpOnly, Secure, SameSite=Strict, token CSRF e bloqueio de tentativas.
- Somente o Super Admin cria usuários internos. Perfis: `superadmin`, `admin`, `analyst` (somente consulta).

## Funcionalidades

- Visão geral real: status de conexão, empresas, cobranças Pix confirmadas, comissões estimadas (antes do custo do PSP).
- Empresas: cadastro de CNPJ válido, taxa por lojista, recebedor MisticPay, análise, aprovação mediante confirmação de evidências KYB, suspensão, reabertura e alteração de dados.
- Suspensão e alteração do recebedor revogam todas as chaves ativas; liberar novamente exige nova aprovação e nova chave.
- Pagadores: listagem baseada em cobranças reais e bloqueio por CPF usando HMAC com segredo privado; CPF completo nunca fica no banco.
- Cobranças: status real, controle de idempotência, reconciliação autenticada diretamente com a MisticPay. Nenhum botão administrativo altera manualmente um pagamento para `paid`.
- API keys: emissão por lojista aprovado, mostradas somente uma vez, revogação a qualquer momento.
- Relatórios diários e exportação CSV; auditoria de todas as operações administrativas; gestão de usuários.

## Variáveis da Render

```dotenv
ARGUS_OPERATION_MODE=production
ARGUS_DB_DRIVER=pgsql
ARGUS_PGSQL_SHARED=true
ARGUS_PGSQL_SCHEMA=argus_payments_b2b
ARGUS_PGSQL_URL=<preencher em segredo na Render>
ARGUS_SUPERADMIN_BOOTSTRAP_EMAIL=Cleyton.douglas2@gmail.com
ARGUS_SUPERADMIN_BOOTSTRAP_HASH=<bcrypt hash da senha temporária; nunca senha em texto>
ARGUS_PAYER_HMAC_KEY=<segredo aleatório>=32 caracteres
ARGUS_COOKIE_SECURE=true
ARGUS_MISTICPAY_MODE=live
```

Preservar chaves MisticPay PK/SK, token de webhook e configurações de split preexistentes. **Não compartilhe segredos ou URLs de banco em código, logs ou capturas de tela.**

## Modelo de integração

- `POST /api/live/pix/charges` cria Pix somente para lojista aprovado, com bearer `arg_live_...` e `Idempotency-Key`.
- `POST /api/live/pix/charges/{id}/reconcile` consulta a MisticPay e verifica status.
- A confirmação por webhook requer consulta autenticada ao provedor antes de marcar `paid`.
- No banco compartilhado gratuito em Oregon, o piloto existente limita Pix a R$ 100 e encerra automaticamente em 2026-12-10T00:00:00Z. **Não é infraestrutura financeira durável.**

## Testes sem dinheiro

O Dockerfile roda `php tests/shared_pgsql_unit.php`, `php tests/live_pix_unit.php` e `php tests/admin_http.php` em SQLite temporário dentro do build. Não gera Pix verdadeiros. Nenhum serviço ou branch principal do PulsoFit é modificado.

## Pendências relevantes antes de escalar

A criação do Super Admin e a implantação do painel **não substituem** backups verificados, MFA para operadores, KYB documental e homologação de repasses reais. Migrar para banco próprio com backup contínuo e revisão de segurança antes do fim do piloto.


## Autenticação 2FA e transferências Pix (nov/2026)

O painel administrativo aplica 2FA TOTP (RFC 6238) obrigatório **a todas as contas humanas com login**: superadministrador, administrador e analista. Após a senha temporária ser substituída, o usuário cadastra o TOTP no aplicativo autenticador. Login posterior exige novo código. Segredos TOTP são cifrados com `sodium_crypto_secretbox` usando `ARGUS_TOTP_ENCRYPTION_KEY` (64 dígitos hexadecimais) na Render; **nunca altere esse segredo sem migração dos TOTP cadastrados**. Código já utilizado não é aceito novamente. Credenciais para integração máquina-a-máquina de lojistas NÃO representam contas com login web; elas continuam segregadas por chave e não podem efetuar saques.

O menu **Saldo e transferências** consulta o saldo da conta da **ARGUS**, não o saldo de cada empresa que recebeu split. Saques exigem autorização `superadmin`, sessão com 2FA, **outro código TOTP ainda não utilizado**, confirmação do usuário, validação da chave Pix, idempotência enviada à MisticPay e auditoria. O pilot limita **R$ 100/saque, R$ 500/dia**. Operações ficam **bloqueadas por padrão**: para disponibilizar saques é necessário chave financeira **separada** com escopos `BALANCE_READ` e `WITHDRAW_CREATE` sob `ARGUS_MISTICPAY_PAYOUT_PK`, `ARGUS_MISTICPAY_PAYOUT_SK`, e `ARGUS_PAYOUTS_ENABLED=yes`, somente após validação operacional e de risco. As chaves de checkout não devem ter permissão de saque. As respostas de saque `QUEUED` não representam pagamento liquidado; reconciliação autenticada obrigatória. **Nenhum saque é efetuado automaticamente em deploy ou testes.**

Provedor/API: `https://api.misticpay.com/api` usa reais com casas decimais; **não confundir** com a API Mistic Finance, que trabalha em centavos. Documentação oficial: https://app.misticpay.com/docs.

## Painel de operações — visual ARGUS clássico (18/11/2026)

O painel `/admin` usa a identidade visual da primeira demonstração ARGUS Payments (preto/dourado), sem restaurar dados ou operações simuladas.

- Tela inicial: KPIs reais, volume diário confirmado, histórico recente de transações, estado da integração e ações rápidas.
- `Gerar Pix`: somente administradores com autenticação de senha + 2FA concluída. Requer uma empresa previamente aprovada e com recebedor MisticPay válido. O endpoint administrativo `POST /api/admin/charges` reutiliza a mesma reserva idempotente, validação de CPF/bloqueio, split, limite do piloto e integração financeira `LivePix::issueCharge` que o endpoint de lojistas. A operação **cria uma cobrança real apenas após confirmação explícita no painel**. Uma falha externa pode deixar a cobrança com estado desconhecido: não faça outra cobrança antes da conciliação.
- `GET /api/admin/charges/{id}` devolve o Pix Copia e Cola somente após autenticação, sessão 2FA e permissões de leitura no painel, sem expor o CPF completo.
- O botão `Verificar pagamento` consulta o PSP autenticado para atualizar o status, nunca marca um Pix como pago apenas com dados do navegador ou webhook.
- Compatível com computador e celular, menu móvel acessível.

Os limites do piloto temporário e os requisitos de segurança para recebimentos/saques permanecem ativos. Testes automatizados não geram cobranças nem saques reais.


### Painel responsivo e Pix somente com valor (novembro 2026)

O painel usa um splash de verificação de sessão antes de mostrar login ou dashboard, animação de navegação e entradas de fontes de pelo menos 16px no iOS para evitar zoom automático. O arquivo `public/static/assets/argus-payments-logo-transparent.webp` contém a marca **original** com apenas canal alpha do fundo preto removido; proporções, texto e cores foram preservados.

A nova área **Gerar Pix** pede somente o valor (R$ 1–100 no piloto). O formulário usa o endpoint `POST /api/admin/quick-pix`. A API anterior de split por empresa segue disponível em `POST /api/admin/charges`, pois **a API antiga da MisticPay exige nome e CPF verdadeiros do pagador** e esses dados não podem ser inventados. O Pix simples é emitido pela **API Finance QRCODES da conta ARGUS, sem split de lojistas**, e por isso precisa de uma credencial exclusiva de QR Codes, disponível no painel Finance MisticPay em Configurações > API QR Codes:

- `ARGUS_FINANCE_QR_CLIENT_ID`
- `ARGUS_FINANCE_QR_CLIENT_SECRET`

Adicione essas duas variáveis **na Render**; não salve no repositório nem na interface web. Enquanto ausentes, a área mostra um aviso e impede a emissão, sem criar cobranças fictícias. A persistência usa `admin_quick_pix`, idempotência UUID e estado conservador `unknown` para resultado incerto; nunca repita emissão automaticamente. A conciliação consulta a API autenticada; nenhum pagamento passa a `paid` só pelo clique do cliente. As cobranças simples também aparecem em transações, KPIs e relatórios sem comissão fictícia.

Referência oficial: https://docs.finance.misticpay.com/quickstart e https://docs.finance.misticpay.com/authentication.
