> **NOVO — MisticPay B2B:** acesse `/operacao` para gerir empresas, comissões, cobranças e lançamentos fictícios; o conector Pix MisticPay fica em `src/Integrations/MisticPayPix.php`, **sem transmissão HTTP**. Leia [PRODUCAO-MISTICPAY.md](PRODUCAO-MISTICPAY.md) para regras e limites. Em produção, não use a sessão demo, não use SQLite efêmero e não envie dinheiro com base neste protótipo.

# ARGUS Payments PHP — Gateway de pagamentos (Sandbox)

Projeto **convertido para PHP 8.1+**, preservando a interface de painel e checkout da ARGUS Payments e os endpoints de API da versão inicial. **Esta versão é um ambiente de testes**: não cobra cartão, não cria QR Pix bancário, não emite boleto registrado, não realiza repasses e não movimenta dinheiro.

## O que funciona no PHP

- Painel financeiro responsivo com gráficos, KPIs e insights demonstrativos.
- Transações Pix, cartão e boleto **simuladas**, com filtros, aprovação/estorno de teste e exportação CSV.
- Links de checkout públicos, com nome/e-mail do comprador e escolha de método **em simulação**.
- Cadastro e consulta de clientes, assinaturas e regras de split ilustrativas.
- Chaves de API `arg_test_...` armazenadas somente como hash SHA-256.
- API JSON REST com `Idempotency-Key`, segregação por estabelecimento, log de auditoria.
- Sessão com cookie HttpOnly/SameSite=Strict, checagem Origin/Fetch Metadata e SQL parametrizado.
- Bancos **SQLite** (padrão) e **MySQL** (opção recomendada em hospedagem compartilhada).
- Conector Pix MisticPay *desativado* de prévia e cálculo de split, em `src/Integrations/MisticPayPix.php`.
- Documentação em `/docs`.

## Organização

```text
argus_payments_php/
├── public/                 <-- esta é a pasta pública (DocumentRoot)
│   ├── .htaccess           <-- rotas Apache
│   ├── index.php           <-- ponto de entrada PHP
│   ├── router.php          <-- servidor PHP local
│   └── static/             <-- CSS, JavaScript, telas e documentação
├── src/
│   ├── Database.php        <-- PDO + migrações automáticas + dados de demonstração
│   ├── Gateway.php         <-- API REST / autenticação / regras
│   └── Integrations/MisticPayPix.php  <-- conector desativado
├── storage/                <-- arquivos SQLite, privados
├── config.php
├── config.local.php.example
└── README.md
```

## Instalação local

**Exige:** PHP 8.1+ com extensão `pdo_sqlite` habilitada (ou `pdo_mysql` para MySQL).

```bash
cd argus_payments_php
php -m | grep -Ei 'pdo_sqlite|pdo_mysql'
php -S 127.0.0.1:8000 -t public public/router.php
```

Acesse: **http://127.0.0.1:8000**. Clique em **Explorar painel de demonstração**. A primeira requisição à API cria automaticamente as tabelas e registros fictícios.

> Caso apareça "Banco de dados indisponível", habilite `pdo_sqlite` nas extensões PHP ou configure o MySQL. A presença de `PDO` sem `pdo_sqlite`/`pdo_mysql` **não é suficiente**.

## Instalar na Hostinger / hospedagem PHP + MySQL

1. Crie um banco MySQL e seu usuário no painel de hospedagem, com acesso ao banco criado.
2. Envie a estrutura para um diretório do seu domínio. Configure a **raiz pública (DocumentRoot) como a pasta `public/`** — não exponha `src/`, `storage/` ou `config.local.php` na web.
3. Copie `config.local.php.example` para `config.local.php` **fora da pasta pública** e preencha host, nome do banco, usuário e senha. Deixe `cookie_secure => true` em HTTPS.
4. Confirme que as extensões PHP `pdo_mysql` e `openssl` estão habilitadas e que **mod_rewrite** está ativo no Apache para as URLs `/api/...` e `/c/...`.
5. Acesse `https://seu-dominio/health` e confirme `"ok":true` e `"database":"connected"`; em seguida abra a página inicial, que cria o esquema automaticamente na primeira requisição à API.
6. Restrinja o acesso se a demo ficar na Internet: **o botão de login é intencionalmente público e não autentica comerciantes reais**. Use um endereço de testes protegido na hospedagem, não um sistema público de clientes.

**Quando não for possível mudar a raiz do domínio:** coloque o conteúdo de `public/` dentro de `public_html/`; coloque `src/`, `storage/`, `config.php` e `config.local.php` no diretório **pai** de `public_html/`. O `index.php` localiza esses arquivos usando `dirname(__DIR__)`. Nunca publique a estrutura inteira dentro de `public_html/`.

## Exemplo de API

No painel, abra **API & Webhooks → Gerar chave de teste**.

```bash
curl -X POST 'https://seu-dominio.com/api/v1/charges' \
  -H 'Content-Type: application/json' \
  -H 'Authorization: Bearer arg_test_SUA_CHAVE' \
  -H 'Idempotency-Key: pedido-loja-00001' \
  -d '{"amount_cents":4990,"method":"pix","customer_name":"Maria Silva","customer_email":"maria@example.com","description":"Plano Premium"}'
```

**Criar uma cobrança não equivale a receber dinheiro**. A API cria uma cobrança pendente de teste. Os botões "Aprovar teste" e "Estornar teste" alteram apenas o banco demonstrativo.

Endpoints suportados (a lista completa está em `/docs`):

| Endpoint | Ação |
|---|---|
| `POST /api/auth/demo` | Iniciar sessão de teste |
| `GET /api/overview` | Resumo e gráficos |
| `GET/POST /api/payments` | Listar/criar cobrança |
| `POST /api/payments/{id}/settle` | Aprovar cobrança fictícia |
| `POST /api/payments/{id}/refund` | Estorno fictício |
| `GET/POST /api/links` | Links de checkout |
| `GET/POST /api/customers` | Clientes |
| `GET/POST /api/subscriptions` | Assinaturas |
| `GET/POST /api/splits` | Regras de divisão de pagamentos |
| `GET/POST /api/keys` | Chaves de API |
| `GET /api/events` | Auditoria |
| `GET /api/reports/payments.csv` | Relatório CSV |
| `POST /api/v1/charges` | Criar cobrança via Bearer API |
| `GET /api/v1/charges/{id}` | Consultar cobrança via Bearer API |
| `GET /api/public/links/{slug}` | Dados públicos do checkout |
| `POST /api/public/links/{slug}/simulate` | Simular checkout |

## Limites e requisitos de produção

Esta versão **não pode** ser usada para transacionar valores reais sem desenvolvimento adicional. Para colocar a ARGUS Payments em produção comercial, é necessário um contrato com PSP/adquirente, contas e permissões apropriadas, login e permissões reais para cada estabelecimento, proteção contra bots, prevenção a fraudes, verificação e conciliação de webhooks do provedor, gestão de estornos, backups, monitoramento, controles de LGPD e avaliação jurídica/regulatória e de PCI DSS aplicável. **Nunca colete PAN e CVV de cartão neste checkout:** utilize tokenização ou componentes hospedados de um PSP.

`src/Integrations/MisticPayPix.php` é um conector de prévia **DRY RUN**, sem chamadas ao provedor. Nenhum valor do checkout desta demo se torna dinheiro real ao apenas inserir um token.

## Requisitos técnicos

- PHP 8.1 ou mais recente, com PDO e `pdo_sqlite` **ou** `pdo_mysql`.
- Apache com `.htaccess` e mod_rewrite, ou outro servidor com regra de encaminhamento para `public/index.php`.
- HTTPS em hospedagem publicada e `cookie_secure => true`.
- Permissão de gravação no diretório `storage/` se utilizar SQLite.

## Testes

Use `bash tests/smoke.sh` na máquina que possui PHP com `pdo_sqlite`: o teste inicia o servidor local, cria clientes, cobranças, links, simula checkout, gera/revoga chave de API e verifica idempotência. É necessário ter `curl` e `python3` disponíveis na máquina de teste.

**Licença:** Código demonstrativo disponibilizado para adaptação e desenvolvimento personalizado.


## Identidade visual ARGUS Payments

A identidade oficial usa a logomarca original enviada pelo proprietário, armazenada em `public/static/assets/argus-payments-logo.jpg`, com símbolo derivado em `argus-symbol.png`. O tema do painel e do checkout adota preto obsidiana, dourado metálico, prata e azul de destaque.

## Segurança da versão demonstrativa

Todas as ações com valores financeiros são **simuladas**. A interface e a API não constituem serviço de pagamento, custódia ou conta bancária. Não publique o botão de acesso de teste como login de usuários reais. O pacote mantém funcionalidades demonstrativas e precisa de autenticação comercial, verificação de webhook, controle de acesso e uma integração com PSP homologada antes de processamento real.

## Integração transacional MisticPay (18/11/2026)

O projeto inclui agora `MisticPayHttpClient` (chamadas reais `POST /api/transactions/create` e `/api/transactions/check`) e `LivePix` (API separada, status verificado no provedor, idempotência e split para o lojista). O código foi testado com um provedor simulado e **não está ativado no Render**.

A sessão de demonstração **não** possui permissão de cobrança real. A ativação exige banco persistente MySQL ou PostgreSQL, chave de produção `pk_/sk_` com escopos `TRANSACTION_CREATE` e `TRANSACTION_READ`, segredo operacional próprio, token de webhook forte e confirmação escrita da direção do split. A ARGUS neste modelo é a conta que inicia a cobrança e `splitUser` é a conta do lojista. Por exemplo: comissão ARGUS de 1,5% significa `splitTax: 98.5` PARA O LOJISTA, antes dos custos MisticPay. A validade comercial deste arranjo deve ser confirmada pela MisticPay.

Leia `ATIVAR-MISTICPAY-LIVE.md` para as variáveis, o roteiro de cadastro de lojistas e a API.


## Banco temporário junto ao PulsoFit (somente testes)

A ARGUS pode utilizar a mesma **instância** PostgreSQL do PulsoFit com um schema exclusivo,
`argus_payments_b2b`. O código cria esse schema com `CREATE SCHEMA IF NOT EXISTS` e
executa `SET search_path` antes de qualquer migração. As tabelas existentes em `public`
**não são alteradas**. Isto não é isolamento por permissões: é apenas separação lógica
no mesmo usuário PostgreSQL.

No Render > ARGUS > Environment, configure o driver `ARGUS_DB_DRIVER=pgsql`,
`ARGUS_PGSQL_SCHEMA=argus_payments_b2b`, `ARGUS_PGSQL_SHARED=true` e
`ARGUS_PGSQL_URL` com a **Internal Database URL** do PostgreSQL já usado pelo
PulsoFit. A URL é segredo: salve apenas na Render, nunca no GitHub/chat.
O modo de pagamento real deve permanecer `ARGUS_MISTICPAY_MODE=disabled`.

O PostgreSQL gratuito temporário do PulsoFit expira em 18/12/2026 (conforme a
conta Render verificada em 18/11/2026) e não oferece as garantias necessárias
para operação financeira. Para produção, migrar para um banco exclusivo com
backups e acesso separado.
