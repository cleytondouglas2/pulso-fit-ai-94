# ARGUS Payments — Centro de operações B2B

Aplicação PHP 8.3 / Apache, integração MisticPay Pix, PostgreSQL em schema isolado. Esta versão oferece **painel administrativo autenticado**; o login e os pagamentos fictícios da demonstração anterior foram removidos da interface e da API pública.

## Acesso ao painel

- `/admin` é a central administrativa; `/` redireciona visualmente para o mesmo painel.
- Super Admin inicial: `Cleyton.douglas2@gmail.com` (case-insensitive).
- Uma senha inicial aleatória é criada **fora do repositório**, e só seu hash bcrypt fica em `ARGUS_SUPERADMIN_BOOTSTRAP_HASH` na Render.
- O primeiro acesso exige troca imediata da senha. Login usa cookie de sessão HttpOnly, Secure, SameSite=Strict, token CSRF e bloqueio de tentativas.
- Somente o Super Admin cria usuários internos. Perfis: `superadmin`, `admin`, `analyst` (somente consulta).

## Funcionalidades

- Visão geral real: status de conexão, empresas, cobranças Pix confirmadas, comissões estimadas (antes do custo do PSP).
- Empresas: cadastro de CNPJ válido, taxa por lojista, recebedor MisticPay, análise, aprovação mediante confirmação de evidências KYB, suspensão, reabertura e alteração de dados.
- Suspensão e alteração do recebedor revogam todas as chaves ativas; liberar novamente exige nova aprovação e nova chave.
- Pagadores: listagem baseada em cobranças reais e bloqueio por CPF usando HMAC com segredo privado; CPF completo nunca fica no banco.
- Cobranças: status real, controle de idempotência, reconciliação autenticada diretamente com a MisticPay. Nenhum botão administrativo altera manualmente um pagamento para `paid`.
- API keys: emissão por lojista aprovado, mostradas somente uma vez, revogação a qualquer momento.
- Relatórios diários e exportação CSV; auditoria de todas as operações administrativas; gestão de usuários.

## Variáveis da Render

```dotenv
ARGUS_OPERATION_MODE=production
ARGUS_DB_DRIVER=pgsql
ARGUS_PGSQL_SHARED=true
ARGUS_PGSQL_SCHEMA=argus_payments_b2b
ARGUS_PGSQL_URL=<preencher em segredo na Render>
ARGUS_SUPERADMIN_BOOTSTRAP_EMAIL=Cleyton.douglas2@gmail.com
ARGUS_SUPERADMIN_BOOTSTRAP_HASH=<bcrypt hash da senha temporária; nunca senha em texto>
ARGUS_PAYER_HMAC_KEY=<segredo aleatório>=32 caracteres
ARGUS_COOKIE_SECURE=true
ARGUS_MISTICPAY_MODE=live
```

Preservar chaves MisticPay PK/SK, token de webhook e configurações de split preexistentes. **Não compartilhe segredos ou URLs de banco em código, logs ou capturas de tela.**

## Modelo de integração

- `POST /api/live/pix/charges` cria Pix somente para lojista aprovado, com bearer `arg_live_...` e `Idempotency-Key`.
- `POST /api/live/pix/charges/{id}/reconcile` consulta a MisticPay e verifica status.
- A confirmação por webhook requer consulta autenticada ao provedor antes de marcar `paid`.
- No banco compartilhado gratuito em Oregon, o piloto existente limita Pix a R$ 100 e encerra automaticamente em 2026-12-10T00:00:00Z. **Não é infraestrutura financeira durável.**

## Testes sem dinheiro

O Dockerfile roda `php tests/shared_pgsql_unit.php`, `php tests/live_pix_unit.php` e `php tests/admin_http.php` em SQLite temporário dentro do build. Não gera Pix verdadeiros. Nenhum serviço ou branch principal do PulsoFit é modificado.

## Pendências relevantes antes de escalar

A criação do Super Admin e a implantação do painel **não substituem** backups verificados, MFA para operadores, KYB documental e homologação de repasses reais. Migrar para banco próprio com backup contínuo e revisão de segurança antes do fim do piloto.
